package com.marktv

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.text.InputType
import android.graphics.Color
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import kotlin.math.min

/** The Jarvis screen: reactor core, live transcript, a few big buttons. Diagnostics live in ServiceActivity. */
class MainActivity : Activity() {

    private lateinit var app: App
    private lateinit var core: JarvisView
    private lateinit var stateText: TextView
    private lateinit var youText: TextView
    private lateinit var botText: TextView
    private lateinit var contBtn: TextView
    private lateinit var micFlag: TextView
    private var seenVersion = 0

    private val logListener: (String) -> Unit = { line ->
        val i = line.indexOf("Вы: ")
        if (i >= 0) {
            youText.text = line.substring(i + 4)
            botText.text = ""
            botText.setTextColor(Hud.CYAN)
        }
        val j = line.indexOf("Mark: ")
        if (j >= 0) {
            botText.text = line.substring(j + 6)
            botText.setTextColor(Hud.CYAN)
        } else if (line.contains("ошибка") || line.contains("Нет разрешения") || line.contains("недоступен")) {
            botText.text = line.substring(minOf(line.length, 10))
            botText.setTextColor(Hud.AMBER)
        }
    }
    private val stateListener: () -> Unit = { refresh() }
    private val levelListener: () -> Unit = { core.level = app.voice.rms }
    private val partialListener: (String) -> Unit = { youText.text = it }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = application as App
        seenVersion = Hud.version
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (!app.voice.hasPermission()) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }

        val dm = resources.displayMetrics
        val d = dm.density
        fun dp(v: Int): Int = (v * d).toInt()
        val light = Typeface.create("sans-serif-light", Typeface.NORMAL)
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = FrameLayout(this)
        root.addView(HudBackground(this), FrameLayout.LayoutParams(match, match))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(40), dp(22), dp(40), dp(22))
        }
        root.addView(content, FrameLayout.LayoutParams(match, match))

        // top bar
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 30f
            setTextColor(Hud.CYAN)
            letterSpacing = 0.3f
            typeface = light
        }
        val sub = TextView(this).apply {
            text = "MARK TV  •  ANDROID TV"
            textSize = 12f
            setTextColor(Hud.MUTED)
            letterSpacing = 0.2f
        }
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(title)
            addView(sub)
        }
        micFlag = TextView(this).apply {
            text = "● МИКРОФОН ВКЛЮЧЁН"
            textSize = 13f
            setTextColor(Hud.RED)
            letterSpacing = 0.1f
            visibility = android.view.View.GONE
        }
        val clock = TextClock(this).apply {
            format24Hour = "HH:mm"
            format12Hour = "HH:mm"
            textSize = 30f
            setTextColor(Hud.TEXT)
            typeface = light
        }
        top.addView(titleCol, LinearLayout.LayoutParams(0, wrap, 1f))
        top.addView(micFlag, LinearLayout.LayoutParams(wrap, wrap).apply { marginEnd = dp(24) })
        top.addView(clock)
        content.addView(top, LinearLayout.LayoutParams(match, wrap))

        // centre row: core on the left, transcript on the right
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val coreSize = min(dm.heightPixels * 0.34f, dm.widthPixels * 0.22f).toInt()
        core = JarvisView(this).apply { setOnClickListener { toggleListen() } }
        left.addView(core, LinearLayout.LayoutParams(coreSize, coreSize))
        stateText = TextView(this).apply {
            textSize = 20f
            letterSpacing = 0.35f
            gravity = Gravity.CENTER
            typeface = light
        }
        left.addView(stateText, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(8) })
        row.addView(left, LinearLayout.LayoutParams(0, match, 0.5f))

        val panel = HudPanel(this)
        val youCap = TextView(this).apply {
            text = "ВЫ"
            textSize = 12f
            setTextColor(Hud.MUTED)
            letterSpacing = 0.3f
        }
        youText = TextView(this).apply {
            textSize = 24f
            setTextColor(Hud.TEXT)
            typeface = light
        }
        val botCap = TextView(this).apply {
            text = "JARVIS"
            textSize = 12f
            setTextColor(Hud.MUTED)
            letterSpacing = 0.3f
        }
        botText = TextView(this).apply {
            textSize = 22f
            setTextColor(Hud.CYAN)
            setLineSpacing(0f, 1.1f)
            text = "Нажмите OK на ядре или кнопку микрофона на пульте и скажите команду."
        }
        val botScroll = ScrollView(this).apply { isFocusable = false }
        botScroll.addView(botText)
        panel.addView(youCap)
        panel.addView(youText, LinearLayout.LayoutParams(match, wrap).apply { bottomMargin = dp(18) })
        panel.addView(botCap)
        panel.addView(botScroll, LinearLayout.LayoutParams(match, 0, 1f))
        row.addView(panel, LinearLayout.LayoutParams(0, match, 1.9f).apply {
            topMargin = dp(10)
            bottomMargin = dp(10)
            marginStart = dp(16)
        })
        content.addView(row, LinearLayout.LayoutParams(match, 0, 1f))

        // text input bar
        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val input = EditText(this).apply {
            hint = "Напишите команду и нажмите «Отправить»"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF667788.toInt())
            textSize = 16f
        }
        fun send() {
            val t = input.text.toString().trim()
            if (t.isEmpty()) return
            input.setText("")
            try {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
            } catch (ignored: Throwable) {
            }
            core.requestFocus()
            app.voice.submitText(t)
        }
        input.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_SEND || action == EditorInfo.IME_ACTION_DONE) {
                send(); true
            } else false
        }
        inputRow.addView(input, LinearLayout.LayoutParams(0, wrap, 1f))
        inputRow.addView(Hud.button(this, "Отправить") { send() }, LinearLayout.LayoutParams(wrap, wrap).apply { marginStart = dp(14) })
        content.addView(inputRow, LinearLayout.LayoutParams(match, wrap).apply { bottomMargin = dp(6) })

        // bottom bar
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        contBtn = Hud.button(this, "") { app.voice.setContinuous(!app.voice.continuous) }
        val serviceBtn = Hud.button(this, "Сервис") {
            startActivity(Intent(this, ServiceActivity::class.java))
        }
        val hint = TextView(this).apply {
            text = "Поиск и длинные ответы появляются справа на экране"
            textSize = 12f
            setTextColor(Hud.MUTED)
            gravity = Gravity.END
        }
        bottom.addView(contBtn)
        bottom.addView(serviceBtn, LinearLayout.LayoutParams(wrap, wrap).apply { marginStart = dp(14) })
        bottom.addView(hint, LinearLayout.LayoutParams(0, wrap, 1f))
        content.addView(bottom, LinearLayout.LayoutParams(match, wrap))

        setContentView(root)
        core.requestFocus()
        refresh()

        // Connect to the TV's own adbd once per process, so the "Allow debugging?" prompt shows now.
        if (!app.adbProbed) {
            app.adbProbed = true
            Thread { app.log("ADB: " + app.keys.shell("echo ok")) }.start()
        }
    }

    private fun toggleListen() {
        if (app.voice.state == VState.IDLE && !app.voice.continuous) app.voice.listenOnce()
        else app.voice.abort()
    }

    override fun onStart() {
        super.onStart()
        app.addLogListener(logListener)
        app.voice.stateListeners.add(stateListener)
        app.voice.levelListeners.add(levelListener)
        app.voice.partialListeners.add(partialListener)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        // colour changed on the Service screen: rebuild with the new palette
        if (seenVersion != Hud.version) recreate()
    }

    override fun onStop() {
        app.removeLogListener(logListener)
        app.voice.stateListeners.remove(stateListener)
        app.voice.levelListeners.remove(levelListener)
        app.voice.partialListeners.remove(partialListener)
        super.onStop()
    }

    private fun refresh() {
        val s = app.voice.state
        core.vstate = s
        val (label, color) = when (s) {
            VState.IDLE -> Pair("ОЖИДАНИЕ", Hud.CYAN)
            VState.LISTENING -> Pair("СЛУШАЮ", Hud.BRIGHT)
            VState.THINKING -> Pair("АНАЛИЗ", Hud.AMBER)
            VState.SPEAKING -> Pair("ОТВЕЧАЮ", Hud.GREEN)
        }
        stateText.text = label
        stateText.setTextColor(color)
        contBtn.text = if (app.voice.continuous) "Микрофон постоянно: вкл" else "Микрофон постоянно: выкл"
        micFlag.visibility = if (app.voice.continuous) android.view.View.VISIBLE else android.view.View.GONE
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0 &&
            (e.keyCode == KeyEvent.KEYCODE_SEARCH || e.keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
                e.keyCode == KeyEvent.KEYCODE_ASSIST)
        ) {
            toggleListen()
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        app.log("Разрешение на микрофон: ${if (ok) "получено" else "ОТКАЗАНО"}")
    }
}
