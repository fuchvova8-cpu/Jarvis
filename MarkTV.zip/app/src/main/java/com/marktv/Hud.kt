package com.marktv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

object Hud {
    const val DEFAULT_ACCENT = "#00d4ff"

    // Base palette (the original Mark teal). The accent-linked colours below are re-derived from it
    // by shifting the hue, so brightness and saturation ratios — and with them the design — stay intact.
    private val B_PRI = 0xFF00D4FF.toInt()
    private val B_BG = 0xFF00060A.toInt()
    private val B_PANEL = 0xFF010D14.toInt()
    private val B_TEXT = 0xFFD8F8FF.toInt()
    private val B_MUTED = 0xFF5AB8CC.toInt()
    private val B_BRIGHT = 0xFF4DF6FF.toInt()

    var CYAN = B_PRI
        private set
    var BG = B_BG
        private set
    var PANEL = withAlpha(B_PANEL, 0xCC)
        private set
    var TEXT = B_TEXT
        private set
    var MUTED = B_MUTED
        private set
    var BRIGHT = B_BRIGHT
        private set
    val CYAN_DIM: Int get() = withAlpha(CYAN, 0x66)

    // Status colours do not follow the accent
    val AMBER = 0xFFFFB300.toInt()
    val GREEN = 0xFF00E5A0.toInt()
    val RED = 0xFFFF5252.toInt()

    var accentHex = DEFAULT_ACCENT
    /** Set by the visible main screen so that a colour changed by a plugin repaints it at once. */
    @Volatile var onChange: Runnable? = null
        private set

    /** Bumped on every successful change; screens compare it to know when to rebuild. */
    var version = 0
        private set

    private fun hsv(c: Int): FloatArray {
        val a = FloatArray(3)
        Color.colorToHSV(c, a)
        return a
    }

    private fun shifted(base: Int, dh: Float, grey: Boolean): Int {
        val a = hsv(base)
        if (grey) a[1] *= 0.15f
        a[0] = ((a[0] + dh) % 360f + 360f) % 360f
        return Color.HSVToColor(Color.alpha(base), a)
    }

    /** Re-derives the palette from an accent "#rrggbb". Returns false for a bad value. */
    fun applyAccent(hex: String): Boolean {
        val h = hex.trim().lowercase()
        if (!Regex("^#[0-9a-f]{6}$").matches(h)) return false
        val acc = hsv(Color.parseColor(h))
        val dh = acc[0] - hsv(B_PRI)[0]
        val grey = acc[1] < 0.08f
        CYAN = shifted(B_PRI, dh, grey)
        BG = shifted(B_BG, dh, grey)
        PANEL = withAlpha(shifted(B_PANEL, dh, grey), 0xCC)
        TEXT = shifted(B_TEXT, dh, grey)
        MUTED = shifted(B_MUTED, dh, grey)
        BRIGHT = shifted(B_BRIGHT, dh, grey)
        accentHex = h
        version++
        return true
    }

    fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    fun button(ctx: Context, text: String, onClick: () -> Unit): TextView {
        val d = ctx.resources.displayMetrics.density
        fun shape(fill: Int, stroke: Int) = GradientDrawable().apply {
            setColor(fill)
            setStroke(max(1, (1.5f * d).toInt()), stroke)
            cornerRadius = 4f * d
        }
        val states = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), shape(withAlpha(CYAN, 70), CYAN))
            addState(intArrayOf(android.R.attr.state_pressed), shape(withAlpha(CYAN, 110), CYAN))
            addState(intArrayOf(), shape(withAlpha(CYAN, 12), CYAN_DIM))
        }
        return TextView(ctx).apply {
            this.text = text
            textSize = 14f
            setTextColor(TEXT)
            letterSpacing = 0.12f
            isAllCaps = true
            gravity = Gravity.CENTER
            background = states
            isFocusable = true
            isClickable = true
            setPadding((18 * d).toInt(), (10 * d).toInt(), (18 * d).toInt(), (10 * d).toInt())
            setOnClickListener { onClick() }
        }
    }
}

/** Dark glass panel with a thin border and bright corner brackets. */
class HudPanel(ctx: Context) : LinearLayout(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density

    init {
        orientation = VERTICAL
        setWillNotDraw(false)
        val pad = (18 * d).toInt()
        setPadding(pad, pad, pad, pad)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = Hud.PANEL
        c.drawRect(0f, 0f, w, h, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d
        p.color = Hud.withAlpha(Hud.CYAN, 70)
        c.drawRect(d / 2, d / 2, w - d / 2, h - d / 2, p)
        p.strokeWidth = 2.5f * d
        p.color = Hud.CYAN
        val l = 22f * d
        val o = d * 1.25f
        c.drawLines(
            floatArrayOf(
                o, o, o + l, o, o, o, o, o + l,
                w - o, o, w - o - l, o, w - o, o, w - o, o + l,
                o, h - o, o + l, h - o, o, h - o, o, h - o - l,
                w - o, h - o, w - o - l, h - o, w - o, h - o, w - o, h - o - l
            ), p
        )
    }
}

/** Static background: deep blue, a soft glow behind the core and a faint grid. */
class HudBackground(ctx: Context) : View(ctx) {
    private val p = Paint()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density
        c.drawColor(Hud.BG)
        p.shader = RadialGradient(
            w * 0.27f, h * 0.52f, max(w, h) * 0.55f,
            Hud.withAlpha(Hud.CYAN, 48), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
        p.color = Hud.withAlpha(Hud.CYAN, 14)
        p.strokeWidth = d
        val step = 48f * d
        var x = 0f
        while (x < w) {
            c.drawLine(x, 0f, x, h, p)
            x += step
        }
        var y = 0f
        while (y < h) {
            c.drawLine(0f, y, w, y, p)
            y += step
        }
    }
}

/**
 * The reactor core. Ticks and arcs rotate, a comet circles the core, radial bars show the voice
 * level while listening and an imitation of speech while speaking. Colour and speed follow the state.
 * Only strokes, lines and one cached gradient — light enough for a weak TV SoC (~30 fps).
 */
class JarvisView(ctx: Context) : View(ctx) {

    var vstate: VState = VState.IDLE
    var level: Float = 0f

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()
    private val t0 = SystemClock.uptimeMillis()
    private var lvl = 0f
    private var running = false

    private var coreShader: RadialGradient? = null
    private var coreColor = 0

    private val nTicks = 48
    private val nBars = 48
    private val ticks = FloatArray(nTicks * 4)
    private val cosB = FloatArray(nBars)
    private val sinB = FloatArray(nBars)
    private val hex = FloatArray(6 * 4)

    private val frame = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, 33)
        }
    }

    init {
        isFocusable = true
        isClickable = true
        for (i in 0 until nBars) {
            val a = (2.0 * PI * i / nBars).toFloat()
            cosB[i] = cos(a)
            sinB[i] = sin(a)
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) / 2f * 0.92f
        for (i in 0 until nTicks) {
            val a = (2.0 * PI * i / nTicks).toFloat()
            val len = if (i % 4 == 0) 0.07f else 0.035f
            val ca = cos(a)
            val sa = sin(a)
            ticks[i * 4] = cx + ca * r * 0.97f
            ticks[i * 4 + 1] = cy + sa * r * 0.97f
            ticks[i * 4 + 2] = cx + ca * r * (0.97f - len)
            ticks[i * 4 + 3] = cy + sa * r * (0.97f - len)
        }
        val hr = r * 0.30f
        for (i in 0 until 6) {
            val a1 = (2.0 * PI * i / 6).toFloat()
            val a2 = (2.0 * PI * (i + 1) / 6).toFloat()
            hex[i * 4] = cx + cos(a1) * hr
            hex[i * 4 + 1] = cy + sin(a1) * hr
            hex[i * 4 + 2] = cx + cos(a2) * hr
            hex[i * 4 + 3] = cy + sin(a2) * hr
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        start()
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) start() else stop()
    }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        invalidate()
    }

    private fun start() {
        if (!running) {
            running = true
            post(frame)
        }
    }

    private fun stop() {
        running = false
        removeCallbacks(frame)
    }

    private fun stateColor(): Int = when (vstate) {
        VState.IDLE -> Hud.CYAN
        VState.LISTENING -> Hud.BRIGHT
        VState.THINKING -> Hud.AMBER
        VState.SPEAKING -> Hud.GREEN
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cx = w / 2f
        val cy = h / 2f
        val half = min(w, h) / 2f
        val r = half * 0.92f
        val d = resources.displayMetrics.density
        val t = (SystemClock.uptimeMillis() - t0) / 1000f
        val col = stateColor()

        val (v1, v2) = when (vstate) {
            VState.IDLE -> Pair(6f, -10f)
            VState.LISTENING -> Pair(20f, -30f)
            VState.THINKING -> Pair(140f, -200f)
            VState.SPEAKING -> Pair(30f, -45f)
        }
        val target = if (vstate == VState.LISTENING) level.coerceIn(0f, 10f) / 10f else 0f
        lvl += (target - lvl) * 0.25f

        // outer thin ring
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.BUTT
        p.strokeWidth = d
        p.color = Hud.withAlpha(col, 90)
        c.drawCircle(cx, cy, r, p)

        // ticks
        c.save()
        c.rotate((t * v1) % 360f, cx, cy)
        p.strokeWidth = 1.5f * d
        p.color = Hud.withAlpha(col, 150)
        c.drawLines(ticks, p)
        c.restore()

        // segmented arcs
        val ra = r * 0.82f
        oval.set(cx - ra, cy - ra, cx + ra, cy + ra)
        p.strokeWidth = r * 0.04f
        p.color = Hud.withAlpha(col, 200)
        val base2 = (t * v2) % 360f
        for (i in 0 until 3) c.drawArc(oval, base2 + i * 120f, 80f, false, p)

        // comet
        val rc = r * 0.70f
        oval.set(cx - rc, cy - rc, cx + rc, cy + rc)
        p.strokeWidth = r * 0.025f
        val head = (t * v1 * 1.5f) % 360f
        for (i in 0 until 16) {
            p.color = Hud.withAlpha(col, 230 - i * 14)
            c.drawArc(oval, head - i * 5f, 5.5f, false, p)
        }

        // radial bars: voice level / imitation of speech
        val inner = r * 0.56f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = max(2f, r * 0.018f)
        p.color = Hud.withAlpha(col, 200)
        for (i in 0 until nBars) {
            val amp = when (vstate) {
                VState.LISTENING -> 0.12f + lvl * (0.5f + 0.5f * sin(i * 0.9f + t * 9f)) * 0.9f
                VState.SPEAKING -> 0.10f + 0.55f * abs(sin(t * 6.5f + i * 0.55f)) * (0.55f + 0.45f * sin(t * 2.3f))
                VState.THINKING -> 0.08f + 0.06f * (0.5f + 0.5f * sin(i * 0.5f - t * 8f))
                VState.IDLE -> 0.05f + 0.025f * (0.5f + 0.5f * sin(i * 0.4f + t * 1.5f))
            }
            val len = r * amp * 0.35f
            c.drawLine(
                cx + cosB[i] * inner, cy + sinB[i] * inner,
                cx + cosB[i] * (inner + len), cy + sinB[i] * (inner + len), p
            )
        }

        // core glow (gradient cached, scaled with the canvas)
        val pulse = 0.38f + 0.02f * sin(t * 2.2f) + lvl * 0.06f
        val cr = r * pulse
        if (coreShader == null || coreColor != col) {
            coreShader = RadialGradient(
                0f, 0f, 100f,
                intArrayOf(0xFFFFFFFF.toInt(), Hud.withAlpha(col, 230), Hud.withAlpha(col, 0)),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
            )
            coreColor = col
        }
        c.save()
        c.translate(cx, cy)
        c.scale(cr / 100f, cr / 100f)
        p.style = Paint.Style.FILL
        p.shader = coreShader
        c.drawCircle(0f, 0f, 100f, p)
        p.shader = null
        c.restore()

        // hexagon and core ring
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 1.5f * d
        p.color = Hud.withAlpha(0xFFFFFFFF.toInt(), 170)
        c.save()
        c.rotate(-t * 20f, cx, cy)
        c.drawLines(hex, p)
        c.restore()
        p.color = Hud.withAlpha(col, 220)
        p.strokeWidth = 2f * d
        c.drawCircle(cx, cy, cr * 0.62f, p)

        if (isFocused) {
            p.strokeWidth = 2f * d
            p.color = 0xFFFFFFFF.toInt()
            c.drawCircle(cx, cy, half * 0.99f, p)
        }
        p.style = Paint.Style.FILL
    }
}
