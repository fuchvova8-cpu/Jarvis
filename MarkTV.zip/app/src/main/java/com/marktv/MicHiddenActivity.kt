package com.marktv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/**
 * Completely invisible "press the core" button: listens for ONE command and answers (voice/results as usual).
 * A second press while it listens stops it.
 */
class MicHiddenActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as App
        if (!app.voice.hasPermission()) {
            Toast.makeText(this, "Mark: нет разрешения на микрофон", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
        } else if ((app.voice.state == VState.SPEAKING || app.voice.state == VState.THINKING) && !app.voice.continuous) {
            app.voice.interrupt()   // the button during an answer: stop it and listen
        } else if (app.voice.state == VState.IDLE && !app.voice.continuous) {
            KeepAliveService.start(app)
            app.voice.listenOnce {
                if (!app.voice.continuous) KeepAliveService.stop(app)
            }
        } else if (!app.voice.continuous) {
            app.voice.abort()
            KeepAliveService.stop(app)
        }
        finish()
    }
}
