package com.marktv

/** Bottom strip + "microphone always on": first press turns it on and shows the strip, second press turns it off. */
class MicBarToggleActivity : OverlayActivity() {
    override val continuousMode: Boolean = true
}
