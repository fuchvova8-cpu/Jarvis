package com.marktv

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.net.Uri
import android.os.Environment
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.ListView
import org.json.JSONArray
import java.io.File
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.text.InputType
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

class ServiceActivity : Activity() {

    private lateinit var app: App
    private lateinit var orb: OrbView
    private lateinit var status: TextView
    private lateinit var partial: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var keyEdit: EditText
    private lateinit var modelEdit: EditText
    private lateinit var contBtn: Button
    private lateinit var pluginBox: LinearLayout
    private var voiceRefresh: (() -> Unit)? = null

    private val logListener: (String) -> Unit = { line ->
        logView.append(line + "\n")
        scroll.post { scroll.scrollTo(0, logView.height) }
    }
    private val stateListener: () -> Unit = { refresh() }
    private val levelListener: () -> Unit = { orb.level = app.voice.rms }
    private val partialListener: (String) -> Unit = { partial.text = it }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float = 16f): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(0xFFFFFFFF.toInt())
    }

    private fun btn(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 16f
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = application as App

        if (!app.voice.hasPermission()) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF101418.toInt())
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }

        val leftScroll = ScrollView(this).apply { isFocusable = false }
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, dp(12), 0)
        }
        leftScroll.addView(left)

        orb = OrbView(this)
        orb.setOnClickListener {
            if (app.voice.state == VState.IDLE && !app.voice.continuous) app.voice.listenOnce()
            else app.voice.abort()
        }
        left.addView(orb, LinearLayout.LayoutParams(dp(170), dp(170)).apply { gravity = Gravity.CENTER_HORIZONTAL })

        status = label("", 18f).apply { gravity = Gravity.CENTER }
        partial = label("", 15f).apply { gravity = Gravity.CENTER }
        left.addView(status, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        left.addView(partial, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        keyEdit = EditText(this).apply {
            hint = "Gemini API key"
            setText(app.apiKey)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF888888.toInt())
        }
        modelEdit = EditText(this).apply {
            hint = "Модель Gemini"
            setText(app.model)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF888888.toInt())
        }
        left.addView(keyEdit)
        left.addView(modelEdit)
        left.addView(btn("Сохранить ключ и модель") {
            app.apiKey = keyEdit.text.toString()
            app.model = modelEdit.text.toString()
            app.log("Настройки сохранены (модель ${app.model}, ключ ${if (app.apiKey.isEmpty()) "ПУСТОЙ" else "задан"})")
        })

        addColorSection(left)
        addVoiceSection(left)

        contBtn = btn("") {
            app.voice.setContinuous(!app.voice.continuous)
        }
        left.addView(contBtn)
        left.addView(btn("Диагностика системы") { diagnose() })
        left.addView(btn("Тест микрофона (AudioRecord, 4 с)") { micTest() })
        left.addView(btn("Тест Gemini") {
            app.worker.execute {
                val r = try {
                    app.brain.ask("Ответь одним словом: привет")
                } catch (e: Throwable) {
                    "Ошибка: ${e.message}"
                }
                app.log("Gemini: $r")
            }
        })
        left.addView(btn("Тест ADB (echo)") {
            app.worker.execute { app.log("ADB echo: " + app.keys.shell("echo ok")) }
        })
        left.addView(btn("ADB: громкость + (клавиша 24)") {
            app.worker.execute { app.log("ADB key 24: " + app.keys.key(24)) }
        })
        left.addView(btn("Список плагинов") {
            app.worker.execute {
                val r = try {
                    app.brain.describePlugins()
                } catch (e: Throwable) {
                    "Ошибка: ${e.message}"
                }
                app.log(r)
            }
        })

        left.addView(label("Настройки плагинов", 18f))
        pluginBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(pluginBox)
        left.addView(btn("Обновить меню плагинов") { loadPluginMenu() })
        addPluginsFolderSection(left)

        logView = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFFCCE0CC.toInt())
            setTextIsSelectable(false)
        }
        scroll = ScrollView(this).apply {
            isFocusable = true
            setBackgroundColor(0xFF0A0D10.toInt())
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(logView)
        }

        root.addView(leftScroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        root.addView(scroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.3f))
        setContentView(root)

        logView.text = app.history().joinToString("\n") + "\n"
        app.log("Плагины: ${app.pluginsDir().absolutePath}")
        app.log("Лог-файл: ${app.logFile.absolutePath}")
        refresh()

        // Connect to the TV's own adbd right away so the "Allow debugging?" prompt shows up now.
        Thread {
            app.log("ADB (127.0.0.1:5555): подтвердите запрос на ТВ, если он появился…")
            app.log("ADB: " + app.keys.shell("echo ok"))
        }.start()
    }

    override fun onStart() {
        super.onStart()
        app.tts.onReady = { voiceRefresh?.invoke() }
        voiceRefresh?.invoke()
        app.addLogListener(logListener)
        app.voice.stateListeners.add(stateListener)
        app.voice.levelListeners.add(levelListener)
        app.voice.partialListeners.add(partialListener)
        refresh()
        loadPluginMenu()
    }

    override fun onStop() {
        app.tts.onReady = null
        app.removeLogListener(logListener)
        app.voice.stateListeners.remove(stateListener)
        app.voice.levelListeners.remove(levelListener)
        app.voice.partialListeners.remove(partialListener)
        super.onStop()
    }

    private fun refresh() {
        orb.vstate = app.voice.state
        status.text = when (app.voice.state) {
            VState.IDLE -> "Нажмите OK на значке или кнопку микрофона"
            VState.LISTENING -> "Слушаю…"
            VState.THINKING -> "Думаю…"
            VState.SPEAKING -> "Говорю…"
        }
        if (app.voice.state != VState.LISTENING) partial.text = ""
        contBtn.text = if (app.voice.continuous) "Микрофон постоянно: ВКЛ (нажмите — выкл)"
        else "Микрофон постоянно: ВЫКЛ (нажмите — вкл)"
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0 && currentFocus !is EditText) {
            val k = e.keyCode
            val nav = k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN ||
                k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT ||
                k == KeyEvent.KEYCODE_DPAD_CENTER
            if (!nav) app.log("KEY $k ${KeyEvent.keyCodeToString(k)}")
        }
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0 &&
            (e.keyCode == KeyEvent.KEYCODE_SEARCH || e.keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
                e.keyCode == KeyEvent.KEYCODE_ASSIST)
        ) {
            orb.performClick()
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        if (requestCode == 2) app.log("Разрешение на файлы: ${if (ok) "получено — нажмите «Применить папку» ещё раз" else "ОТКАЗАНО"}")
        else app.log("Разрешение на микрофон: ${if (ok) "получено" else "ОТКАЗАНО"}")
    }

    // ---------- plugin settings menu ----------

    /** One button per plugin that has a settings page (the plugin names its own menu item). */
    private fun loadPluginMenu() {
        app.worker.execute {
            val json = try {
                app.brain.pluginSettingsList()
            } catch (e: Throwable) {
                app.log("Меню плагинов: ${e.message}")
                "[]"
            }
            runOnUiThread {
                pluginBox.removeAllViews()
                try {
                    val arr = JSONArray(json)
                    if (arr.length() == 0) {
                        pluginBox.addView(label("Нет плагинов с настройками", 14f))
                    }
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        pluginBox.addView(btn(o.optString("title")) {
                            startActivity(
                                Intent(this, PluginSettingsActivity::class.java)
                                    .putExtra(PluginSettingsActivity.EXTRA_PLUGIN, o.optString("name"))
                                    .putExtra(PluginSettingsActivity.EXTRA_TITLE, o.optString("title"))
                            )
                        })
                    }
                } catch (e: Throwable) {
                    app.log("Меню плагинов: ${e.message}")
                }
            }
        }
    }

    // ---------- plugins folder ----------

    private fun ownDirs(): List<String> = listOfNotNull(
        getExternalFilesDir(null)?.parentFile?.absolutePath, filesDir.absolutePath
    )

    private fun needsStorageAccess(path: String): Boolean = ownDirs().none { path.startsWith(it) }

    /** Asks for access to files outside the app's own folder. Returns true if access is already there. */
    private fun ensureStorageAccess(): Boolean {
        if (Build.VERSION.SDK_INT >= 30) {
            if (Environment.isExternalStorageManager()) return true
            app.log("Разрешите «Доступ ко всем файлам» для Mark TV, затем нажмите кнопку ещё раз")
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Throwable) {
                app.log("Не открылись настройки доступа к файлам: ${e.message}")
            }
            return false
        }
        val perms = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) return true
        app.log("Нужно разрешение на доступ к файлам — разрешите и нажмите кнопку ещё раз")
        requestPermissions(perms, 2)
        return false
    }

    private fun applyPluginsFolder(raw: String) {
        val path = raw.trim().trimEnd('/')
        val old = app.pluginsDir()
        if (path.isEmpty()) {
            app.customPluginsDir = ""
            app.log("Папка плагинов: стандартная — ${app.pluginsDir().absolutePath}")
            return
        }
        if (!path.startsWith("/")) {
            app.log("Папка плагинов: нужен полный путь, например /storage/emulated/0/MarkTV/plugins")
            return
        }
        if (needsStorageAccess(path) && !ensureStorageAccess()) return
        val d = File(path)
        try {
            d.mkdirs()
        } catch (ignored: Throwable) {
        }
        if (!d.isDirectory || !d.canRead()) {
            app.log("Папка плагинов: не удалось открыть $path")
            return
        }
        app.customPluginsDir = path
        val hasPy = (d.listFiles { f -> f.isFile && f.name.endsWith(".py") } ?: emptyArray()).isNotEmpty()
        var note = ""
        if (!hasPy && old.absolutePath != d.absolutePath) {
            val n = app.copyPlugins(old, d)
            if (n > 0) note = " (скопировано плагинов из старой папки: $n)"
        }
        app.log("Папка плагинов: $path$note")
    }

    private fun addPluginsFolderSection(left: LinearLayout) {
        left.addView(label("Папка плагинов", 18f))
        val cur = label("", 13f)
        fun show() {
            cur.text = "Сейчас: ${app.pluginsDir().absolutePath}" +
                if (app.customPluginsDir.isEmpty()) "  (стандартная)" else ""
        }
        show()
        left.addView(cur)
        val edit = EditText(this).apply {
            hint = "/storage/emulated/0/MarkTV/plugins"
            setSingleLine(true)
            setText(app.customPluginsDir)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF888888.toInt())
        }
        left.addView(edit)
        left.addView(btn("Выбрать папку…") {
            if (ensureStorageAccess()) {
                val start = File(edit.text.toString().trim()).takeIf { it.isDirectory }
                    ?: Environment.getExternalStorageDirectory()
                pickFolder(start) { edit.setText(it) }
            }
        })
        left.addView(btn("Применить папку") {
            applyPluginsFolder(edit.text.toString())
            show()
        })
        left.addView(btn("Вернуть стандартную папку") {
            edit.setText("")
            applyPluginsFolder("")
            show()
        })
    }

    /** Small folder browser: OK on a row opens it, the first row goes up. */
    private fun pickFolder(start: File, onPick: (String) -> Unit) {
        var dir = start
        val entries = ArrayList<String>()
        val list = ListView(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, entries)
        list.adapter = adapter
        val dlg = AlertDialog.Builder(this)
            .setView(list)
            .setPositiveButton("Выбрать эту папку") { _, _ -> onPick(dir.absolutePath) }
            .setNegativeButton("Отмена", null)
            .create()
        var subs: List<File> = emptyList()
        fun fill() {
            subs = (dir.listFiles { f -> f.isDirectory && !f.name.startsWith(".") } ?: emptyArray())
                .sortedBy { it.name.lowercase() }
            entries.clear()
            entries.add("⬆  .. (вверх)")
            subs.forEach { entries.add("📁  " + it.name) }
            adapter.notifyDataSetChanged()
            dlg.setTitle(dir.absolutePath)
        }
        list.setOnItemClickListener { _, _, pos, _ ->
            if (pos == 0) dir.parentFile?.let { dir = it } else dir = subs[pos - 1]
            fill()
        }
        fill()
        dlg.show()
    }

    private fun swatchBg(fill: Int): Drawable {
        fun shape(stroke: Int, w: Int) = GradientDrawable().apply {
            setColor(fill)
            setStroke(w, stroke)
            cornerRadius = dp(4).toFloat()
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), shape(0xFFFFFFFF.toInt(), dp(4)))
            addState(intArrayOf(), shape(0xFF223344.toInt(), dp(1)))
        }
    }

    private fun hueOf(color: Int): Int {
        val a = FloatArray(3)
        Color.colorToHSV(color, a)
        return a[0].toInt().coerceIn(0, 359)
    }

    private fun hexFromHue(h: Int): String =
        String.format("#%06x", Color.HSVToColor(floatArrayOf(h.toFloat(), 1f, 1f)) and 0xFFFFFF)

    /** Interface colour, like the hue wheel / hex field of the desktop Mark: presets, a hue slider and a hex box. */
    /** Voice of the spoken answers: TTS engine, voice, speed and pitch. */
    private fun addVoiceSection(left: LinearLayout) {
        left.addView(label("Голос озвучки", 18f))
        val current = label("", 14f)
        left.addView(current)

        var gemBtn: Button? = null
        var gemVoiceBtn: Button? = null

        fun refreshText() {
            val g = app.tts.gem
            gemBtn?.text = if (g.enabled) "Нейроголос Gemini: ВКЛ (нажмите — выкл)" else "Нейроголос Gemini: ВЫКЛ (нажмите — вкл)"
            gemVoiceBtn?.text = "Голос Gemini: ${g.voice}"
            val pause = g.pauseMinutes()
            current.text = (if (g.enabled) "Говорит: Gemini, голос ${g.voice}, модель ${g.model}\n" +
                (if (pause > 0) "ЛИМИТ Gemini исчерпан, пауза ещё ~$pause мин — говорит системный\n" else "") +
                "Системный — запасной:\n" else "Говорит: системный голос\n") +
                "Движок: ${app.tts.engineLabel()}\n" +
                "Голос: ${app.tts.voiceName.ifEmpty { "по умолчанию" }}\n" +
                "Скорость: %.2f   Тон: %.2f".format(app.tts.rate, app.tts.pitch)
        }
        voiceRefresh = { refreshText() }

        gemBtn = btn("") {
            app.tts.gem.enabled = !app.tts.gem.enabled
            refreshText()   // no test phrase here: the free tier allows only ~10 Gemini voice requests a day
        }
        left.addView(gemBtn)
        gemVoiceBtn = btn("") {
            val names = GeminiTts.VOICES.map { "${it.first} — ${it.second}" }
            val checked = GeminiTts.VOICES.indexOfFirst { it.first == app.tts.gem.voice }
            AlertDialog.Builder(this)
                .setTitle("Голос Gemini (выбор сразу озвучивается)")
                .setSingleChoiceItems(names.toTypedArray(), checked) { dlg, which ->
                    app.tts.gem.voice = GeminiTts.VOICES[which].first
                    app.tts.gem.enabled = true
                    refreshText()
                    app.tts.speak("Здравствуйте. Это проверка голоса. Меня зовут Джарвис.")
                    dlg.dismiss()
                }
                .setNegativeButton("Отмена", null)
                .show()
        }
        left.addView(gemVoiceBtn)
        val gemModelEdit = EditText(this).apply {
            hint = "Live-модель Gemini (как в Mark-LVII)"
            setText(app.tts.gem.model)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF888888.toInt())
        }
        left.addView(gemModelEdit)
        left.addView(btn("Сохранить модель озвучки") {
            app.tts.gem.model = gemModelEdit.text.toString()
            refreshText()
            app.tts.gem.clearPause()   // a new model may have its own quota
            app.log("Модель озвучки Gemini: ${app.tts.gem.model}")
        })
        refreshText()

        fun test() {
            app.tts.speak("Здравствуйте. Это проверка голоса. Меня зовут Джарвис.")
        }

        left.addView(btn("Системный голос: выбрать") {
            val voices = app.tts.russianVoices()
            if (voices.isEmpty()) {
                app.log("Русских голосов у этого движка нет. Выберите другой движок или установите голос в настройках TTS")
                return@btn
            }
            val names = voices.mapIndexed { i, v ->
                "${i + 1}. ${v.name}  (${if (v.isNetworkConnectionRequired) "онлайн" else "офлайн"})"
            }
            val checked = voices.indexOfFirst { it.name == app.tts.voiceName }
            AlertDialog.Builder(this)
                .setTitle("Голос (выбор сразу озвучивается)")
                .setSingleChoiceItems(names.toTypedArray(), checked) { dlg, which ->
                    app.tts.setVoice(voices[which].name)
                    refreshText()
                    test()
                    dlg.dismiss()
                }
                .setNeutralButton("По умолчанию") { _, _ ->
                    app.tts.setVoice("")
                    app.tts.setEngine(app.tts.enginePkg)
                }
                .setNegativeButton("Отмена", null)
                .show()
        })

        left.addView(btn("Системный движок озвучки: выбрать") {
            val list = app.tts.engines()
            if (list.isEmpty()) {
                app.log("Движки TTS не найдены")
                return@btn
            }
            val labels = ArrayList<String>()
            labels.add("Системный по умолчанию")
            list.forEach { labels.add("${it.second}  [${it.first}]") }
            val checked = if (app.tts.enginePkg.isEmpty()) 0 else (list.indexOfFirst { it.first == app.tts.enginePkg } + 1)
            AlertDialog.Builder(this)
                .setTitle("Движок TTS")
                .setSingleChoiceItems(labels.toTypedArray(), checked) { dlg, which ->
                    app.tts.setEngine(if (which == 0) "" else list[which - 1].first)
                    refreshText()
                    dlg.dismiss()
                }
                .setNegativeButton("Отмена", null)
                .show()
        })

        fun slider(title: String, value: Float, onChange: (Float) -> Unit) {
            left.addView(label(title, 14f))
            val bar = SeekBar(this).apply {
                max = 150                 // 0.50 .. 2.00
                keyProgressIncrement = 5
                progress = ((value - 0.5f) * 100).toInt().coerceIn(0, 150)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        if (fromUser) {
                            onChange(0.5f + progress / 100f)
                            refreshText()
                        }
                    }

                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) { test() }
                })
            }
            left.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        slider("Скорость речи, только системный голос (← →)", app.tts.rate) { app.tts.rate = it }
        slider("Тон голоса, только системный голос (← →)", app.tts.pitch) { app.tts.pitch = it }

        left.addView(btn("Проверить голос") { test() })
        left.addView(btn("Сбросить голос, скорость и тон") {
            app.tts.rate = 1.0f
            app.tts.pitch = 1.0f
            app.tts.setVoice("")
            app.tts.setEngine(app.tts.enginePkg)
            refreshText()
        })
        left.addView(btn("Системные настройки озвучки (TTS)") {
            try {
                startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Throwable) {
                try {
                    startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e2: Throwable) {
                    app.log("Не удалось открыть настройки: ${e2.message}")
                }
            }
        })
    }

    private fun addColorSection(left: LinearLayout) {
        left.addView(label("Цвет интерфейса Jarvis", 18f))
        val current = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setShadowLayer(4f, 0f, 0f, 0xFF000000.toInt())
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        var hueBar: SeekBar? = null
        var hexEdit: EditText? = null

        fun setAccent(hex: String): Boolean {
            if (!Hud.applyAccent(hex)) return false
            app.accent = Hud.accentHex
            current.text = Hud.accentHex
            current.setBackgroundColor(Hud.CYAN)
            hueBar?.progress = hueOf(Hud.CYAN)
            hexEdit?.setText(Hud.accentHex)
            return true
        }

        current.text = Hud.accentHex
        current.setBackgroundColor(Hud.CYAN)
        left.addView(current, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val presets = listOf("#00d4ff", "#ff3355", "#ff6b00", "#ffcc00", "#00ff88", "#4d7cff", "#b44dff", "#ff4da6")
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (hex in presets) {
            val sw = View(this).apply {
                background = swatchBg(Color.parseColor(hex))
                isFocusable = true
                isClickable = true
                setOnClickListener { setAccent(hex) }
            }
            row.addView(sw, LinearLayout.LayoutParams(dp(34), dp(34)).apply {
                marginEnd = dp(6)
                topMargin = dp(6)
                bottomMargin = dp(6)
            })
        }
        left.addView(row)

        left.addView(label("Оттенок (← → на пульте)", 14f))
        val rainbow = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(
                0xFFFF0000.toInt(), 0xFFFFFF00.toInt(), 0xFF00FF00.toInt(),
                0xFF00FFFF.toInt(), 0xFF0000FF.toInt(), 0xFFFF00FF.toInt(), 0xFFFF0000.toInt()
            )
        ).apply {
            setSize(0, dp(14))
            cornerRadius = dp(7).toFloat()
        }
        val bar = SeekBar(this).apply {
            max = 359
            keyProgressIncrement = 5
            progress = hueOf(Hud.CYAN)
            progressDrawable = rainbow
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) setAccent(hexFromHue(progress))
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        hueBar = bar
        left.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val edit = EditText(this).apply {
            hint = "#rrggbb"
            setSingleLine(true)
            setText(Hud.accentHex)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF888888.toInt())
        }
        hexEdit = edit
        left.addView(edit)
        left.addView(btn("Применить hex") {
            if (!setAccent(edit.text.toString())) app.log("Цвет: нужен формат #rrggbb")
        })
        left.addView(btn("Сбросить цвет") { setAccent(Hud.DEFAULT_ACCENT) })
    }

    private fun typeName(t: Int): String = when (t) {
        15 -> "встроенный микрофон"
        11 -> "USB-устройство"
        22 -> "USB-гарнитура"
        7 -> "Bluetooth SCO"
        8 -> "Bluetooth A2DP"
        25 -> "remote submix"
        else -> "тип $t"
    }

    private fun diagnose() {
        app.log("— Диагностика —")
        app.log("Устройство: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        app.log("ABI: ${Build.SUPPORTED_ABIS.joinToString()}")
        app.log("RECORD_AUDIO: ${if (app.voice.hasPermission()) "есть" else "НЕТ"}")
        app.log("SpeechRecognizer доступен: ${SpeechRecognizer.isRecognitionAvailable(this)}")
        val svcs = packageManager.queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), 0)
        app.log("Службы распознавания: " + if (svcs.isEmpty()) "нет" else svcs.joinToString { it.serviceInfo.packageName })
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val ins = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
        app.log("Аудиовходы: " + if (ins.isEmpty()) "нет" else ins.joinToString { "${it.productName} [${typeName(it.type)}]" })
        app.log("TTS: ${app.tts.info()}")
        app.log("Ключ Gemini: ${if (app.apiKey.isEmpty()) "НЕ ЗАДАН" else "задан"}, модель ${app.model}")
    }

    private fun micTest() {
        if (!app.voice.hasPermission()) {
            app.log("Тест микрофона: нет разрешения")
            return
        }
        app.log("Тест микрофона: говорите 4 секунды…")
        Thread {
            try {
                val rate = 16000
                val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val ar = AudioRecord(
                    MediaRecorder.AudioSource.MIC, rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, 4096) * 2
                )
                if (ar.state != AudioRecord.STATE_INITIALIZED) {
                    app.log("AudioRecord не запустился (нет источника звука)")
                    ar.release()
                    return@Thread
                }
                ar.startRecording()
                val buf = ShortArray(1600)
                var peak = 0
                var sum = 0.0
                var n = 0L
                val end = System.currentTimeMillis() + 4000
                while (System.currentTimeMillis() < end) {
                    val r = ar.read(buf, 0, buf.size)
                    if (r <= 0) break
                    for (i in 0 until r) {
                        val v = abs(buf[i].toInt())
                        if (v > peak) peak = v
                        sum += v.toDouble() * v
                        n++
                    }
                }
                ar.stop()
                ar.release()
                val rms = if (n > 0) sqrt(sum / n) else 0.0
                val verdict = if (peak < 60) "ТИШИНА — микрофона нет или он не отдаёт звук приложениям"
                else "звук есть"
                app.log("AudioRecord: пик=$peak rms=${rms.toInt()} из 32767 → $verdict")
            } catch (e: Throwable) {
                app.log("AudioRecord: ${e.javaClass.simpleName}: ${e.message}")
            }
        }.start()
    }
}
