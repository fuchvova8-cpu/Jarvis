package com.marktv

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.concurrent.CopyOnWriteArrayList

enum class VState { IDLE, LISTENING, THINKING, SPEAKING }

/** How long a conversation keeps the microphone on after the last phrase (the Live session idles out at the same time). */
private const val CONVERSATION_MS = 10 * 60_000L

/**
 * Voice loop: system SpeechRecognizer (the same engine Android TV search uses,
 * so it can take audio from the remote's microphone) -> Gemini (Python) -> TTS.
 * Everything here runs on the main thread.
 */
class Voice(private val app: App) {

    var state = VState.IDLE
        private set
    var continuous = false
        private set
    var rms = 0f
        private set

    val stateListeners = CopyOnWriteArrayList<() -> Unit>()
    val levelListeners = CopyOnWriteArrayList<() -> Unit>()
    val partialListeners = CopyOnWriteArrayList<(String) -> Unit>()

    private var rec: SpeechRecognizer? = null
    private var busy = false
    private var errStreak = 0
    private var onFinished: (() -> Unit)? = null

    /**
     * Conversation mode: after a phrase spoken into the microphone the mic stays on, phrase after phrase, for as
     * long as the conversation goes on (the Live session lives the same 10 minutes) — like Mark-LVII, whose
     * microphone is simply always open. The same button that started it (or Stop) turns it off.
     */
    var conversation = false
        private set
    private var lastPhrase = 0L

    fun hasPermission(): Boolean =
        app.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun set(s: VState) {
        state = s
        if (s == VState.SPEAKING) startWatch() else if (watching) stopWatch()
        for (l in stateListeners) l()
    }

    // ---- interrupting Mark -----------------------------------------------------------------
    // In Mark-LVII the microphone is always open and the user simply talks over the answer. Here the mic is closed
    // while Mark speaks, so there are two ways in: the mic button (stop the answer and listen at once) and a stop word
    // spoken during the answer ("стоп", "хватит", "замолчи", …), watched by a recognizer that runs only while Mark speaks.

    /** Settings → "Перебивание голосом". */
    var interruptByVoice: Boolean
        get() = app.prefs.getBoolean("interrupt_voice", true)
        set(v) {
            app.prefs.edit().putBoolean("interrupt_voice", v).apply()
            if (!v) stopWatch()
        }

    private var watching = false

    private val stopWords = setOf(
        "стоп", "хватит", "замолчи", "молчи", "тихо", "стой", "подожди", "отмена", "достаточно", "хорош", "stop"
    )

    /** Only short phrases count, so a long sentence that merely contains the word (or Mark's own voice) does not. */
    private fun isStopPhrase(t: String): Boolean {
        val w = t.lowercase().split(Regex("[^\\p{L}]+")).filter { it.isNotEmpty() }
        return w.isNotEmpty() && w.size <= 4 && w.any { it in stopWords }
    }

    private fun recognizerIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, app.packageName)
    }

    private fun startWatch() {
        if (watching || !interruptByVoice || !hasPermission() || state != VState.SPEAKING) return
        if (!SpeechRecognizer.isRecognitionAvailable(app)) return
        watching = true
        try {
            val r = rec ?: SpeechRecognizer.createSpeechRecognizer(app).also {
                it.setRecognitionListener(listener)
                rec = it
            }
            r.startListening(recognizerIntent())
        } catch (e: Throwable) {
            watching = false
            app.log("Перебивание: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun stopWatch() {
        if (!watching) return
        watching = false
        try { rec?.destroy() } catch (ignored: Throwable) {}
        rec = null
    }

    /** Restart the stop-word watch while Mark is still speaking (a recognizer session lasts only a few seconds). */
    private fun rewatch() {
        watching = false
        try { rec?.destroy() } catch (ignored: Throwable) {}
        rec = null
        app.main.postDelayed({ if (state == VState.SPEAKING) startWatch() }, 500)
    }

    /** Stop the answer (spoken, or still being prepared) and listen at once; the conversation goes on. */
    fun interrupt() {
        if (!busy && state != VState.SPEAKING) return
        app.log("Перебили — слушаю")
        stopWatch()
        app.tts.stop()
        busy = false
        set(VState.IDLE)
        if (!continuous) {
            conversation = true
            lastPhrase = System.currentTimeMillis()
        }
        errStreak = 0
        app.main.postDelayed({ if (state == VState.IDLE && !busy) startInternal() }, 300)
    }

    /** The mic button: during an answer it interrupts; otherwise it starts / stops listening as before. */
    fun press(finished: (() -> Unit)? = null) {
        if ((state == VState.SPEAKING || state == VState.THINKING) && busy) {
            interrupt()
            return
        }
        if (state == VState.IDLE && !continuous) listenOnce(finished) else abort()
    }

    private fun conversationAlive(): Boolean =
        conversation && System.currentTimeMillis() - lastPhrase < CONVERSATION_MS

    /** The mic button pressed during a conversation, or the conversation ran out: close it and release the one-shot callback. */
    fun endConversation() {
        if (!conversation) return
        conversation = false
        errStreak = 0
        app.log("Микрофон: разговор окончен, выключен")
        try { rec?.cancel() } catch (ignored: Throwable) {}
        if (state == VState.LISTENING) set(VState.IDLE)
        finishOnce()
    }

    /** One phrase — and, after it, as long as the conversation lasts — then [finished] is called (overlay uses this to close itself). */
    fun listenOnce(finished: (() -> Unit)? = null) {
        if (conversation) {   // the button while the mic is on = turn it off
            endConversation()
            finished?.invoke()
            return
        }
        if (continuous || busy || state != VState.IDLE) {
            app.log("Уже занят (режим постоянного микрофона или идёт ответ)")
            finished?.invoke()
            return
        }
        onFinished = finished
        startInternal()
    }

    /** A typed command (text bar on the main screen): handled exactly like a recognised phrase. */
    fun submitText(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        if (busy) {
            app.log("Занят: дождитесь ответа")
            return
        }
        if (state == VState.LISTENING) {
            try {
                rec?.cancel()
            } catch (ignored: Throwable) {
            }
            set(VState.IDLE)
        }
        handle(t)
    }

    fun setContinuous(on: Boolean) {
        if (continuous == on) return
        continuous = on
        errStreak = 0
        app.log(if (on) "Микрофон постоянно: ВКЛ" else "Микрофон постоянно: ВЫКЛ")
        if (on) {
            try {
                KeepAliveService.start(app)
            } catch (e: Throwable) {
                app.log("Служба: ${e.message}")
            }
            if (!busy && state == VState.IDLE) startInternal()
        } else {
            try {
                KeepAliveService.stop(app)
            } catch (ignored: Throwable) {
            }
            if (state == VState.LISTENING) {
                rec?.cancel()
                set(VState.IDLE)
            }
        }
        set(state)
    }

    /** User pressed stop: cancel listening/speaking and leave continuous mode. */
    fun abort() {
        conversation = false
        if (continuous) setContinuous(false)
        rec?.cancel()
        app.tts.stop()
        busy = false
        onFinished = null
        set(VState.IDLE)
    }

    /** Overlay closed: drop a one-shot session, but keep continuous mode untouched. */
    fun cancelOneShot() {
        if (continuous) return
        conversation = false
        onFinished = null
        if (state == VState.LISTENING) {
            rec?.cancel()
            set(VState.IDLE)
        }
    }

    private fun finishOnce() {
        val f = onFinished
        onFinished = null
        f?.invoke()
    }

    private fun startInternal() {
        if (busy || state == VState.LISTENING) return
        if (!hasPermission()) {
            app.log("Нет разрешения на микрофон — откройте Mark TV и разрешите")
            finishOnce()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            app.log("SpeechRecognizer недоступен: на ТВ нет службы распознавания речи (приложение Google)")
            finishOnce()
            return
        }
        val r = rec ?: SpeechRecognizer.createSpeechRecognizer(app).also {
            it.setRecognitionListener(listener)
            rec = it
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, app.packageName)
        }
        set(VState.LISTENING)
        try {
            r.startListening(i)
        } catch (e: Throwable) {
            app.log("startListening: ${e.javaClass.simpleName}: ${e.message}")
            set(VState.IDLE)
            finishOnce()
        }
    }

    private fun handle(text: String, fromMic: Boolean = false) {
        app.log("Вы: $text")
        if (fromMic && !continuous) conversation = true
        lastPhrase = System.currentTimeMillis()
        errStreak = 0
        busy = true
        set(VState.THINKING)
        app.worker.execute {
            if (converseLive(text)) return@execute
            val reply = try {
                app.brain.ask(text)
            } catch (e: Throwable) {
                "Ошибка: ${e.message}"
            }
            app.main.post {
                val say = reply.ifBlank { "Пусто" }
                app.log("Mark: $say")
                if (say.length > 160 && System.currentTimeMillis() - app.shownAt > 15_000) {
                    app.showContent("Mark", say)
                }
                set(VState.SPEAKING)
                app.tts.speak(say) {
                    busy = false
                    set(VState.IDLE)
                    afterTurn()
                }
            }
        }
    }

    /**
     * The way Mark-LVII works: the text goes to Gemini Live, which answers with its own voice (the five voices of the
     * original) and runs the plugins as tools. Returns true when the turn was handled here; false = Live could not
     * be used (off, resting, error before anything happened), then the text model + system voice take over.
     * Runs on the worker thread.
     */
    /** After an answer: keep the mic on (continuous mode or a live conversation), otherwise finish the one-shot. */
    private fun afterTurn() {
        when {
            continuous -> startInternal()
            conversationAlive() -> startInternal()
            else -> { if (conversation) endConversation() else finishOnce() }
        }
    }

    private fun converseLive(text: String): Boolean {
        val g = app.tts.gem
        if (!g.enabled || app.apiKey.isEmpty() || g.pauseMinutes() > 0) return false
        val res = try {
            g.converse(text) { app.main.post { set(VState.SPEAKING) } }
        } catch (e: Throwable) {
            app.log("Gemini Live: ${e.javaClass.simpleName}: ${e.message}")
            return false
        }
        if (res.cancelled) return true
        if (!res.handled) return false
        app.main.post {
            val say = res.reply
            app.log("Mark: " + say.ifBlank { "(ответил голосом)" })
            if (say.length > 160 && System.currentTimeMillis() - app.shownAt > 15_000) {
                app.showContent("Mark", say)
            }
            busy = false
            set(VState.IDLE)
            afterTurn()
        }
        return true
    }

    private fun errName(e: Int): String = when (e) {
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "NETWORK_TIMEOUT"
        SpeechRecognizer.ERROR_NETWORK -> "NETWORK"
        SpeechRecognizer.ERROR_AUDIO -> "AUDIO (нет звука с микрофона)"
        SpeechRecognizer.ERROR_SERVER -> "SERVER"
        SpeechRecognizer.ERROR_CLIENT -> "CLIENT"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "SPEECH_TIMEOUT (тишина)"
        SpeechRecognizer.ERROR_NO_MATCH -> "NO_MATCH (не разобрал)"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "RECOGNIZER_BUSY"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "INSUFFICIENT_PERMISSIONS"
        else -> "код $e"
    }

    private fun onRecError(e: Int) {
        app.log("Распознавание: ошибка ${errName(e)}")
        set(VState.IDLE)
        if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            if (continuous) setContinuous(false)
            conversation = false
            finishOnce()
            return
        }
        if (e == SpeechRecognizer.ERROR_CLIENT || e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
            try {
                rec?.destroy()
            } catch (ignored: Throwable) {
            }
            rec = null
        }
        val silence = e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || e == SpeechRecognizer.ERROR_NO_MATCH
        if (conversation && !continuous && !conversationAlive()) { endConversation(); return }
        if (continuous || conversationAlive()) {
            // silence is normal while the TV is being watched; in a conversation only real errors count
            if (continuous || !silence) errStreak++
            if (errStreak >= 8) {
                app.log("Слишком много ошибок подряд — микрофон выключен")
                if (continuous) setContinuous(false)
                if (conversation) endConversation() else finishOnce()
                return
            }
            val delay = if (e == SpeechRecognizer.ERROR_CLIENT || e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 400L
            app.main.postDelayed({ if (continuous || conversationAlive()) startInternal() else if (conversation) endConversation() }, delay)
        } else {
            finishOnce()
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            if (watching) return
            app.log("Микрофон: готов, говорите")
        }

        override fun onBeginningOfSpeech() {
            if (watching) return
            app.log("Микрофон: речь пошла")
        }

        override fun onRmsChanged(rmsdB: Float) {
            if (watching) return
            rms = rmsdB
            for (l in levelListeners) l()
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            if (watching) return
            app.log("Микрофон: речь закончилась")
        }

        override fun onError(error: Int) {
            if (watching) {
                if (state == VState.SPEAKING) rewatch() else stopWatch()
                return
            }
            onRecError(error)
        }

        override fun onResults(results: Bundle?) {
            if (watching) {
                val w = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (isStopPhrase(w)) interrupt() else if (state == VState.SPEAKING) rewatch() else stopWatch()
                return
            }
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (t.isNullOrBlank()) onRecError(SpeechRecognizer.ERROR_NO_MATCH) else handle(t, true)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            if (watching) {
                val w = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (isStopPhrase(w)) interrupt()
                return
            }
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) for (l in partialListeners) l(t)
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }
}
