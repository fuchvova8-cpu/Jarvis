package com.marktv

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.concurrent.CopyOnWriteArrayList

enum class VState { IDLE, LISTENING, THINKING, SPEAKING }

/**
 * Voice loop: system SpeechRecognizer (the same engine Android TV search uses,
 * so it can take audio from the remote's microphone) -> Gemini (Python) -> TTS.
 * Everything here runs on the main thread.
 */
class Voice(private val app: App) {

    var state = VState.IDLE
        private set
    var continuous = false
        private set
    var rms = 0f
        private set

    val stateListeners = CopyOnWriteArrayList<() -> Unit>()
    val levelListeners = CopyOnWriteArrayList<() -> Unit>()
    val partialListeners = CopyOnWriteArrayList<(String) -> Unit>()

    private var rec: SpeechRecognizer? = null
    private var busy = false
    private var errStreak = 0
    private var onFinished: (() -> Unit)? = null

    fun hasPermission(): Boolean =
        app.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun set(s: VState) {
        state = s
        for (l in stateListeners) l()
    }

    /** One phrase, then [finished] is called (overlay uses this to close itself). */
    fun listenOnce(finished: (() -> Unit)? = null) {
        if (continuous || busy || state != VState.IDLE) {
            app.log("Уже занят (режим постоянного микрофона или идёт ответ)")
            finished?.invoke()
            return
        }
        onFinished = finished
        startInternal()
    }

    /** A typed command (text bar on the main screen): handled exactly like a recognised phrase. */
    fun submitText(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        if (busy) {
            app.log("Занят: дождитесь ответа")
            return
        }
        if (state == VState.LISTENING) {
            try {
                rec?.cancel()
            } catch (ignored: Throwable) {
            }
            set(VState.IDLE)
        }
        handle(t)
    }

    fun setContinuous(on: Boolean) {
        if (continuous == on) return
        continuous = on
        errStreak = 0
        app.log(if (on) "Микрофон постоянно: ВКЛ" else "Микрофон постоянно: ВЫКЛ")
        if (on) {
            try {
                KeepAliveService.start(app)
            } catch (e: Throwable) {
                app.log("Служба: ${e.message}")
            }
            if (!busy && state == VState.IDLE) startInternal()
        } else {
            try {
                KeepAliveService.stop(app)
            } catch (ignored: Throwable) {
            }
            if (state == VState.LISTENING) {
                rec?.cancel()
                set(VState.IDLE)
            }
        }
        set(state)
    }

    /** User pressed stop: cancel listening/speaking and leave continuous mode. */
    fun abort() {
        if (continuous) setContinuous(false)
        rec?.cancel()
        app.tts.stop()
        busy = false
        onFinished = null
        set(VState.IDLE)
    }

    /** Overlay closed: drop a one-shot session, but keep continuous mode untouched. */
    fun cancelOneShot() {
        if (continuous) return
        onFinished = null
        if (state == VState.LISTENING) {
            rec?.cancel()
            set(VState.IDLE)
        }
    }

    private fun finishOnce() {
        val f = onFinished
        onFinished = null
        f?.invoke()
    }

    private fun startInternal() {
        if (busy || state == VState.LISTENING) return
        if (!hasPermission()) {
            app.log("Нет разрешения на микрофон — откройте Mark TV и разрешите")
            finishOnce()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            app.log("SpeechRecognizer недоступен: на ТВ нет службы распознавания речи (приложение Google)")
            finishOnce()
            return
        }
        val r = rec ?: SpeechRecognizer.createSpeechRecognizer(app).also {
            it.setRecognitionListener(listener)
            rec = it
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, app.packageName)
        }
        set(VState.LISTENING)
        try {
            r.startListening(i)
        } catch (e: Throwable) {
            app.log("startListening: ${e.javaClass.simpleName}: ${e.message}")
            set(VState.IDLE)
            finishOnce()
        }
    }

    private fun handle(text: String) {
        app.log("Вы: $text")
        errStreak = 0
        busy = true
        set(VState.THINKING)
        app.worker.execute {
            val reply = try {
                app.brain.ask(text)
            } catch (e: Throwable) {
                "Ошибка: ${e.message}"
            }
            app.main.post {
                val say = reply.ifBlank { "Пусто" }
                app.log("Mark: $say")
                if (say.length > 160 && System.currentTimeMillis() - app.shownAt > 15_000) {
                    app.showContent("Mark", say)
                }
                set(VState.SPEAKING)
                app.tts.speak(say) {
                    busy = false
                    set(VState.IDLE)
                    if (continuous) startInternal() else finishOnce()
                }
            }
        }
    }

    private fun errName(e: Int): String = when (e) {
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "NETWORK_TIMEOUT"
        SpeechRecognizer.ERROR_NETWORK -> "NETWORK"
        SpeechRecognizer.ERROR_AUDIO -> "AUDIO (нет звука с микрофона)"
        SpeechRecognizer.ERROR_SERVER -> "SERVER"
        SpeechRecognizer.ERROR_CLIENT -> "CLIENT"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "SPEECH_TIMEOUT (тишина)"
        SpeechRecognizer.ERROR_NO_MATCH -> "NO_MATCH (не разобрал)"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "RECOGNIZER_BUSY"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "INSUFFICIENT_PERMISSIONS"
        else -> "код $e"
    }

    private fun onRecError(e: Int) {
        app.log("Распознавание: ошибка ${errName(e)}")
        set(VState.IDLE)
        if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            if (continuous) setContinuous(false)
            finishOnce()
            return
        }
        if (e == SpeechRecognizer.ERROR_CLIENT || e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
            try {
                rec?.destroy()
            } catch (ignored: Throwable) {
            }
            rec = null
        }
        if (continuous) {
            errStreak++
            if (errStreak >= 8) {
                app.log("Слишком много ошибок подряд — постоянный микрофон выключен")
                setContinuous(false)
                finishOnce()
                return
            }
            val delay = if (e == SpeechRecognizer.ERROR_CLIENT || e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 400L
            app.main.postDelayed({ if (continuous) startInternal() }, delay)
        } else {
            finishOnce()
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            app.log("Микрофон: готов, говорите")
        }

        override fun onBeginningOfSpeech() {
            app.log("Микрофон: речь пошла")
        }

        override fun onRmsChanged(rmsdB: Float) {
            rms = rmsdB
            for (l in levelListeners) l()
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            app.log("Микрофон: речь закончилась")
        }

        override fun onError(error: Int) {
            onRecError(error)
        }

        override fun onResults(results: Bundle?) {
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (t.isNullOrBlank()) onRecError(SpeechRecognizer.ERROR_NO_MATCH) else handle(t)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) for (l in partialListeners) l(t)
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }
}
