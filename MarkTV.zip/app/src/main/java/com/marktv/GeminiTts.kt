package com.marktv

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors

/**
 * Speaks with Gemini's neural voices (generateContent with AUDIO output) and plays the PCM through AudioTrack.
 * The text is cut into sentence chunks that are fetched in parallel and played in order.
 * Any failure is reported to the caller (done(false)) so it can fall back to the system TTS.
 */
class GeminiTts(private val app: App) {

    companion object {
        const val DEFAULT_VOICE = "Charon"
        const val DEFAULT_MODEL = "gemini-3.8-flash-tts"
        private val MODEL_FALLBACKS = listOf("gemini-3.8-flash-lite-tts", "gemini-2.5-flash-preview-tts")
        private const val RATE = 24000
        private const val CHUNK = 450
        private const val MAX_CHUNKS = 8

        /** name to short style note (from Google's docs). */
        val VOICES: List<Pair<String, String>> = listOf(
            "Zephyr" to "Bright", "Puck" to "Upbeat", "Charon" to "Informative", "Kore" to "Firm",
            "Fenrir" to "Excitable", "Leda" to "Youthful", "Orus" to "Firm", "Aoede" to "Breezy",
            "Callirrhoe" to "Easy-going", "Autonoe" to "Bright", "Enceladus" to "Breathy", "Iapetus" to "Clear",
            "Umbriel" to "Easy-going", "Algieba" to "Smooth", "Despina" to "Smooth", "Erinome" to "Clear",
            "Algenib" to "Gravelly", "Rasalgethi" to "Informative", "Laomedeia" to "Upbeat", "Achernar" to "Soft",
            "Alnilam" to "Firm", "Schedar" to "Even", "Gacrux" to "Mature", "Pulcherrima" to "Forward",
            "Achird" to "Friendly", "Zubenelgenubi" to "Casual", "Vindemiatrix" to "Gentle", "Sadachbia" to "Lively",
            "Sadaltager" to "Knowledgeable", "Sulafat" to "Warm"
        )
    }

    /** Use Gemini voices (true by default); false = system TTS only. */
    var enabled: Boolean
        get() = app.prefs.getBoolean("gem_tts", true)
        set(v) { app.prefs.edit().putBoolean("gem_tts", v).apply() }

    var voice: String
        get() = app.prefs.getString("gem_tts_voice", DEFAULT_VOICE) ?: DEFAULT_VOICE
        set(v) { app.prefs.edit().putString("gem_tts_voice", v.ifBlank { DEFAULT_VOICE }).apply() }

    var model: String
        get() = app.prefs.getString("gem_tts_model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) { app.prefs.edit().putString("gem_tts_model", v.trim().ifEmpty { DEFAULT_MODEL }).apply() }

    private val fetchPool = Executors.newFixedThreadPool(2)
    private val playPool = Executors.newSingleThreadExecutor()
    @Volatile private var gen = 0
    /** 0 = request shape from the current docs (voiceConfig.voice), 1 = older shape (prebuiltVoiceConfig.voiceName). */
    @Volatile private var shape = 0

    /** Cancels whatever is being fetched/played. No callback is made for a cancelled speech. */
    fun stop() {
        gen++
    }

    /** [done] runs on the main thread: true = finished (or partly played), false = nothing was played, use another voice. */
    fun speak(text: String, done: (Boolean) -> Unit) {
        val my = ++gen
        val chunks = split(clean(text))
        if (chunks.isEmpty()) {
            app.main.post { done(true) }
            return
        }
        playPool.execute {
            var played = false
            try {
                val futures = chunks.map { c -> fetchPool.submit(Callable { fetch(c) }) }
                for (f in futures) {
                    if (gen != my) return@execute
                    val pcm = f.get()
                    if (gen != my) return@execute
                    play(pcm, my)
                    played = true
                }
                if (gen == my) app.main.post { done(true) }
            } catch (e: Throwable) {
                if (gen != my) return@execute
                val c = (e as? ExecutionException)?.cause ?: e
                app.log("Gemini TTS: ${c.javaClass.simpleName}: ${c.message}")
                app.main.post { done(played) }
            }
        }
    }

    // ---- text -----------------------------------------------------------------------------

    private fun clean(s: String): String =
        s.replace(Regex("[*_`#>]+"), " ").replace(Regex("\\s+"), " ").trim()

    private fun split(text: String): List<String> {
        if (text.isEmpty()) return emptyList()
        val out = ArrayList<String>()
        val sb = StringBuilder()
        fun flush() {
            if (sb.isNotBlank()) out.add(sb.toString().trim())
            sb.setLength(0)
        }
        for (sentence in text.split(Regex("(?<=[.!?…])\\s+"))) {
            var s = sentence
            while (s.length > CHUNK) {
                var cut = s.lastIndexOf(' ', CHUNK)
                if (cut < CHUNK / 2) cut = CHUNK
                if (sb.isNotEmpty()) flush()
                out.add(s.substring(0, cut).trim())
                s = s.substring(cut).trim()
            }
            if (sb.length + s.length + 1 > CHUNK) flush()
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(s)
        }
        flush()
        return if (out.size > MAX_CHUNKS) out.subList(0, MAX_CHUNKS) else out
    }

    // ---- network --------------------------------------------------------------------------

    private class Reply(val code: Int, val text: String)

    private fun body(text: String, shape: Int): String {
        val voiceCfg = if (shape == 0) JSONObject().put("voice", voice)
        else JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice))
        return JSONObject()
            .put("contents", org.json.JSONArray().put(
                JSONObject().put("role", "user").put("parts", org.json.JSONArray().put(JSONObject().put("text", text)))
            ))
            .put("generationConfig", JSONObject()
                .put("responseModalities", org.json.JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", voiceCfg)))
            .toString()
    }

    private fun post(m: String, text: String, shape: Int): Reply {
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent")
            .openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", app.apiKey)
            c.outputStream.use { it.write(body(text, shape).toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Reply(code, txt)
        } finally {
            c.disconnect()
        }
    }

    private fun errText(r: Reply): String {
        val msg = try {
            JSONObject(r.text).optJSONObject("error")?.optString("message") ?: ""
        } catch (e: Throwable) {
            ""
        }
        return "HTTP ${r.code}: ${msg.ifEmpty { r.text.take(160) }}"
    }

    /** Returns 16-bit mono PCM at 24 kHz for one chunk of text. */
    private fun fetch(text: String): ByteArray {
        var last = "нет ответа"
        val models = listOf(model) + MODEL_FALLBACKS.filter { it != model }
        for (m in models) {
            val shapes = if (shape == 0) listOf(0, 1) else listOf(1, 0)
            for (sh in shapes) {
                val r = post(m, text, sh)
                if (r.code in 200..299) {
                    val pcm = pcmOf(r.text)
                    if (pcm.isNotEmpty()) {
                        shape = sh
                        if (m != model) {
                            app.log("Gemini TTS: модель $model недоступна, использую $m")
                            model = m
                        }
                        return pcm
                    }
                    last = "в ответе нет аудио"
                    continue
                }
                last = "$m: " + errText(r)
                if (r.code == 404) break           // unknown model: try the next one
                if (r.code == 400) continue        // maybe the other request shape
                throw IOException(last)            // key / quota / server problems: another model will not help
            }
        }
        throw IOException(last)
    }

    private fun pcmOf(json: String): ByteArray {
        val part = JSONObject(json).optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0) ?: return ByteArray(0)
        val inline = part.optJSONObject("inlineData") ?: part.optJSONObject("inline_data") ?: return ByteArray(0)
        val b64 = inline.optString("data")
        if (b64.isEmpty()) return ByteArray(0)
        val raw = Base64.decode(b64, Base64.DEFAULT)
        // The docs say unary replies are WAV (RIFF header); raw L16 PCM is handled too.
        if (raw.size > 44 && raw[0] == 'R'.code.toByte() && raw[1] == 'I'.code.toByte() &&
            raw[2] == 'F'.code.toByte() && raw[3] == 'F'.code.toByte()) {
            var i = 12
            while (i + 8 <= raw.size) {
                val id = String(raw, i, 4, Charsets.ISO_8859_1)
                val size = (raw[i + 4].toInt() and 0xFF) or ((raw[i + 5].toInt() and 0xFF) shl 8) or
                    ((raw[i + 6].toInt() and 0xFF) shl 16) or ((raw[i + 7].toInt() and 0xFF) shl 24)
                if (id == "data") {
                    val start = i + 8
                    val end = if (size <= 0 || start + size > raw.size) raw.size else start + size
                    return raw.copyOfRange(start, end)
                }
                if (size < 0) break
                i += 8 + size + (size and 1)
            }
            return raw.copyOfRange(44, raw.size)
        }
        return raw
    }

    // ---- playback -------------------------------------------------------------------------

    private fun play(pcm: ByteArray, my: Int) {
        if (pcm.isEmpty()) return
        val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(min, 16384))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        try {
            t.play()
            var off = 0
            while (off < pcm.size && gen == my) {
                // Non-blocking, so a stop() (gen change) is noticed within ~10 ms.
                val n = t.write(pcm, off, minOf(4096, pcm.size - off), AudioTrack.WRITE_NON_BLOCKING)
                if (n < 0) throw IOException("AudioTrack.write: $n")
                if (n == 0) Thread.sleep(10) else off += n
            }
            val frames = pcm.size / 2
            val limit = System.currentTimeMillis() + frames * 1000L / RATE + 3000
            while (gen == my && t.playbackHeadPosition < frames && System.currentTimeMillis() < limit) {
                Thread.sleep(30)
            }
        } finally {
            try {
                t.pause()
                t.flush()
            } catch (ignored: Throwable) {
            }
            t.release()
        }
    }
}
