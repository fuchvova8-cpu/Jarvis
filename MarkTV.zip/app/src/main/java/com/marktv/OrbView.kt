package com.marktv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.View
import kotlin.math.min

/** The microphone "orb": focusable, clickable with OK on the remote, colour shows the state. */
class OrbView(ctx: Context) : View(ctx) {

    var vstate: VState = VState.IDLE
        set(v) {
            field = v
            invalidate()
        }

    var level: Float = 0f
        set(v) {
            field = v
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    init {
        isFocusable = true
        isClickable = true
    }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) / 2f * 0.6f
        val col = when (vstate) {
            VState.IDLE -> 0xFF3A6EA5.toInt()
            VState.LISTENING -> 0xFFD32F2F.toInt()
            VState.THINKING -> 0xFFF9A825.toInt()
            VState.SPEAKING -> 0xFF2E7D32.toInt()
        }
        paint.style = Paint.Style.FILL
        if (vstate == VState.LISTENING) {
            val k = (level.coerceIn(0f, 10f)) / 10f
            paint.color = col
            paint.alpha = 70
            c.drawCircle(cx, cy, base * (1f + 0.35f * k), paint)
        }
        paint.alpha = 255
        paint.color = col
        c.drawCircle(cx, cy, base, paint)

        // microphone glyph
        paint.color = 0xFFFFFFFF.toInt()
        val w = base * 0.38f
        val h = base * 0.75f
        rect.set(cx - w / 2, cy - h / 2 - base * 0.1f, cx + w / 2, cy + h / 2 - base * 0.1f)
        c.drawRoundRect(rect, w / 2, w / 2, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = base * 0.07f
        val r = base * 0.42f
        rect.set(cx - r, cy - r * 0.9f, cx + r, cy + r * 0.9f)
        c.drawArc(rect, 20f, 140f, false, paint)
        c.drawLine(cx, cy + r * 0.9f, cx, cy + base * 0.62f, paint)

        if (isFocused) {
            paint.color = 0xFFFFFFFF.toInt()
            paint.strokeWidth = base * 0.06f
            c.drawCircle(cx, cy, base * 1.12f, paint)
        }
        paint.style = Paint.Style.FILL
    }
}
