package com.marktv

import android.app.Application
import android.content.Intent
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

class App : Application() {

    val main = Handler(Looper.getMainLooper())
    val worker = Executors.newSingleThreadExecutor()

    lateinit var prefs: SharedPreferences
    lateinit var tts: Tts
    lateinit var voice: Voice
    lateinit var brain: Brain
    lateinit var keys: KeyInjector

    private val lines = ArrayDeque<String>()
    private val logListeners = CopyOnWriteArrayList<(String) -> Unit>()
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    val logFile: File by lazy { File(getExternalFilesDir(null) ?: filesDir, "marktv.log") }

    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(v) {
            val old = prefs.getString("api_key", "") ?: ""
            prefs.edit().putString("api_key", v.trim()).apply()
            // core/gemini.api_key(): what a model answered to the old key says nothing about the new one.
            if (old != v.trim()) try { tts.gem.clearPause() } catch (e: Throwable) {}
        }

    var accent: String
        get() = prefs.getString("accent", Hud.DEFAULT_ACCENT) ?: Hud.DEFAULT_ACCENT
        set(v) { prefs.edit().putString("accent", v).apply() }


    override fun onCreate() {
        super.onCreate()
        inst = this
        prefs = getSharedPreferences("marktv", MODE_PRIVATE)
        Hud.applyAccent(accent)
        try {
            if (logFile.exists() && logFile.length() > 500_000) logFile.delete()
        } catch (ignored: Throwable) {
        }
        tts = Tts(this)
        voice = Voice(this)
        brain = Brain(this)
        keys = KeyInjector(this)
        log("Mark TV запущен")
    }

    /** Standard plugins folder (…/Android/data/com.marktv/files/plugins). */
    fun defaultPluginsDir(): File {
        val d = File(getExternalFilesDir(null) ?: filesDir, "plugins")
        d.mkdirs()
        return d
    }

    /** Folder chosen in the Service menu, or "" for the standard one. */
    var customPluginsDir: String
        get() = prefs.getString("plugins_dir", "") ?: ""
        set(v) { prefs.edit().putString("plugins_dir", v.trim()).apply() }

    private var warnedDir = ""

    /** The folder plugins are loaded from: the custom one when it is usable, otherwise the standard one. */
    fun pluginsDir(): File {
        val custom = customPluginsDir
        if (custom.isNotEmpty()) {
            val d = File(custom)
            try {
                d.mkdirs()
            } catch (ignored: Throwable) {
            }
            if (d.isDirectory && d.canRead()) return d
            if (warnedDir != custom) {
                warnedDir = custom
                log("Папка плагинов недоступна: $custom — пока используется стандартная (нужно разрешение на файлы?)")
            }
        }
        return defaultPluginsDir()
    }

    /** Copies *.py files that are missing in [to]. Returns how many were copied. */
    fun copyPlugins(from: File, to: File): Int {
        var n = 0
        try {
            to.mkdirs()
            for (f in from.listFiles { x -> x.isFile && x.name.endsWith(".py") } ?: emptyArray()) {
                val t = File(to, f.name)
                if (!t.exists()) {
                    f.copyTo(t)
                    n++
                }
            }
        } catch (e: Throwable) {
            log("Копирование плагинов: ${e.javaClass.simpleName}: ${e.message}")
        }
        return n
    }

    fun log(msg: String) {
        val line = timeFmt.format(Date()) + "  " + msg
        android.util.Log.i("MarkTV", msg)
        synchronized(lines) {
            lines.addLast(line)
            while (lines.size > 400) lines.removeFirst()
        }
        try {
            logFile.appendText(line + "\n")
        } catch (ignored: Throwable) {
        }
        main.post { for (l in logListeners) l(line) }
    }

    fun history(): List<String> = synchronized(lines) { lines.toList() }

    fun addLogListener(l: (String) -> Unit) {
        logListeners.add(l)
    }

    fun removeLogListener(l: (String) -> Unit) {
        logListeners.remove(l)
    }

    @Volatile var lastTitle = ""
    @Volatile var lastText = ""
    /** JSON array of poster cards (title, sub, image, cmd, app); empty = plain text mode. */
    @Volatile var lastResults = ""
    @Volatile var shownAt = 0L
    @Volatile var adbProbed = false

    /** Puts a title and text on the TV screen (ResultsActivity). Safe to call from any thread. */
    fun showContent(title: String, text: String) {
        lastResults = ""
        lastTitle = title
        lastText = text
        shownAt = System.currentTimeMillis()
        openResults(title)
    }

    /**
     * Opens a title like the system search does, from inside the app (startActivity), trying each variant in turn.
     * [json] = [{name, action, data, comp, pkg, extras:{k:v}}]. Returns "ok:<variant>" or "ERR: ...".
     */
    fun openIntents(title: String, json: String): String {
        val arr = try { org.json.JSONArray(json) } catch (e: Throwable) { return "ERR: bad json" }
        var last = "нет вариантов"
        for (n in 0 until arr.length()) {
            val o = arr.getJSONObject(n)
            val name = o.optString("name")
            try {
                val i = Intent()
                o.optString("action").takeIf { it.isNotEmpty() }?.let { i.action = it }
                o.optString("data").takeIf { it.isNotEmpty() }?.let { i.data = android.net.Uri.parse(it) }
                val comp = o.optString("comp")
                val pkg = o.optString("pkg")
                if (comp.isNotEmpty()) android.content.ComponentName.unflattenFromString(comp)?.let { i.component = it }
                else if (pkg.isNotEmpty()) i.setPackage(pkg)
                o.optJSONObject("extras")?.let { ex ->
                    for (k in ex.keys()) i.putExtra(k, ex.getString(k))
                }
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                log("Открыто «$title»: вариант $name (${i.toUri(0)})")
                return "ok:$name"
            } catch (e: Throwable) {
                last = "$name: ${e.javaClass.simpleName}: ${e.message}"
                log("Открыть «$title»: $last")
            }
        }
        return "ERR: $last"
    }

    /** Card tapped: in-app intents first, then shell commands as a fallback. Shows a toast with the outcome. */
    fun openCard(title: String, intentsJson: String, cmds: List<String>) {
        worker.execute {
            var res = if (intentsJson.isNotEmpty() && intentsJson != "[]") openIntents(title, intentsJson) else "ERR: -"
            if (res.startsWith("ERR")) {
                for (c in cmds) {
                    val out = keys.shell(c)
                    log("Открыть «$title»: $c → $out")
                    val low = out.lowercase()
                    val bad = out.startsWith("ADB:") || low.contains("error") || low.contains("unable to resolve") ||
                        low.contains("does not exist") || low.contains("exception") || low.contains("permission denial")
                    if (!bad) { res = "ok:shell"; break }
                    res = "ERR: ${out.take(100)}"
                }
            }
            val ok = res.startsWith("ok")
            main.post {
                Toast.makeText(this, if (ok) "Открываю: $title" else "Не открылось: ${res.take(140)}", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Shows poster cards (ResultsActivity grid). [json] is an array of objects, see ResultsActivity. */
    fun showResults(title: String, json: String) {
        lastTitle = title
        lastText = ""
        lastResults = json
        shownAt = System.currentTimeMillis()
        openResults(title)
    }

    private fun openResults(title: String) {
        log("На экран: $title")
        main.post {
            try {
                val i = Intent(this, ResultsActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                startActivity(i)
            } catch (e: Throwable) {
                log("Не удалось открыть экран результатов: ${e.message}")
            }
        }
    }

    companion object {
        lateinit var inst: App
    }
}
