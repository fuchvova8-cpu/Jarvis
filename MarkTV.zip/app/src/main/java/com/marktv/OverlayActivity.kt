package com.marktv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Translucent "listen once" window for use on top of the TV player.
 * Bind it to a remote button with TV Quick Actions.
 */
open class OverlayActivity : Activity() {

    /** true: the strip toggles "microphone always on" and stays while it is on (no one-shot listening). */
    protected open val continuousMode: Boolean = false

    private lateinit var app: App
    private lateinit var core: JarvisView
    private lateinit var text: TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private val stateListener: () -> Unit = {
        core.vstate = app.voice.state
        if (app.voice.state == VState.LISTENING) {
            text.setTextColor(Hud.TEXT)
            text.text = "Слушаю…"
        } else if (continuousMode && !app.voice.continuous) {
            finish()
        } else if (app.voice.state == VState.THINKING) {
            text.setTextColor(Hud.AMBER)
            text.text = "Анализ…"
        }
    }
    private val levelListener: () -> Unit = { core.level = app.voice.rms }
    private val partialListener: (String) -> Unit = { text.text = it }
    private val logListener: (String) -> Unit = { line ->
        val i = line.indexOf("Mark: ")
        if (i >= 0) {
            text.setTextColor(Hud.CYAN)
            text.text = line.substring(i + 6)
        } else if (line.contains("ошибка") || line.contains("Нет разрешения") || line.contains("недоступен")) {
            text.setTextColor(Hud.AMBER)
            text.text = line.substring(minOf(line.length, 10))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = application as App
        MicGuard.allow()

        if (!app.voice.hasPermission()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        if (continuousMode) {
            if (app.voice.continuous) {
                app.voice.setContinuous(false)
                finish()
                return
            }
            app.voice.setContinuous(true)
        }

        val root = FrameLayout(this)
        val panel = HudPanel(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(24), dp(10))
        }
        core = JarvisView(this)
        panel.addView(core, LinearLayout.LayoutParams(dp(110), dp(110)))
        text = TextView(this).apply {
            textSize = 22f
            setTextColor(Hud.TEXT)
            this.text = "Слушаю…"
            maxLines = 4
        }
        panel.addView(text, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(14)
        })
        root.addView(
            panel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
            ).apply {
                marginStart = dp(40)
                marginEnd = dp(40)
                bottomMargin = dp(28)
            }
        )
        setContentView(root)

        app.addLogListener(logListener)
        app.voice.stateListeners.add(stateListener)
        app.voice.levelListeners.add(levelListener)
        app.voice.partialListeners.add(partialListener)

        if (!continuousMode) {
            app.voice.listenOnce { finish() }
            // safety net: never hang on screen
            app.main.postDelayed({ if (!isFinishing) finish() }, 60_000)
        }
    }

    /** singleTask: a second press of the launcher entry arrives here, not in onCreate. */
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (!::app.isInitialized) return
        // some remotes / Quick Actions deliver the same press twice: ignore a repeat right after start
        if (!MicGuard.allow()) return
        if (continuousMode) {
            app.voice.setContinuous(false)
        } else {
            app.voice.abort()
        }
        finish()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && e.keyCode == KeyEvent.KEYCODE_BACK) {
            app.voice.abort()
            finish()
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onDestroy() {
        if (::app.isInitialized) {
            app.removeLogListener(logListener)
            app.voice.stateListeners.remove(stateListener)
            app.voice.levelListeners.remove(levelListener)
            app.voice.partialListeners.remove(partialListener)
            app.voice.cancelOneShot()
        }
        super.onDestroy()
    }
}
