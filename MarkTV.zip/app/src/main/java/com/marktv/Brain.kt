package com.marktv

import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

/** Thin wrapper around the Python core (app/src/main/python/brain.py). Call from worker threads only. */
class Brain(private val app: App) {

    private var mod: PyObject? = null

    @Synchronized
    private fun module(): PyObject {
        mod?.let { return it }
        if (!Python.isStarted()) Python.start(AndroidPlatform(app))
        val m = Python.getInstance().getModule("brain")
        m.callAttr("set_host", Host(app))
        mod = m
        app.log("Python запущен")
        return m
    }

    private fun configured(): PyObject {
        val m = module()
        m.callAttr("configure", app.apiKey, app.model, app.pluginsDir().absolutePath)
        return m
    }

    fun ask(text: String): String = configured().callAttr("ask", text).toString()

    // ---- Gemini Live as the brain (GeminiTts.converse) ----

    /** JSON {system, tools}: the system prompt (with recent dialogue) and the plugin function declarations. */
    fun liveContext(): String = configured().callAttr("live_context").toString()

    /** Runs a plugin as a Live tool call; returns the text result for the toolResponse. */
    fun liveTool(name: String, argsJson: String): String = configured().callAttr("live_tool", name, argsJson).toString()

    /** screen_process: JSON {mime, data, text} of a captured frame to send into the session after the tool response, or "". */
    fun livePendingVision(): String = configured().callAttr("live_pending_vision").toString()

    /** Stores the exchange so the text fallback keeps the context. */
    fun liveNote(user: String, reply: String) {
        configured().callAttr("live_note", user, reply)
    }

    /** After-turn hook for plugins that wrap ask() (ultron). */
    fun liveTurnEnd() {
        configured().callAttr("live_turn_end")
    }

    /** JSON [{name, title}] of plugins that have a settings page. */
    fun pluginSettingsList(): String = configured().callAttr("plugin_settings_list").toString()

    /** JSON list of settings items of one plugin (see brain.py). */
    fun pluginSettingsItems(name: String): String = configured().callAttr("plugin_settings_items", name).toString()

    /** Sends a button press / "__leave__" with all field values; returns JSON {message, refresh}. */
    fun pluginSettingsEvent(name: String, event: String, valuesJson: String): String =
        configured().callAttr("plugin_settings_event", name, event, valuesJson).toString()

    fun describePlugins(): String = configured().callAttr("describe_plugins").toString()
}
