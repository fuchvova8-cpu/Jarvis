package com.marktv

import android.app.SearchManager
import android.app.SearchableInfo
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** The object Python plugins talk to (android_bridge.py wraps it). Methods are called from a worker thread. */
class Host(private val app: App) {

    fun log(msg: String) {
        app.log("плагин: $msg")
    }

    fun speak(text: String) {
        app.main.post { app.tts.speak(text) }
    }

    fun showContent(title: String, text: String) {
        app.showContent(title, text)
    }

    fun showResults(title: String, json: String) {
        app.showResults(title, json)
    }

    /** Opens a title from inside the app (see App.openIntents). Returns "ok:<variant>" or "ERR: ...". */
    fun openIntents(title: String, json: String): String = app.openIntents(title, json)

    fun key(code: Int): String = app.keys.key(code)

    fun shell(cmd: String): String = app.keys.shell(cmd)

    /** screen_process: the original's _compress (PNG -> JPEG, scaled to fit maxW x maxH). Returns "ok" or "ERR: ...". */
    fun compressImage(src: String, dst: String, maxW: Int, maxH: Int, quality: Int): String {
        return try {
            val bmp = android.graphics.BitmapFactory.decodeFile(src) ?: return "ERR: decode"
            val k = minOf(maxW.toDouble() / bmp.width, maxH.toDouble() / bmp.height, 1.0)
            val out = if (k < 1.0)
                android.graphics.Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true)
            else bmp
            java.io.FileOutputStream(dst).use { out.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality, it) }
            if (out !== bmp) out.recycle()
            bmp.recycle()
            "ok"
        } catch (e: Throwable) {
            "ERR: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    /** Side call through a throwaway Live session (core/gemini.py). Returns the text or "ERR: ...". */
    fun liveOneShot(prompt: String, system: String, imageB64: String, imageMime: String, timeoutMs: Long): String =
        app.tts.gem.oneShot(prompt, system, imageB64, imageMime, timeoutMs)

    /** interface_color tool: set the accent live (as the hex box in Service does) and repaint the visible screen. */
    fun setAccent(hex: String): String {
        if (!Hud.applyAccent(hex)) return "ERR: нужен формат #rrggbb"
        app.accent = Hud.accentHex
        Hud.onChange?.run()
        return "ok"
    }

    fun pluginsDir(): String = app.pluginsDir().absolutePath

    /** Private folder for plugin data: survives a change of the plugins folder. */
    fun dataDir(): String = app.filesDir.absolutePath

    /** Launchable apps as JSON: [{pkg, label, tv}]. TV apps (Leanback launcher) first. */
    fun listApps(): String {
        val pm = app.packageManager
        val out = JSONArray()
        val seen = HashSet<String>()
        fun add(category: String, tv: Boolean) {
            val i = android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(i, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == app.packageName || !seen.add(pkg)) continue
                val o = JSONObject()
                o.put("pkg", pkg)
                o.put("label", ri.loadLabel(pm).toString())
                o.put("tv", tv)
                out.put(o)
            }
        }
        add(android.content.Intent.CATEGORY_LEANBACK_LAUNCHER, true)
        add(android.content.Intent.CATEGORY_LAUNCHER, false)
        return out.toString()
    }

    /** Starts an app from inside Mark TV (TV launcher first). Returns "ok" or "ERR: ...". */
    fun launchApp(pkg: String): String {
        return try {
            val pm = app.packageManager
            val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
            if (i == null) {
                "ERR: у приложения нет значка запуска"
            } else {
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                app.startActivity(i)
                "ok"
            }
        } catch (e: Throwable) {
            "ERR: ${describe(e)}"
        }
    }

    /** Description of a search provider as declared in the app's searchable.xml. */
    private class Spec(
        val pkg: String,
        val path: String,
        val selection: String?,
        val action: String?,
        val data: String?,
        val comp: String? = null
    )

    private val specs = java.util.concurrent.ConcurrentHashMap<String, Spec>()

    private fun describe(e: Throwable): String {
        val sb = StringBuilder("${e.javaClass.simpleName}: ${e.message}")
        var c = e.cause
        var n = 0
        while (c != null && n < 2) {
            sb.append(" <- ${c.javaClass.simpleName}: ${c.message}")
            c = c.cause
            n++
        }
        return sb.toString()
    }

    /** Same as the system global search: SearchManager.getSearchablesInGlobalSearch() (hidden API, via reflection). */
    @Suppress("UNCHECKED_CAST")
    private fun scanSearchManager() {
        val sm = app.getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val m = SearchManager::class.java.getMethod("getSearchablesInGlobalSearch")
        val list = m.invoke(sm) as? List<SearchableInfo> ?: return
        for (si in list) {
            val auth = si.suggestAuthority ?: continue
            val pkg = si.searchActivity?.packageName ?: continue
            specs[auth] = Spec(pkg, si.suggestPath ?: "", si.suggestSelection, si.suggestIntentAction, si.suggestIntentData,
                si.searchActivity?.flattenToString())
        }
    }

    /** Fallback when the hidden API is blocked: exported providers whose authority looks like search. */
    @Suppress("DEPRECATION")
    private fun scanPackages() {
        val pm = app.packageManager
        for (ai in pm.getInstalledApplications(0)) {
            val pi = try {
                pm.getPackageInfo(ai.packageName, PackageManager.GET_PROVIDERS)
            } catch (e: Throwable) {
                continue
            }
            for (pr in pi.providers ?: continue) {
                val auth = pr.authority ?: continue
                if (!pr.exported) continue
                if (!(auth.contains("search", true) || auth.contains("suggest", true))) continue
                for (a in auth.split(";")) if (!specs.containsKey(a)) specs[a] = Spec(ai.packageName, "", null, null, null)
            }
        }
    }

    /** Search providers of installed apps, one "authority|package" per line, or "ERR: ..." on failure. */
    fun searchProviders(): String {
        specs.clear()
        try {
            scanSearchManager()
        } catch (e: Throwable) {
            app.log("Провайдеры: SearchManager недоступен (${describe(e)}), сканирую пакеты")
        }
        try {
            scanPackages()
        } catch (e: Throwable) {
            if (specs.isEmpty()) return "ERR: ${describe(e)}"
        }
        val out = StringBuilder()
        for ((a, sp) in specs) out.append(a).append('|').append(sp.pkg).append('\n')
        app.log("Провайдеров поиска: ${specs.size}")
        return out.toString()
    }

    /**
     * Queries a provider exactly as the system search does (path / selection from its searchable.xml).
     * Returns a JSON array of rows (column -> text), or "ERR: ..." with the full exception.
     */
    fun searchQuery(authority: String, query: String, limit: Int): String {
        val sp = specs[authority] ?: Spec("", "", null, null, null)
        return try {
            val b = Uri.Builder().scheme("content").authority(authority)
            if (sp.path.isNotEmpty()) b.appendEncodedPath(sp.path)
            b.appendPath("search_suggest_query")
            var args: Array<String>? = null
            if (sp.selection != null) args = arrayOf(query) else b.appendPath(query)
            b.appendQueryParameter("limit", limit.toString())
            val rows = readRows(b.build(), sp.selection, args)
            for (i in 0 until rows.length()) {
                val o = rows.getJSONObject(i)
                sp.action?.let { o.put("_default_action", it) }
                sp.data?.let { o.put("_default_data", it) }
                sp.comp?.let { o.put("_component", it) }
            }
            rows.toString()
        } catch (e: Throwable) {
            val err = describe(e)
            app.log("Поиск $authority: $err")
            "ERR: $err"
        }
    }

    /**
     * Generic provider query from inside the app: any content:// URI, optional selection with one argument.
     * Lets the Python plugin try different query styles without rebuilding the APK. JSON rows or "ERR: ...".
     */
    fun queryUri(uri: String, selection: String?, arg: String?): String {
        return try {
            readRows(Uri.parse(uri), selection, if (arg != null) arrayOf(arg) else null).toString()
        } catch (e: Throwable) {
            "ERR: ${describe(e)}"
        }
    }

    /** What the app declared in searchable.xml for this authority: JSON {pkg,path,selection,action,data}. */
    fun providerSpec(authority: String): String {
        val sp = specs[authority] ?: return "{}"
        val o = JSONObject()
        o.put("pkg", sp.pkg)
        o.put("path", sp.path)
        o.put("selection", sp.selection ?: JSONObject.NULL)
        o.put("action", sp.action ?: JSONObject.NULL)
        o.put("data", sp.data ?: JSONObject.NULL)
        o.put("comp", sp.comp ?: JSONObject.NULL)
        return o.toString()
    }

    private fun readRows(uri: Uri, selection: String?, args: Array<String>?): JSONArray {
        val rows = JSONArray()
        val c = app.contentResolver.query(uri, null, selection, args, null) ?: return rows
        c.use {
            val names = it.columnNames
            while (it.moveToNext()) {
                val o = JSONObject()
                for (i in names.indices) {
                    try {
                        o.put(names[i], it.getString(i) ?: "")
                    } catch (ignored: Throwable) {
                    }
                }
                rows.put(o)
            }
        }
        return rows
    }
}
