package com.marktv

import dadb.AdbKeyPair
import dadb.Dadb
import java.io.File

/**
 * Sends key events to the TV by talking to its own adbd on 127.0.0.1:5555.
 * Needs "ADB debugging" enabled in Developer options (and, on some firmwares,
 * a one-time `adb tcpip 5555` from a PC). The first connection shows an
 * "Allow debugging?" prompt on the TV — tick "always allow".
 */
class KeyInjector(private val app: App) {

    @Volatile private var dadb: Dadb? = null

    @Synchronized
    private fun conn(): Dadb {
        dadb?.let { return it }
        val priv = File(app.filesDir, "adbkey")
        val pub = File(app.filesDir, "adbkey.pub")
        if (!priv.exists() || !pub.exists()) AdbKeyPair.generate(priv, pub)
        val kp = AdbKeyPair.read(priv, pub)
        val d = Dadb.create("127.0.0.1", 5555, kp)
        dadb = d
        return d
    }

    /** Runs a shell command on the TV. Returns "ok" or a short error text. */
    fun shell(cmd: String): String {
        return try {
            val r = conn().shell(cmd)
            if (r.exitCode == 0) {
                val out = r.allOutput.trim()
                if (out.isEmpty()) "ok" else "ok: $out"
            } else {
                "ADB: exit ${r.exitCode}: ${r.allOutput.trim()}"
            }
        } catch (e: Throwable) {
            dadb = null
            "ADB: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    fun key(code: Int): String = shell("input keyevent $code")
}
