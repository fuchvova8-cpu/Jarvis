package com.marktv

import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class Tts(private val app: App) : TextToSpeech.OnInitListener {

    private var engine: TextToSpeech? = TextToSpeech(app, this)
    @Volatile private var ready = false
    @Volatile private var onDone: (() -> Unit)? = null

    override fun onInit(status: Int) {
        val t = engine ?: return
        if (status != TextToSpeech.SUCCESS) {
            app.log("TTS: ошибка запуска ($status) — озвучки не будет")
            return
        }
        val r = t.setLanguage(Locale("ru", "RU"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            app.log("TTS: русский язык не поддерживается ($r) — установите голос Google TTS")
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                finish()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                finish()
            }
        })
        ready = true
        app.log("TTS готов")
    }

    fun speak(text: String, done: (() -> Unit)? = null) {
        val t = engine
        if (!ready || t == null) {
            app.log("TTS не готов — ответ не озвучен")
            done?.invoke()
            return
        }
        onDone = done
        val clean = if (text.length > 3500) text.substring(0, 3500) else text
        t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }

    fun stop() {
        onDone = null
        try {
            engine?.stop()
        } catch (ignored: Throwable) {
        }
    }

    fun info(): String =
        if (ready) "готов" else "не готов"

    private fun finish() {
        val d = onDone
        onDone = null
        if (d != null) app.main.post { d() }
    }
}
