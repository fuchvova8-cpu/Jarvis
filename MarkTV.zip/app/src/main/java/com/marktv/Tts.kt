package com.marktv

import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice as TtsVoice
import java.util.Locale

class Tts(private val app: App) : TextToSpeech.OnInitListener {

    private var engine: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var onDone: (() -> Unit)? = null

    /** Called (on the main thread) after the engine has been (re)started, e.g. to refresh the voice list. */
    @Volatile var onReady: (() -> Unit)? = null

    // ---- saved settings -------------------------------------------------------------------

    /** Package of the TTS engine chosen in the Service menu, "" = system default. */
    var enginePkg: String
        get() = app.prefs.getString("tts_engine", "") ?: ""
        set(v) { app.prefs.edit().putString("tts_engine", v).apply() }

    /** Name of the chosen voice, "" = engine default for Russian. */
    var voiceName: String
        get() = app.prefs.getString("tts_voice", "") ?: ""
        set(v) { app.prefs.edit().putString("tts_voice", v).apply() }

    /** Speech rate, 1.0 = normal. */
    var rate: Float
        get() = app.prefs.getFloat("tts_rate", 1.0f)
        set(v) {
            app.prefs.edit().putFloat("tts_rate", v).apply()
            engine?.setSpeechRate(v)
        }

    /** Pitch, 1.0 = normal. */
    var pitch: Float
        get() = app.prefs.getFloat("tts_pitch", 1.0f)
        set(v) {
            app.prefs.edit().putFloat("tts_pitch", v).apply()
            engine?.setPitch(v)
        }

    init {
        start()
    }

    private fun start() {
        ready = false
        val old = engine
        engine = null
        try {
            old?.stop()
            old?.shutdown()
        } catch (ignored: Throwable) {
        }
        val pkg = enginePkg
        engine = try {
            if (pkg.isNotEmpty()) TextToSpeech(app, this, pkg) else TextToSpeech(app, this)
        } catch (e: Throwable) {
            app.log("TTS: не удалось запустить движок ${pkg.ifEmpty { "по умолчанию" }}: ${e.message}")
            null
        }
    }

    /** Switches to another TTS engine package ("" = system default) and restarts. */
    fun setEngine(pkg: String) {
        enginePkg = pkg
        voiceName = ""
        start()
    }

    /**
     * Some engines call this synchronously from inside the TextToSpeech constructor (engine is still null then),
     * and some throw from setLanguage()/getVoices(). An exception here would kill the whole app at startup,
     * so the work is posted to the main thread and fully guarded.
     */
    override fun onInit(status: Int) {
        app.main.post {
            try {
                initEngine(status)
            } catch (e: Throwable) {
                ready = false
                app.log("TTS: сбой инициализации (${e.javaClass.simpleName}: ${e.message}) — озвучки не будет")
                fallBackToDefaultEngine()
            }
        }
    }

    private fun initEngine(status: Int) {
        val t = engine ?: return
        if (status != TextToSpeech.SUCCESS) {
            app.log("TTS: ошибка запуска ($status) — озвучки не будет")
            fallBackToDefaultEngine()
            return
        }
        try {
            val r = t.setLanguage(Locale("ru", "RU"))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                app.log("TTS: русский язык не поддерживается ($r) — установите голос Google TTS")
            }
        } catch (e: Throwable) {
            app.log("TTS: setLanguage: ${e.javaClass.simpleName}: ${e.message}")
        }
        applyVoice(t)
        try {
            t.setSpeechRate(rate)
            t.setPitch(pitch)
        } catch (e: Throwable) {
            app.log("TTS: скорость/тон: ${e.message}")
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                finish()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                finish()
            }
        })
        ready = true
        app.log("TTS готов (${engineLabel()}, голос: ${voiceName.ifEmpty { "по умолчанию" }})")
        onReady?.invoke()
    }

    /** A chosen engine that fails to start is dropped once, so the app falls back to the system default engine. */
    private fun fallBackToDefaultEngine() {
        if (enginePkg.isEmpty()) return
        app.log("TTS: движок ${enginePkg} не запустился — возвращаю системный по умолчанию")
        enginePkg = ""
        voiceName = ""
        start()
    }

    private fun applyVoice(t: TextToSpeech) {
        val name = voiceName
        if (name.isEmpty()) return
        try {
            val v = t.voices?.firstOrNull { it.name == name }
            if (v != null) t.voice = v
            else app.log("TTS: голос «$name» не найден — используется голос по умолчанию")
        } catch (e: Throwable) {
            app.log("TTS: не удалось выбрать голос: ${e.message}")
        }
    }

    // ---- lists for the menu ---------------------------------------------------------------

    /** Installed TTS engines as (package, label). */
    fun engines(): List<Pair<String, String>> = try {
        engine?.engines?.map { it.name to it.label } ?: emptyList()
    } catch (e: Throwable) {
        emptyList()
    }

    /** Russian voices of the current engine, sorted by name. */
    fun russianVoices(): List<TtsVoice> = try {
        (engine?.voices ?: emptySet<TtsVoice>())
            .filter { it.locale.language == "ru" }
            .sortedBy { it.name }
    } catch (e: Throwable) {
        emptyList()
    }

    /** Selects a voice by name and remembers it. */
    fun setVoice(name: String) {
        voiceName = name
        val t = engine ?: return
        if (ready) applyVoice(t)
    }

    fun engineLabel(): String {
        val pkg = enginePkg
        if (pkg.isEmpty()) {
            return try {
                val def = engine?.defaultEngine
                engines().firstOrNull { it.first == def }?.second ?: def ?: "по умолчанию"
            } catch (e: Throwable) {
                "по умолчанию"
            }
        }
        return engines().firstOrNull { it.first == pkg }?.second ?: pkg
    }

    // ---- speaking -------------------------------------------------------------------------

    fun speak(text: String, done: (() -> Unit)? = null) {
        val t = engine
        if (!ready || t == null) {
            app.log("TTS не готов — ответ не озвучен")
            done?.invoke()
            return
        }
        onDone = done
        val clean = if (text.length > 3500) text.substring(0, 3500) else text
        try {
            val r = t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
            if (r != TextToSpeech.SUCCESS) {
                app.log("TTS: speak вернул $r")
                finish()
            }
        } catch (e: Throwable) {
            app.log("TTS: speak: ${e.javaClass.simpleName}: ${e.message}")
            finish()
        }
    }

    fun stop() {
        onDone = null
        try {
            engine?.stop()
        } catch (ignored: Throwable) {
        }
    }

    fun info(): String =
        if (ready) "готов (${engineLabel()}, голос: ${voiceName.ifEmpty { "по умолчанию" }})" else "не готов"

    private fun finish() {
        val d = onDone
        onDone = null
        if (d != null) app.main.post { d() }
    }
}
