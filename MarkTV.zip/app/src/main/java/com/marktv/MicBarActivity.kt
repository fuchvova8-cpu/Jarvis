package com.marktv

/**
 * Same bottom strip as [OverlayActivity], but a separate launcher entry with its own task,
 * so the main window is never dragged to the front. Bind it to a remote button.
 */
class MicBarActivity : OverlayActivity()
