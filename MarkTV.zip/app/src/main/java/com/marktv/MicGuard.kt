package com.marktv

import android.os.SystemClock

/** Some remotes deliver one press twice. All mic launcher entries share this: a repeat within 1.5 s is ignored. */
object MicGuard {
    private var last = 0L

    @Synchronized
    fun allow(): Boolean {
        val now = SystemClock.uptimeMillis()
        if (now - last < 1500) return false
        last = now
        return true
    }
}
