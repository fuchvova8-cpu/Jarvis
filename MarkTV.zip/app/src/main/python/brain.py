"""Mark TV core: Gemini (REST, stdlib only) + plugin loader compatible with Mark-LV plugins.

A plugin is one .py file with
    PLUGIN = {"name": ..., "description": ..., "parameters": {"type": "OBJECT", ...}}
    def run(parameters, player=None, session_memory=None) -> str
Built-in plugins live in builtin_plugins/. Your own plugins go into the plugins
folder shown in the app (…/Android/data/com.marktv/files/plugins) and are picked
up on the next question, no rebuild needed.
"""
import importlib
import importlib.util
import json
import os
import re
import time
import traceback
import urllib.error
import urllib.request

import android_bridge

host = None
API_KEY = ""
PLUGINS_DIR = ""

HISTORY = []
MAX_HISTORY = 24
SESSION_MEMORY = {}
MAX_STEPS = 6

BUILTIN = [
    "builtin_plugins.channel_keys",
    "builtin_plugins.tv_keys",
    "builtin_plugins.screen_process",
    "builtin_plugins.save_memory",
    "builtin_plugins.recall_memory",
]

URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
NAME_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]{0,63}$")

ASSISTANT_NAME = "JARVIS"


def _describe_tools(decls):
    """main.py _describe_tools: одна строка на возможность, прямо из живых деклараций инструментов."""
    lines = []
    for d in decls or ():
        name = d.get("name")
        if not name:
            continue
        desc = " ".join(str(d.get("description") or "").split())
        lines.append("- %s: %s" % (name, desc[:150]) if desc else "- %s" % name)
    return "\n".join(lines)


def _describe_limits(has_vision, has_mic):
    """main.py _describe_limits (без части про платформу ПК)."""
    out = [
        "- Anything not listed above is outside your reach. Say so in one clause "
        "and offer the nearest thing you can actually do — never mime an action "
        "you cannot take, and never report a result you did not get.",
        "- You act on this machine only. You cannot reach the user's other "
        "devices, accounts or hardware except through the tools listed above.",
        "- You remember what is in the memory block and what has been said this "
        "session. Anything else you were told before is gone unless it was saved.",
    ]
    if has_vision:
        out.append(
            "- Your sight is not continuous. You see nothing until you call a "
            "vision tool, and then only that single frame at that moment — you "
            "cannot watch, monitor or notice something changing on screen.")
    else:
        out.append("- You have no sight at all in this build.")
    if has_mic:
        out.append(
            "- You hear nothing while the microphone is muted, and you cannot "
            "unmute it yourself.")
    return "\n".join(out)


def _render_prompt(template, values):
    out = template or ""
    for key, val in values.items():
        out = out.replace("{" + key + "}", str(val))
    return out


def build_system():
    """main.py _build_config(): [CURRENT DATE & TIME] + [IDENTITY] + память + prompt.txt с подставленными возможностями."""
    from datetime import datetime
    import memory_manager
    import prompt_text
    load_plugins()
    now = datetime.now()
    time_ctx = ("[CURRENT DATE & TIME]\n"
                "Right now it is: %s\n"
                "Use this to calculate exact times for reminders.\n\n" % now.strftime("%A, %B %d, %Y — %I:%M %p"))
    addr = ('ADDRESS: Address the user with the ordinary respectful form '
            'for a superior in the language you are currently speaking — '
            '"sir" in English, its everyday equivalent in any other '
            'language. Never an archaic or aristocratic form, and never '
            'the form from a different language than the one you are '
            'speaking in this sentence.')
    identity = ("[IDENTITY]\nYour name is %s. Always refer to yourself as %s.\n%s\n\n"
                % (ASSISTANT_NAME, ASSISTANT_NAME, addr))
    try:
        mem = memory_manager.format_memory_for_prompt(memory_manager.load_memory())
    except Exception as e:
        host.log("память: %s" % e)
        mem = ""
    decls = declarations()
    names = {d.get("name") for d in decls}
    prompt = _render_prompt(prompt_text.PROMPT, {
        "assistant_name": ASSISTANT_NAME,
        "platform": "Android TV",
        "capabilities": _describe_tools(decls),
        "limits": _describe_limits(has_vision="screen_process" in names, has_mic=True),
    })
    parts = [time_ctx, identity]
    if mem:
        parts.append(mem)
    parts.append(prompt)
    return "\n".join(parts)


_plugins = {}   # name -> (PLUGIN dict, run callable, source)
_mods = {}      # name -> module (for plugin settings pages)
_errors = []
_mtimes = {}    # path -> (mtime, module)


class Player:
    """What plugins receive as `player`. Desktop-only UI calls become harmless no-ops."""

    def write_log(self, text):
        host.log(str(text))

    def show_content(self, title, text):
        host.showContent(str(title), str(text))

    def speak(self, text):
        host.speak(str(text))

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)

        def _noop(*args, **kwargs):
            host.log("player.%s() не поддерживается на ТВ" % name)

        return _noop


PLAYER = Player()


def set_host(h):
    global host
    host = h
    android_bridge.set_host(h)


def configure(api_key, model, plugins_dir):
    """model не используется: модели выбирает лестница оригинала (LADDER). Ключ — как core/gemini.api_key()."""
    global API_KEY, PLUGINS_DIR
    new_key = (api_key or "").strip()
    if API_KEY and new_key != API_KEY:
        # What a model answered to the old key says nothing about the new one.
        _cooldown.clear()
        _gone.clear()
    API_KEY = new_key
    PLUGINS_DIR = plugins_dir or ""


def _register(found, mod, source):
    p = getattr(mod, "PLUGIN", None)
    r = getattr(mod, "run", None)
    if not isinstance(p, dict) or not callable(r):
        raise ValueError("нет PLUGIN или run()")
    name = p.get("name")
    if not isinstance(name, str) or not NAME_RE.match(name):
        raise ValueError("некорректное имя плагина: %r" % (name,))
    found[name] = (p, r, source)
    _mods[name] = mod


def load_plugins():
    global _plugins, _errors
    found, errors = {}, []
    for modname in BUILTIN:
        try:
            _register(found, importlib.import_module(modname), modname)
        except Exception as e:
            errors.append("%s: %s: %s" % (modname, type(e).__name__, e))
    if PLUGINS_DIR and os.path.isdir(PLUGINS_DIR):
        for fn in sorted(os.listdir(PLUGINS_DIR)):
            if not fn.endswith(".py") or fn.startswith("_"):
                continue
            path = os.path.join(PLUGINS_DIR, fn)
            try:
                mt = os.path.getmtime(path)
                cached = _mtimes.get(path)
                if cached and cached[0] == mt:
                    mod = cached[1]
                else:
                    spec = importlib.util.spec_from_file_location("userplugin_" + fn[:-3], path)
                    mod = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(mod)
                    _mtimes[path] = (mt, mod)
                _register(found, mod, path)
            except Exception as e:
                errors.append("%s: %s: %s" % (fn, type(e).__name__, e))
    _plugins, _errors = found, errors


def declarations():
    decls = []
    for name, (p, _run, _src) in _plugins.items():
        d = {"name": name, "description": str(p.get("description", ""))[:1000]}
        params = p.get("parameters")
        if isinstance(params, dict) and params.get("properties"):
            d["parameters"] = params
        decls.append(d)
    return decls


# ---------- plugin settings pages (Service menu) ----------
#
# A plugin may add a settings page by defining in its module
#     SETTINGS = {"title": "Название пункта в меню «Сервис»"}
#     def settings_items() -> list of items:
#         {"type": "label",  "text": "..."}
#         {"type": "button", "id": "refresh", "label": "Обновить"}
#         {"type": "text",   "id": "p:com.app", "label": "Название", "value": "...", "hint": "...", "multiline": True}
#     def settings_event(event, values) -> str | dict | None
#         event  — id нажатой кнопки ("__leave__" — экран закрыт); values — {id: текст} всех полей.
#         result — текст сообщения или {"message": "...", "refresh": True/False}.

def _settings_plugins():
    load_plugins()
    res = []
    for name in sorted(_plugins):
        m = _mods.get(name)
        s = getattr(m, "SETTINGS", None)
        if isinstance(s, dict) and callable(getattr(m, "settings_items", None)):
            res.append((name, str(s.get("title") or name), m))
    return res


def plugin_settings_list():
    return json.dumps([{"name": n, "title": t} for n, t, _m in _settings_plugins()], ensure_ascii=False)


def _find_settings_mod(name):
    for n, _t, m in _settings_plugins():
        if n == name:
            return m
    return None


def plugin_settings_items(name):
    m = _find_settings_mod(name)
    if m is None:
        return json.dumps([{"type": "label", "text": "У плагина нет настроек."}], ensure_ascii=False)
    try:
        items = m.settings_items()
        return json.dumps(list(items), ensure_ascii=False)
    except Exception as e:
        host.log("настройки %s: %s" % (name, traceback.format_exc(limit=3)))
        return json.dumps([{"type": "label", "text": "Ошибка: %s: %s" % (type(e).__name__, e)}], ensure_ascii=False)


def plugin_settings_event(name, event, values_json):
    m = _find_settings_mod(name)
    out = {"message": "", "refresh": False}
    if m is None or not callable(getattr(m, "settings_event", None)):
        return json.dumps(out, ensure_ascii=False)
    try:
        values = json.loads(values_json) if values_json else {}
        res = m.settings_event(str(event), values)
        if isinstance(res, dict):
            out["message"] = str(res.get("message") or "")
            out["refresh"] = bool(res.get("refresh"))
        elif res:
            out["message"] = str(res)
            out["refresh"] = True
    except Exception as e:
        host.log("настройки %s: %s" % (name, traceback.format_exc(limit=3)))
        out["message"] = "Ошибка: %s: %s" % (type(e).__name__, e)
    return json.dumps(out, ensure_ascii=False)


def describe_plugins():
    load_plugins()
    lines = ["Плагинов: %d" % len(_plugins)]
    for name, (_p, _r, src) in sorted(_plugins.items()):
        lines.append("  • %s  (%s)" % (name, os.path.basename(src) if os.sep in src else src))
    for e in _errors:
        lines.append("  ✗ " + e)
    return "\n".join(lines)


class GeminiError(RuntimeError):
    def __init__(self, code, msg):
        RuntimeError.__init__(self, "Gemini HTTP %s: %s" % (code, msg))
        self.code = code
        self.msg = msg


def _http_error(e):
    try:
        msg = json.loads(e.read().decode("utf-8")).get("error", {}).get("message", "")
    except Exception:
        msg = ""
    return GeminiError(e.code, msg or e.reason)


def _post(model, body):
    req = urllib.request.Request(
        URL.format(model=model),
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json", "x-goog-api-key": API_KEY},
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise _http_error(e)


def _suggested(msg):
    """Google's own error text names the replacement: '...use models/gemini-X-flash...'."""
    m = re.search(r"use models/([A-Za-z0-9._\-]+)", msg or "")
    return m.group(1) if m else None


RETRY_CODES = (429, 500, 502, 503, 504)


def _flash_models(allow_lite=False):
    """Models this key can use for generateContent, newest 'flash' first."""
    req = urllib.request.Request(
        "https://generativelanguage.googleapis.com/v1beta/models?pageSize=200",
        headers={"x-goog-api-key": API_KEY},
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            data = json.loads(r.read().decode("utf-8"))
    except Exception as e:
        host.log("список моделей не получен: %s" % e)
        return []
    skip = ["image", "tts", "live", "audio", "exp", "thinking", "robotics", "computer"]
    if not allow_lite:
        skip.append("lite")
    found = []
    for m in data.get("models", []):
        name = m.get("name", "").replace("models/", "")
        if not name.startswith("gemini-") or "flash" not in name:
            continue
        if "generateContent" not in m.get("supportedGenerationMethods", []):
            continue
        if any(x in name for x in skip):
            continue
        v = re.search(r"gemini-(\d+(?:\.\d+)?)", name)
        found.append(((float(v.group(1)) if v else 0.0, 0 if "preview" in name else 1), name))
    found.sort(reverse=True)
    return [n for _v, n in found]


def _pick_model():
    models = _flash_models()
    return models[0] if models else None


def _post_retry(model, body):
    """Overload (503/429/5xx) is usually brief: retry a couple of times."""
    delays = (1.0, 2.5)
    for i in range(len(delays) + 1):
        try:
            return _post(model, body)
        except GeminiError as e:
            if e.code not in RETRY_CODES or i == len(delays):
                raise
            host.log("Gemini %s, повтор через %.1f с" % (e.code, delays[i]))
            time.sleep(delays[i])


def _generate(tools):
    body = {
        "systemInstruction": {"parts": [{"text": build_system()}]},
        "contents": HISTORY,
    }
    if tools:
        body["tools"] = [{"functionDeclarations": tools}]
    return _call(body)


# core/gemini.py: _LADDERS[FAST] и классификация ошибок, один в один.
LADDER = ("gemini-3.5-flash-lite", "gemini-flash-lite-latest",
          "gemini-3.1-flash-lite", "gemini-3.5-flash",
          "gemini-3.6-flash", "gemini-3.8-flash", "gemini-flash-latest",
          "gemini-3-flash-preview", "gemini-2.5-flash-lite", "gemini-2.5-flash")
_COOLDOWN_SECONDS = 300
_GONE_SECONDS = 6 * 60 * 60
_UNAVAILABLE_SECONDS = 30 * 60
_cooldown = {}   # model -> time.monotonic() до которого модель отдыхает
_gone = set()    # отдыхают потому, что их нет для этого ключа (404, 403)


def _cool(model, seconds=_COOLDOWN_SECONDS):
    _cooldown[model] = time.monotonic() + seconds
    if seconds >= _GONE_SECONDS:
        _gone.add(model)
    else:
        _gone.discard(model)


def _cooling(model):
    until = _cooldown.get(model, 0.0)
    if until and time.monotonic() < until:
        return True
    _cooldown.pop(model, None)
    _gone.discard(model)
    return False


def usable_rungs(ladder):
    ladder = list(ladder)
    ready = [m for m in ladder if not _cooling(m)]
    if ready:
        return ready
    passing = sorted((m for m in ladder if m not in _gone), key=lambda m: _cooldown.get(m, 0.0))
    return passing or ladder


def is_key_error(err):
    low = err.lower()
    return ("api key not valid" in low or "api_key_invalid" in low
            or "api key expired" in low or "invalid api key" in low)


def is_quota_error(err):
    return "429" in err or "RESOURCE_EXHAUSTED" in err


def is_unavailable_error(err):
    low = err.lower()
    return "503" in err or "504" in err or "unavailable" in low or "deadline_exceeded" in low


def is_gone_error(err):
    low = err.lower()
    return "404" in err or "not found" in low or "is not supported" in low or "permission" in low or "403" in err


def _call(body):
    """core/gemini.call(): REST-лестница с отдыхом упавших. Ключ отвергнут — остальные модели не трогаем (тот же ключ)."""
    last = None
    for model in usable_rungs(LADDER):
        try:
            return _post(model, body)
        except Exception as e:
            last = e
            msg = str(e)
            if is_key_error(msg):
                host.log("Gemini: ключ не принят — %s" % msg[:120])
                raise
            elif is_quota_error(msg):
                _cool(model)
                host.log("Gemini: %s — лимит, пропускаю на %d мин" % (model, _COOLDOWN_SECONDS // 60))
            elif is_gone_error(msg):
                _cool(model, _GONE_SECONDS)
                host.log("Gemini: %s недоступна для этого ключа, отложена" % model)
            elif is_unavailable_error(msg):
                _cool(model, _UNAVAILABLE_SECONDS)
                host.log("Gemini: %s не отвечает, отдыхает %d мин" % (model, _UNAVAILABLE_SECONDS // 60))
            else:
                host.log("Gemini: %s: %s" % (model, msg[:140]))
    raise last or RuntimeError("нет доступных моделей Gemini")


ONE_SHOT_SYSTEM = (
    "You are a data-processing function, not an assistant and not in a conversation. There is no person listening "
    "to you. Produce exactly the output the request asks for and nothing else: no greeting, no acknowledgement, no "
    "'Understood', no explanation, no closing remark, no restating of the question. If the request asks for JSON, "
    "emit only the JSON. If it asks for code, emit only the code. If it asks for one word, emit that one word. "
    "Preserve the exact spelling, punctuation, capitals and whitespace of anything you are asked to copy or return."
)


def one_shot(prompt, system=None, image=None, mime="image/jpeg", timeout_s=30):
    """core/gemini.py call(): служебный запрос без диалога. ЛИДИРУЕТ Live (отдельная одноразовая сессия, другой пул
    квот и ничего не слышно пользователю), за ним REST-лестница. Всегда возвращает текст; ошибка — строка 'ERR: ...'.
    Плагины вызывают: import brain; brain.one_shot("...")."""
    import base64
    if not API_KEY:
        return "ERR: не задан ключ Gemini"
    b64 = base64.b64encode(image).decode("ascii") if image else ""
    live = getattr(host, "liveOneShot", None)
    if callable(live):
        try:
            r = str(live(prompt, system or ONE_SHOT_SYSTEM, b64, mime, int(timeout_s * 1000)))
            if not r.startswith("ERR:"):
                return r
            host.log("one_shot: Live не ответил (%s), REST" % r[:120])
        except Exception as e:
            host.log("one_shot: Live: %s" % e)
    parts = []
    if b64:
        parts.append({"inlineData": {"mimeType": mime, "data": b64}})
    parts.append({"text": prompt})
    body = {"systemInstruction": {"parts": [{"text": system or ONE_SHOT_SYSTEM}]},
            "contents": [{"role": "user", "parts": parts}]}
    try:
        resp = _call(body)
    except Exception as e:
        return "ERR: %s" % (_friendly(e) or e)
    out = ((resp.get("candidates") or [{}])[0].get("content") or {}).get("parts") or []
    text = "".join(p.get("text", "") for p in out if not p.get("thought")).strip()
    return text or "ERR: пустой ответ"


def _friendly(e):
    code = getattr(e, "code", None)
    msg = getattr(e, "msg", "") or ""
    if code in (500, 502, 503, 504):
        return "Серверы Gemini сейчас перегружены. Повторите через минуту."
    if code == 429:
        return "Превышен лимит запросов Gemini. Подождите минуту."
    if code in (400, 403) and "API key" in msg:
        return "Ключ Gemini не принят. Проверьте ключ в настройках."
    return None


def _run_tool(name, args):
    entry = _plugins.get(name)
    if entry is None:
        return "Неизвестный инструмент: %s" % name
    try:
        result = entry[1](args, PLAYER, SESSION_MEMORY)
        return str(result)[:2000]
    except Exception as e:
        host.log("плагин %s упал: %s" % (name, traceback.format_exc(limit=3)))
        return "Ошибка плагина %s: %s: %s" % (name, type(e).__name__, e)


def _trim():
    while len(HISTORY) > MAX_HISTORY:
        HISTORY.pop(0)
    # history must start with a user turn that has text (never with a functionResponse)
    while HISTORY:
        first = HISTORY[0]
        if first.get("role") == "user" and any("text" in p for p in first.get("parts", [])):
            break
        HISTORY.pop(0)


# ---------- Gemini Live as the brain (see GeminiTts.converse in Kotlin) ----------
#
# In Mark-LVII the answer is spoken by the Live model itself. Here Kotlin runs the Live session and calls back
# into this module: live_context() gives the system prompt + tool declarations, live_tool() runs a plugin,
# live_note() stores the exchange in HISTORY (so the text fallback keeps the context), live_turn_end() lets
# plugins that wrap ask() (e.g. ultron) do their after-turn work.

_NOOP = "\x00live-turn-end\x00"


def _recent_text(limit=8):
    lines = []
    for item in HISTORY[-limit * 2:]:
        txt = " ".join(p.get("text", "") for p in item.get("parts", []) if p.get("text") and not p.get("thought")).strip()
        if not txt:
            continue
        lines.append(("Пользователь: " if item.get("role") == "user" else "Mark: ") + txt)
    return lines[-limit:]


def live_context():
    load_plugins()
    system = build_system()
    recent = _recent_text()
    if recent:
        system += "\n\nНедавний разговор (для контекста, не пересказывай его):\n" + "\n".join(recent)
    return json.dumps({"system": system, "tools": declarations()}, ensure_ascii=False)


def live_tool(name, args_json):
    try:
        args = json.loads(args_json or "{}")
        if not isinstance(args, dict):
            args = {}
    except Exception:
        args = {}
    return _run_tool(name, args)


def _take_vision_json():
    try:
        raw = live_pending_vision()
        return json.loads(raw) if raw else None
    except Exception:
        return None


def live_pending_vision():
    """main.py _flush_pending_vision: the frame to send into the Live session right after the tool response.
    JSON {mime, data(base64), text} or "" when nothing is pending. Kotlin sends it as a user turn."""
    from builtin_plugins import screen_process
    return screen_process.take_pending()


def live_note(user_text, reply_text):
    user_text = (user_text or "").strip()
    reply_text = (reply_text or "").strip()
    if user_text:
        HISTORY.append({"role": "user", "parts": [{"text": user_text}]})
        HISTORY.append({"role": "model", "parts": [{"text": reply_text or "(ответил голосом)"}]})
        _trim()


def live_turn_end():
    ask(_NOOP)


def ask(text):
    if text == _NOOP:
        return ""
    if not API_KEY:
        return "Не задан ключ Gemini. Откройте настройки приложения и вставьте ключ."
    load_plugins()
    start = len(HISTORY)
    HISTORY.append({"role": "user", "parts": [{"text": text}]})
    tools = declarations()
    try:
        for _ in range(MAX_STEPS):
            resp = _generate(tools)
            cands = resp.get("candidates") or [{}]
            cand = cands[0]
            parts = (cand.get("content") or {}).get("parts") or []
            if not parts:
                reason = cand.get("finishReason") or resp.get("promptFeedback") or "пустой ответ"
                del HISTORY[start:]
                return "Модель не ответила (%s)." % (reason,)
            HISTORY.append({"role": "model", "parts": parts})
            calls = [p["functionCall"] for p in parts if "functionCall" in p]
            if not calls:
                answer = "".join(p.get("text", "") for p in parts if not p.get("thought")).strip()
                _trim()
                return answer or "Готово."
            out = []
            for c in calls:
                result = _run_tool(c.get("name", ""), c.get("args") or {})
                out.append({"functionResponse": {"name": c.get("name", ""), "response": {"result": result}}})
            pend = _take_vision_json()
            if pend:
                out.append({"inlineData": {"mimeType": pend["mime"], "data": pend["data"]}})
                out.append({"text": pend["text"]})
            HISTORY.append({"role": "user", "parts": out})
        _trim()
        return "Слишком много шагов подряд, остановился."
    except Exception as e:
        del HISTORY[start:]
        if not isinstance(e, RuntimeError):
            host.log("ask: %s" % traceback.format_exc(limit=4))
        return _friendly(e) or "Ошибка: %s" % (e,)
