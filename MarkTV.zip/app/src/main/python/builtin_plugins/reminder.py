"""reminder — как actions/reminder.py оригинала (те же параметры date/time/message), но на ТВ вместо планировщика ОС
напоминание хранится в файле, а brain.py раз в 15 секунд проверяет срок и произносит текст вслух."""
import json
import os
import threading
from datetime import datetime

import android_bridge as android

_lock = threading.Lock()

PLUGIN = {
    "name": "reminder",
    "description": "Sets a timed reminder. The assistant says the message aloud at that time while the app is running.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "date": {"type": "STRING", "description": "Date in YYYY-MM-DD format"},
            "time": {"type": "STRING", "description": "Time in HH:MM format (24h)"},
            "message": {"type": "STRING", "description": "Reminder message text"},
        },
        "required": ["date", "time", "message"],
    },
}


def _path():
    d = os.path.join(android.data_dir() or ".", "memory")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "reminders.json")


def _load():
    try:
        with open(_path(), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save(items):
    with open(_path(), "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=2)


def run(parameters, player=None, session_memory=None):
    date_str = str(parameters.get("date", "")).strip()
    time_str = str(parameters.get("time", "")).strip()
    message = str(parameters.get("message", "Reminder")).strip()
    if not date_str or not time_str:
        return "I need both a date and a time to set a reminder."
    try:
        target = datetime.strptime("%s %s" % (date_str, time_str), "%Y-%m-%d %H:%M")
    except ValueError:
        return "I couldn't parse that date or time. Please use YYYY-MM-DD and HH:MM."
    if target <= datetime.now():
        return "That time has already passed — I can't set a reminder in the past."
    with _lock:
        items = _load()
        items.append({"at": target.strftime("%Y-%m-%d %H:%M"), "message": message[:200]})
        _save(items)
    return "Reminder set for %s." % target.strftime("%B %d at %I:%M %p")


def check_due(speak):
    """Вызывается brain-ом раз в 15 с: произнести наступившие напоминания и убрать их из файла."""
    with _lock:
        items = _load()
        if not items:
            return
        now = datetime.now()
        due, rest = [], []
        for it in items:
            try:
                (due if datetime.strptime(it["at"], "%Y-%m-%d %H:%M") <= now else rest).append(it)
            except Exception:
                pass
        if due:
            _save(rest)
    for it in due:
        speak(it.get("message", ""))
