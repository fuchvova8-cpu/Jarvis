from builtin_plugins import memory_tools as _m
PLUGIN = _m.PLUGIN_SAVE
run = _m.save
