import android_bridge as android

PLUGIN = {
    "name": "channel_keys",
    "description": (
        "Переключить телеканал: набирает цифры номера канала на пульте. "
        "Вызывай на фразы вроде «канал 327», «включи триста двадцать седьмой». "
        "Передавай номер цифрами."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "channel": {"type": "STRING", "description": "Номер канала цифрами, например 327"},
            "press_ok": {"type": "BOOLEAN", "description": "Нажать OK после набора (по умолчанию нет)"},
        },
        "required": ["channel"],
    },
}


def run(parameters, player=None, session_memory=None):
    digits = "".join(ch for ch in str(parameters.get("channel", "")) if ch.isdigit())
    if not digits:
        return "Не понял номер канала."
    res = android.type_text(digits, delay=0.25)
    if not str(res).startswith("ok"):
        return "Не удалось набрать канал: %s" % res
    if parameters.get("press_ok"):
        android.key("ok")
    return "Набрал канал %s." % digits
