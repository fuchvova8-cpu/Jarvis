"""interface_color — меняет акцентный цвет интерфейса Jarvis на лету (Host.setAccent), как поле hex в «Сервис»."""
import android_bridge as android

PLUGIN = {
    "name": "interface_color",
    "description": "Changes the accent colour of the assistant's interface (the whole palette follows it). "
                   "Use only when a plugin or the user asks for a colour change; pass the exact hex value.",
    "parameters": {
        "type": "OBJECT",
        "properties": {"hex": {"type": "STRING", "description": "Colour as #rrggbb, e.g. #ff0004"}},
        "required": ["hex"],
    },
}


def run(parameters, player=None, session_memory=None):
    hx = str((parameters or {}).get("hex") or "").strip().lower()
    fn = getattr(android.host, "setAccent", None)
    if not callable(fn):
        return "Error: this build cannot change the interface colour."
    r = str(fn(hx))
    return "Interface colour set to %s." % hx if r == "ok" else "Error: %s" % r
