"""save_memory / recall_memory — как в Mark-LVII (main.py TOOL_DECLARATIONS и _execute_tool, memory/memory_manager.py)."""
import memory_manager as mm

PLUGIN_SAVE = {
    "name": "save_memory",
    "description": (
        "Save an important personal fact about the user to long-term memory. "
        "Call this silently whenever the user reveals something worth remembering: "
        "name, age, city, job, preferences, hobbies, relationships, projects, or future plans. "
        "Do NOT call for: weather, reminders, searches, or one-time commands. "
        "Do NOT announce that you are saving — just call it silently. "
        "Values must be in English regardless of the conversation language."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "category": {
                "type": "STRING",
                "description": (
                    "identity — name, age, birthday, city, job, language, nationality | "
                    "preferences — favorite food/color/music/film/game/sport, hobbies | "
                    "projects — active projects, goals, things being built | "
                    "relationships — friends, family, partner, colleagues | "
                    "wishes — future plans, things to buy, travel dreams | "
                    "notes — habits, schedule, anything else worth remembering"
                ),
            },
            "key": {"type": "STRING", "description": "Short snake_case key (e.g. name, favorite_food, sister_name)"},
            "value": {"type": "STRING", "description": "Concise value in English (e.g. Fatih, pizza, older sister)"},
        },
        "required": ["category", "key", "value"],
    },
}

PLUGIN_RECALL = {
    "name": "recall_memory",
    "description": (
        "Look up a fact you have stored about the user but which is NOT in "
        "the memory block of your system prompt. "
        "The prompt lists the keys it did not have room for under "
        "'[ALSO REMEMBERED]' — if the user asks about anything named there, "
        "call this FIRST. "
        "Also call it before saying you do not know something personal, and "
        "when the user asks what you remember about them (leave query empty "
        "for everything). "
        "This is a local file search: it is instant and costs nothing."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "query": {
                "type": "STRING",
                "description": (
                    "Keyword to search for — a name, a topic, a category "
                    "(e.g. 'ayse', 'coffee', 'projects'). "
                    "Leave empty to list everything stored."
                ),
            },
        },
        "required": [],
    },
}


def save(parameters, player=None, session_memory=None):
    category = parameters.get("category", "notes")
    key = parameters.get("key", "")
    value = parameters.get("value", "")
    if key and value:
        mm.update_memory({category: {key: {"value": value}}})
    return "ok"   # original: {"result": "ok", "silent": True}


def recall(parameters, player=None, session_memory=None):
    return mm.search_memory(parameters.get("query", ""), limit=8)
