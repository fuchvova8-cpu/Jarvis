"""Агент экрана Mark: смотрит на экран ТВ и делает то, что сказал пользователь.

Цикл: свежий снимок экрана -> Gemini выбирает ОДНО действие (нажать, листать, кнопка пульта, ввод текста,
ждать, готово/не получилось) -> действие выполняется через ADB -> новый снимок -> и так до «готово»
(не больше MAX_STEPS шагов и TIME_LIMIT секунд). Каждый шаг — отдельный запрос с самым свежим снимком,
поэтому модель всегда видит экран таким, какой он сейчас.

Окно Mark поверх ТВ перехватывало бы нажатия, поэтому перед работой плагин просит приложение закрыть его
(Host.hideOverlay). Если в приложении этого метода нет, работа идёт как есть.
"""
import json
import struct
import time

import android_bridge as android
from builtin_plugins import screen_vision as sv

MAX_STEPS = 10        # шагов (действий) на одну задачу
TIME_LIMIT = 110      # секунд на всю задачу
SETTLE = 1.3          # пауза после действия, чтобы экран успел обновиться
HIDE_WAIT = 0.9       # пауза после закрытия окна Mark
REPEAT_LIMIT = 3      # одно и то же действие подряд столько раз — считаем, что зациклились
MAX_WAIT = 5          # максимум секунд в действии wait

PLUGIN = {
    "name": "screen_agent",
    "description": (
        "Выполняет действие на экране телевизора, глядя на экран: нажимает на пункты, листает, открывает, "
        "включает, вводит текст, нажимает кнопки пульта — столько шагов, сколько нужно. "
        "Вызывай, когда просят что-то СДЕЛАТЬ с тем, что показано на экране: «нажми на второй фильм», "
        "«открой настройки», «промотай вниз и выбери…», «найди … и включи», «закрой это окно». "
        "В task передай просьбу пользователя как есть. Если нужно только ответить, что на экране, "
        "используй screen_vision."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "task": {"type": "STRING", "description": "Что нужно сделать на экране, словами пользователя"},
        },
        "required": ["task"],
    },
}

AGENT_SYSTEM = (
    "Ты Mark — ассистент, который управляет экраном Android TV вместо пользователя. Ты видишь снимок экрана "
    "и выбираешь ровно одно следующее действие, вызвав функцию. Телевизор управляется как пультом: если tap "
    "по координатам не сработал, используй стрелки и ok. Координаты x и y — целые числа от 0 до 1000 по ширине "
    "и высоте снимка, (0,0) — левый верхний угол. Не повторяй действие, которое не изменило экран: смени подход. "
    "Когда задача выполнена, вызови done с короткой фразой по-русски для озвучки. Если задачу выполнить нельзя, "
    "вызови fail с короткой причиной. Не совершай покупки, подписки и оплату, не вводи пароли и платёжные данные, "
    "не удаляй данные и аккаунты, не устанавливай и не удаляй приложения: если для задачи это нужно, вызови fail "
    "и скажи, что нужно подтверждение пользователя. На снимке может быть интерфейс самого ассистента — не трогай его."
)

_NUM = {"type": "INTEGER"}
TOOLS = [
    {"name": "tap", "description": "Нажать на точку экрана (как клик).",
     "parameters": {"type": "OBJECT", "properties": {
         "x": dict(_NUM, description="0..1000 слева направо"), "y": dict(_NUM, description="0..1000 сверху вниз")},
         "required": ["x", "y"]}},
    {"name": "scroll", "description": "Пролистать содержимое: direction=down показывает то, что ниже, up — выше, "
                                       "right — правее, left — левее.",
     "parameters": {"type": "OBJECT", "properties": {"direction": {"type": "STRING", "description": "up|down|left|right"}},
                    "required": ["direction"]}},
    {"name": "key", "description": "Нажать кнопку пульта: up, down, left, right, ok, back, home, menu, play_pause, "
                                    "play, pause, stop, ff, rew, channel_up, channel_down, info, guide, volume_up, "
                                    "volume_down, mute, pageup, pagedown, enter.",
     "parameters": {"type": "OBJECT", "properties": {"key": {"type": "STRING"}}, "required": ["key"]}},
    {"name": "type_text", "description": "Ввести текст в активное поле. Работает только для латиницы и цифр; "
                                          "русские буквы вводи нажатием клавиш экранной клавиатуры (tap).",
     "parameters": {"type": "OBJECT", "properties": {"text": {"type": "STRING"}}, "required": ["text"]}},
    {"name": "wait", "description": "Подождать, пока экран загрузится (секунды, не больше %d)." % MAX_WAIT,
     "parameters": {"type": "OBJECT", "properties": {"seconds": {"type": "INTEGER"}}, "required": ["seconds"]}},
    {"name": "done", "description": "Задача выполнена. message — короткая фраза пользователю.",
     "parameters": {"type": "OBJECT", "properties": {"message": {"type": "STRING"}}, "required": ["message"]}},
    {"name": "fail", "description": "Задачу выполнить не получается. reason — короткая причина.",
     "parameters": {"type": "OBJECT", "properties": {"reason": {"type": "STRING"}}, "required": ["reason"]}},
]


def _png_size(data):
    try:
        w, h = struct.unpack(">II", data[16:24])
        if 100 <= w <= 10000 and 100 <= h <= 10000:
            return w, h
    except Exception:
        pass
    return 1920, 1080


def _num(v, default=0):
    try:
        return int(round(float(v)))
    except (TypeError, ValueError):
        return default


def _px(v, size):
    return max(0, min(size - 1, int(max(0, min(1000, _num(v))) * size / 1000)))


def _ok(res):
    return not str(res).startswith(("ADB:", "ERR", "Ошибка"))


def _execute(name, args, w, h):
    """Выполнить действие. Возвращает (получилось, описание для истории)."""
    if name == "tap":
        x, y = _px(args.get("x"), w), _px(args.get("y"), h)
        res = android.shell("input tap %d %d" % (x, y))
        return _ok(res), "tap(%s, %s)" % (args.get("x"), args.get("y")) + ("" if _ok(res) else ": %s" % str(res)[:80])
    if name == "scroll":
        d = str(args.get("direction") or "").lower()
        moves = {  # (x1, y1, x2, y2) в долях экрана: палец движется в сторону, обратную листанию
            "down": (0.5, 0.72, 0.5, 0.28), "up": (0.5, 0.28, 0.5, 0.72),
            "right": (0.75, 0.5, 0.25, 0.5), "left": (0.25, 0.5, 0.75, 0.5),
        }
        if d not in moves:
            return False, "scroll: неизвестное направление %r" % d
        fx1, fy1, fx2, fy2 = moves[d]
        res = android.shell("input swipe %d %d %d %d 350" % (fx1 * w, fy1 * h, fx2 * w, fy2 * h))
        return _ok(res), "scroll(%s)" % d + ("" if _ok(res) else ": %s" % str(res)[:80])
    if name == "key":
        k = str(args.get("key") or "").strip().lower()
        try:
            code = android.code_of(k)
        except ValueError:
            return False, "key: неизвестная кнопка %r" % k
        res = android.key(code)
        return _ok(res), "key(%s)" % k + ("" if _ok(res) else ": %s" % str(res)[:80])
    if name == "type_text":
        text = str(args.get("text") or "")
        if not text:
            return False, "type_text: пустой текст"
        if not text.isascii():
            return False, "type_text: русские буквы так не ввести, нажимай клавиши экранной клавиатуры через tap"
        arg = text.replace("\\", "\\\\").replace("'", "'\\''").replace(" ", "%s")
        res = android.shell("input text '%s'" % arg)
        return _ok(res), "type_text(%r)" % text + ("" if _ok(res) else ": %s" % str(res)[:80])
    if name == "wait":
        sec = max(1, min(MAX_WAIT, _num(args.get("seconds"), 2)))
        time.sleep(sec)
        return True, "wait(%d)" % sec
    return False, "неизвестное действие %r" % name


def _pick_call(resp):
    cands = resp.get("candidates") or [{}]
    parts = (cands[0].get("content") or {}).get("parts") or []
    for p in parts:
        if "functionCall" in p:
            c = p["functionCall"]
            return c.get("name", ""), (c.get("args") or {}), ""
    text = "".join(p.get("text", "") for p in parts if not p.get("thought")).strip()
    return "", {}, text


def _agent(task, mem):
    import base64
    import brain  # поздний импорт: brain сам загружает этот плагин

    t0 = time.time()
    hide = getattr(android.host, "hideOverlay", None)
    if callable(hide):  # окно Mark поверх ТВ перехватило бы нажатия
        try:
            hide()
        except Exception as e:
            android.log("agent: не закрыл окно Mark: %s" % e)
        time.sleep(HIDE_WAIT)

    history, last, repeats = [], None, 0
    for step in range(1, MAX_STEPS + 1):
        if time.time() - t0 > TIME_LIMIT:
            return "Не успел за отведённое время. Сделано: %s." % ("; ".join(history[-3:]) or "ничего")
        data, err = sv._screenshot()
        if data is None:
            return "Не удалось сделать снимок экрана: %s" % err
        w, h = _png_size(data)
        prompt = "Задача пользователя: %s\nРазмер снимка: %dx%d.\nУже сделано: %s\nВыбери одно следующее действие." % (
            task, w, h, ("; ".join("%d) %s" % (i + 1, s) for i, s in enumerate(history[-8:])) or "ничего"))
        if len(data) < sv.BLACK_BYTES:
            prompt += "\nСнимок почти чёрный: видео или защищённый кадр не виден, управляй кнопками пульта."
        body = {
            "systemInstruction": {"parts": [{"text": AGENT_SYSTEM}]},
            "contents": [{"role": "user", "parts": [
                {"inlineData": {"mimeType": "image/png", "data": base64.b64encode(data).decode("ascii")}},
                {"text": prompt},
            ]}],
            "tools": [{"functionDeclarations": TOOLS}],
            "toolConfig": {"functionCallingConfig": {"mode": "ANY"}},
        }
        try:
            resp = brain._call(body)
        except Exception as e:
            return brain._friendly(e) or "Ошибка: %s" % (e,)
        name, args, text = _pick_call(resp)
        if name == "done":
            return str(args.get("message") or "Готово.")
        if name == "fail":
            return "Не получилось: %s" % (args.get("reason") or "причина неизвестна")
        if not name:
            return text or "Модель не выбрала действие."
        key = (name, json.dumps(args, sort_keys=True, ensure_ascii=False))
        repeats = repeats + 1 if key == last else 1
        last = key
        if repeats >= REPEAT_LIMIT:
            return "Остановился: одно и то же действие (%s) не помогает." % name
        ok, desc = _execute(name, args, w, h)
        history.append(desc + ("" if ok else " — НЕ ВЫПОЛНЕНО"))
        android.log("agent шаг %d: %s" % (step, history[-1]))
        if name != "wait":
            time.sleep(SETTLE)
    return "Сделал %d шагов, но задача не завершена. Последнее: %s." % (MAX_STEPS, history[-1] if history else "ничего")


def run(parameters, player=None, session_memory=None):
    task = str(parameters.get("task") or "").strip()
    if not task:
        return "Не понял, что сделать на экране."
    try:
        return _agent(task, session_memory if isinstance(session_memory, dict) else {})
    except Exception as e:
        return "Ошибка: %s: %s" % (type(e).__name__, e)
