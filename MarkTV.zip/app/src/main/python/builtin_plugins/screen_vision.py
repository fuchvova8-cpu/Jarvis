"""Зрение Mark: снимок экрана ТВ -> Gemini -> короткий ответ.

`screencap -p` (через ADB) кладёт PNG в папку приложения на внешнем накопителе
(…/Android/data/com.marktv/files/), оттуда его читает Python, а brain.vision() отправляет картинку в Gemini.
Если кадр почти чёрный (видео на аппаратном слое или защищённый контент в снимок не попадают),
к запросу добавляется текст интерфейса, прочитанный через uiautomator.
"""
import os
import time
import xml.etree.ElementTree as ET

import android_bridge as android

APP_PKG = "com.marktv"
DEFAULT_DIR = "/storage/emulated/0/Android/data/com.marktv/files"
SHOT_NAME = "screen_vision.png"
DUMP_NAME = "screen_vision_ui.xml"
BLACK_BYTES = 40000      # PNG меньше этого размера на ТВ 1080p — почти наверняка чёрный кадр
MAX_UI_TEXTS = 80        # сколько строк интерфейса добавлять к запросу
PNG_MAGIC = b"\x89PNG\r\n\x1a\n"

PLUGIN = {
    "name": "screen_vision",
    "description": (
        "Видит экран телевизора: делает снимок экрана и отвечает по нему. "
        "action=look с question — ответить на вопрос о том, что сейчас на экране "
        "(«что на экране», «что это за фильм», «прочитай, что написано», «какой сейчас канал», "
        "«что выбрано в меню», «опиши картинку»). В question передай вопрос пользователя как есть. "
        "with_text=true добавляет к снимку текст интерфейса (точнее для мелкого текста, но медленнее). "
        "action=text — только прочитать текст интерфейса приложения на экране, без картинки. "
        "Вызывай, когда пользователь просит посмотреть на экран или спрашивает о том, что на нём показано."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "look | text (по умолчанию look)"},
            "question": {"type": "STRING", "description": "Вопрос о том, что на экране (для look)"},
            "with_text": {"type": "BOOLEAN", "description": "Добавить текст интерфейса к снимку (необязательно)"},
        },
        "required": [],
    },
}


def _dir():
    """Папка Mark TV на внешнем накопителе: туда может писать и ADB shell, и само приложение."""
    try:
        pd = str(android.host.pluginsDir())
    except Exception:
        pd = ""
    marker = "/Android/data/%s/files" % APP_PKG
    i = pd.find(marker)
    return (pd[:i] + marker) if i >= 0 else DEFAULT_DIR


def _screenshot():
    """Возвращает (bytes PNG, '') или (None, причина)."""
    d = _dir()
    path = d + "/" + SHOT_NAME
    res = str(android.shell("mkdir -p '%s'; rm -f '%s'; screencap -p '%s'; chmod 666 '%s'" % (d, path, path, path)))
    err = res[:150]
    for _ in range(6):
        try:
            if os.path.getsize(path) > 0:
                with open(path, "rb") as f:
                    data = f.read()
                try:
                    os.remove(path)
                except OSError:
                    pass
                if data[:8] != PNG_MAGIC:
                    return None, "screencap вернул не картинку"
                return data, ""
        except OSError as e:
            err = err or str(e)
        time.sleep(0.4)
    return None, err or "файл снимка не появился"


def _ui_texts():
    """Тексты интерфейса приложений на экране (без самого Mark): список строк или None."""
    path = _dir() + "/" + DUMP_NAME
    android.shell("rm -f '%s'; uiautomator dump '%s' >/dev/null 2>&1; chmod 666 '%s'" % (path, path, path))
    xml = ""
    for _ in range(6):
        try:
            with open(path, encoding="utf-8", errors="replace") as f:
                xml = f.read()
            if "<hierarchy" in xml:
                break
        except OSError:
            pass
        time.sleep(0.5)
    try:
        os.remove(path)
    except OSError:
        pass
    a, b = xml.find("<hierarchy"), xml.rfind("</hierarchy>")
    if a < 0 or b < 0:
        return None
    try:
        root = ET.fromstring(xml[a:b + len("</hierarchy>")])
    except ET.ParseError:
        return None
    seen, items = set(), []
    for node in root.iter("node"):
        if node.get("package") == APP_PKG:
            continue
        for attr in ("text", "content-desc"):
            v = (node.get(attr) or "").strip()
            if len(v) >= 2 and v not in seen:
                seen.add(v)
                items.append(v)
    return items


def _look(question, with_text, player):
    data, err = _screenshot()
    if data is None:
        return "Не удалось сделать снимок экрана: %s" % err
    note = ""
    black = len(data) < BLACK_BYTES
    if black or with_text:
        texts = _ui_texts()
        if texts:
            note = "Текст интерфейса приложения на экране (из системы, не с картинки): " + "; ".join(texts[:MAX_UI_TEXTS])
    if black:
        note = ("Снимок почти чёрный: видео или защищённый контент в снимок не попадают. " + note).strip()
    import brain  # поздний импорт: brain сам загружает этот плагин
    answer = brain.vision(question, data, "image/png", note)
    if black and "чёрн" not in answer.lower() and "черн" not in answer.lower():
        answer += " Кадр на снимке почти чёрный: видео могло не попасть в снимок."
    return answer


def run(parameters, player=None, session_memory=None):
    action = str(parameters.get("action") or "look").lower()
    try:
        if action == "text":
            texts = _ui_texts()
            if not texts:
                return "Не удалось прочитать текст с экрана."
            if player is not None:
                player.show_content("На экране", "\n".join("%d. %s" % (i + 1, t) for i, t in enumerate(texts[:60])))
            return "На экране: %s." % "; ".join(texts[:10])
        if action in ("look", "see", ""):
            return _look(str(parameters.get("question") or ""), bool(parameters.get("with_text")), player)
        return "Неизвестное действие: %s" % action
    except Exception as e:
        return "Ошибка: %s: %s" % (type(e).__name__, e)
