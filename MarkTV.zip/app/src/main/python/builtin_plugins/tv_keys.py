import android_bridge as android

PLUGIN = {
    "name": "tv_keys",
    "description": (
        "Нажать кнопку пульта телевизора: громкость, пауза, назад, домой и т.д. "
        "Допустимые значения key: volume_up, volume_down, mute, play_pause, play, pause, stop, "
        "next, prev, ff, rew, up, down, left, right, ok, back, home, menu, channel_up, "
        "channel_down, info, guide, tv, input, settings, red, green, yellow, blue. "
        "times — сколько раз нажать (например, громкость на 5 шагов)."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "key": {"type": "STRING", "description": "Имя кнопки из списка"},
            "times": {"type": "INTEGER", "description": "Сколько раз нажать, по умолчанию 1"},
        },
        "required": ["key"],
    },
}


def run(parameters, player=None, session_memory=None):
    key = str(parameters.get("key", "")).strip()
    try:
        times = int(parameters.get("times") or 1)
    except (TypeError, ValueError):
        times = 1
    times = max(1, min(times, 30))
    res = android.keys([key] * times, delay=0.12)
    if str(res).startswith("ok"):
        return "Нажал %s ×%d." % (key, times)
    return "Не получилось: %s" % res
