"""screen_process — зрение Mark-LVII (main.py: screen_process / _flush_pending_vision, actions/screen_processor.py).

Как в оригинале:
  * зрение не непрерывное: кадр делается только при вызове инструмента, на этот момент;
  * кадр уменьшается до 1280x720 и сжимается в JPEG q82 (_compress);
  * cooldown 4 с и защита от параллельного вызова (_vision_busy / _vision_last_time);
  * результат инструмента — «[VISION_ACTIVE] … attached to this same exchange …»;
  * сразу после ответа инструмента кадр уходит в ТУ ЖЕ сессию как реплика пользователя
    «[IMAGE SOURCE: SCREEN CAPTURE]\n\n<вопрос>» (Kotlin: GeminiTts, brain.live_pending_vision).
Веб-камеры на ТВ нет, поэтому angle=camera не поддерживается.
"""
import base64
import json
import os
import threading
import time

import android_bridge as android

APP_PKG = "com.marktv"
DEFAULT_DIR = "/storage/emulated/0/Android/data/com.marktv/files"
IMG_MAX_W, IMG_MAX_H, JPEG_Q = 1280, 720, 82
COOLDOWN = 4.0        # секунд — как в оригинале
BUSY_TIMEOUT = 40.0   # страховка: если кадр так и не забрали, busy не должен залипнуть

_lock = threading.Lock()
_pending = None       # (bytes, mime, question)
_busy = False
_last = 0.0

PLUGIN = {
    "name": "screen_process",
    "description": (
        "Captures the screen image and lets you analyze it. "
        "MUST be called when user asks what is on screen, what you see, "
        "analyze my screen, etc. "
        "You have NO visual ability without this tool. "
        "After the image is captured it is sent directly to you — describe what you see and answer the user's question."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "angle": {"type": "STRING", "description": "'screen' to capture display. Default: 'screen'"},
            "text": {"type": "STRING", "description": "The question or instruction about the captured image"},
        },
        "required": ["text"],
    },
}


def _dir():
    try:
        pd = str(android.host.pluginsDir())
    except Exception:
        pd = ""
    marker = "/Android/data/%s/files" % APP_PKG
    i = pd.find(marker)
    return (pd[:i] + marker) if i >= 0 else DEFAULT_DIR


def _read(path):
    for _ in range(8):
        try:
            if os.path.getsize(path) > 0:
                with open(path, "rb") as f:
                    return f.read()
        except OSError:
            pass
        time.sleep(0.4)
    return None


def _capture_screen():
    """actions/screen_processor._capture_screen: снимок экрана -> (bytes, mime). Исключение при неудаче."""
    d = _dir()
    png, jpg = d + "/screen_process.png", d + "/screen_process.jpg"
    android.shell("mkdir -p '%s'; rm -f '%s' '%s'; screencap -p '%s'; chmod 666 '%s'" % (d, png, jpg, png, png))
    raw = _read(png)
    if raw is None or raw[:8] != b"\x89PNG\r\n\x1a\n":
        raise RuntimeError("screencap не дал картинку")
    data, mime = raw, "image/png"
    # _compress: уменьшить до 1280x720 и в JPEG q82 (Host.compressImage); при неудаче уходит исходный PNG, как в оригинале
    comp = getattr(android.host, "compressImage", None)
    if callable(comp):
        try:
            if str(comp(png, jpg, IMG_MAX_W, IMG_MAX_H, JPEG_Q)).startswith("ok"):
                small = _read(jpg)
                if small:
                    data, mime = small, "image/jpeg"
        except Exception as e:
            android.log("screen_process: сжатие не удалось: %s" % e)
    for p in (png, jpg):
        try:
            os.remove(p)
        except OSError:
            pass
    return data, mime


def run(parameters, player=None, session_memory=None):
    global _pending, _busy, _last
    now = time.monotonic()
    with _lock:
        if _busy and now - _last > BUSY_TIMEOUT:
            _busy = False
        if _busy or (now - _last) < COOLDOWN:
            wait = max(0.0, COOLDOWN - (now - _last))
            android.log("[Vision] cooldown (%.1fs) — повторный вызов пропущен" % wait)
            return "Vision is still processing the previous request. I will not call this again."
        _busy = True
        _last = now
    angle = str(parameters.get("angle") or "screen").lower()
    question = str(parameters.get("text") or "What do you see?")
    if angle == "camera":
        with _lock:
            _busy = False
        return "There is no webcam on this TV."
    try:
        img, mime = _capture_screen()
    except Exception as e:
        with _lock:
            _busy = False
        return "Screen capture failed: %s" % e
    android.log("[Vision] Screen: %d bytes (%s)" % (len(img), mime))
    with _lock:
        _pending = (img, mime, question)
    return ("[VISION_ACTIVE] Screen captured and attached to this same exchange. Do not acknowledge and do not "
            "answer yet — the image is arriving with this result. Reply once, from what you actually see in it.")


def take_pending():
    """_flush_pending_vision: JSON {mime, data, text} для отправки в сессию сразу после ответа инструмента, либо ''."""
    global _pending, _busy
    with _lock:
        p, _pending = _pending, None
        _busy = False
    if not p:
        return ""
    img, mime, question = p
    return json.dumps({"mime": mime, "data": base64.b64encode(img).decode("ascii"),
                       "text": "[IMAGE SOURCE: SCREEN CAPTURE]\n\n" + question})
