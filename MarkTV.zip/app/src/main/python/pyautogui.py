"""Tiny pyautogui stand-in so desktop Mark plugins that only press keys can load on the TV.

press / write / typewrite / hotkey / keyDown are mapped to remote-control key
events. Mouse, screen and window calls do nothing (and log a line).
"""
import time

import android_bridge as _a

FAILSAFE = False
PAUSE = 0.0


def press(keys, presses=1, interval=0.1, **kwargs):
    seq = list(keys) if isinstance(keys, (list, tuple)) else [keys]
    for _ in range(int(presses)):
        for k in seq:
            _a.key(k)
            time.sleep(interval)


def keyDown(key, **kwargs):
    _a.key(key)


def keyUp(key, **kwargs):
    pass


def write(message, interval=0.1, **kwargs):
    for ch in str(message):
        _a.key(ch)
        time.sleep(interval)


typewrite = write


def hotkey(*keys, **kwargs):
    # No chords on a TV remote: press the last key only.
    if keys:
        _a.key(keys[-1])


def size():
    return (1920, 1080)


def __getattr__(name):
    if name.startswith("_"):
        raise AttributeError(name)

    def _noop(*args, **kwargs):
        _a.log("pyautogui.%s() не поддерживается на ТВ" % name)

    return _noop
