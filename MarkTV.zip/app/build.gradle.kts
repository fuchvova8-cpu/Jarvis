plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.marktv"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.marktv"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "0.2"

        // Xiaomi Mi TV 4A is most likely 32-bit (armeabi-v7a); arm64 is kept for newer boxes.
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

chaquopy {
    defaultConfig {
        version = "3.11"
        buildPython("python3")
        // No pip packages on purpose: the Python core uses only the standard library.
    }
}

dependencies {
    // ADB client used to send key events to the TV itself over 127.0.0.1:5555
    implementation("dev.mobile:dadb:1.2.10")
}
