"""Mark TV core: Gemini (REST, stdlib only) + plugin loader compatible with Mark-LV plugins.

A plugin is one .py file with
    PLUGIN = {"name": ..., "description": ..., "parameters": {"type": "OBJECT", ...}}
    def run(parameters, player=None, session_memory=None) -> str
Built-in plugins live in builtin_plugins/. Your own plugins go into the plugins
folder shown in the app (…/Android/data/com.marktv/files/plugins) and are picked
up on the next question, no rebuild needed.
"""
import importlib
import importlib.util
import json
import os
import re
import traceback
import urllib.error
import urllib.request

import android_bridge

host = None
API_KEY = ""
MODEL = "gemini-2.5-flash"
PLUGINS_DIR = ""

HISTORY = []
MAX_HISTORY = 24
SESSION_MEMORY = {}
MAX_STEPS = 6

BUILTIN = [
    "builtin_plugins.channel_keys",
    "builtin_plugins.tv_keys",
]

URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
NAME_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]{0,63}$")

SYSTEM = (
    "Ты Mark — голосовой ассистент на телевизоре. Отвечай по-русски, коротко: одно-два "
    "предложения, без markdown, списков и эмодзи, потому что ответ будет озвучен. "
    "Для управления телевизором используй доступные инструменты. Не утверждай, что действие "
    "выполнено, пока инструмент не вернул подтверждение; если инструмент вернул ошибку — "
    "так и скажи."
)

_plugins = {}   # name -> (PLUGIN dict, run callable, source)
_errors = []
_mtimes = {}    # path -> (mtime, module)


class Player:
    """What plugins receive as `player`. Desktop-only UI calls become harmless no-ops."""

    def write_log(self, text):
        host.log(str(text))

    def show_content(self, title, text):
        host.log("%s: %s" % (title, text))

    def speak(self, text):
        host.speak(str(text))

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)

        def _noop(*args, **kwargs):
            host.log("player.%s() не поддерживается на ТВ" % name)

        return _noop


PLAYER = Player()


def set_host(h):
    global host
    host = h
    android_bridge.set_host(h)


def configure(api_key, model, plugins_dir):
    global API_KEY, MODEL, PLUGINS_DIR
    API_KEY = (api_key or "").strip()
    MODEL = (model or "").strip() or "gemini-2.5-flash"
    PLUGINS_DIR = plugins_dir or ""


def _register(found, mod, source):
    p = getattr(mod, "PLUGIN", None)
    r = getattr(mod, "run", None)
    if not isinstance(p, dict) or not callable(r):
        raise ValueError("нет PLUGIN или run()")
    name = p.get("name")
    if not isinstance(name, str) or not NAME_RE.match(name):
        raise ValueError("некорректное имя плагина: %r" % (name,))
    found[name] = (p, r, source)


def load_plugins():
    global _plugins, _errors
    found, errors = {}, []
    for modname in BUILTIN:
        try:
            _register(found, importlib.import_module(modname), modname)
        except Exception as e:
            errors.append("%s: %s: %s" % (modname, type(e).__name__, e))
    if PLUGINS_DIR and os.path.isdir(PLUGINS_DIR):
        for fn in sorted(os.listdir(PLUGINS_DIR)):
            if not fn.endswith(".py") or fn.startswith("_"):
                continue
            path = os.path.join(PLUGINS_DIR, fn)
            try:
                mt = os.path.getmtime(path)
                cached = _mtimes.get(path)
                if cached and cached[0] == mt:
                    mod = cached[1]
                else:
                    spec = importlib.util.spec_from_file_location("userplugin_" + fn[:-3], path)
                    mod = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(mod)
                    _mtimes[path] = (mt, mod)
                _register(found, mod, path)
            except Exception as e:
                errors.append("%s: %s: %s" % (fn, type(e).__name__, e))
    _plugins, _errors = found, errors


def declarations():
    decls = []
    for name, (p, _run, _src) in _plugins.items():
        d = {"name": name, "description": str(p.get("description", ""))[:1000]}
        params = p.get("parameters")
        if isinstance(params, dict) and params.get("properties"):
            d["parameters"] = params
        decls.append(d)
    return decls


def describe_plugins():
    load_plugins()
    lines = ["Плагинов: %d" % len(_plugins)]
    for name, (_p, _r, src) in sorted(_plugins.items()):
        lines.append("  • %s  (%s)" % (name, os.path.basename(src) if os.sep in src else src))
    for e in _errors:
        lines.append("  ✗ " + e)
    return "\n".join(lines)


def _generate(tools):
    body = {
        "systemInstruction": {"parts": [{"text": SYSTEM}]},
        "contents": HISTORY,
    }
    if tools:
        body["tools"] = [{"functionDeclarations": tools}]
    req = urllib.request.Request(
        URL.format(model=MODEL),
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json", "x-goog-api-key": API_KEY},
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode("utf-8")).get("error", {}).get("message", "")
        except Exception:
            msg = ""
        raise RuntimeError("Gemini HTTP %s: %s" % (e.code, msg or e.reason))


def _run_tool(name, args):
    entry = _plugins.get(name)
    if entry is None:
        return "Неизвестный инструмент: %s" % name
    try:
        result = entry[1](args, PLAYER, SESSION_MEMORY)
        return str(result)[:2000]
    except Exception as e:
        host.log("плагин %s упал: %s" % (name, traceback.format_exc(limit=3)))
        return "Ошибка плагина %s: %s: %s" % (name, type(e).__name__, e)


def _trim():
    while len(HISTORY) > MAX_HISTORY:
        HISTORY.pop(0)
    # history must start with a user turn that has text (never with a functionResponse)
    while HISTORY:
        first = HISTORY[0]
        if first.get("role") == "user" and any("text" in p for p in first.get("parts", [])):
            break
        HISTORY.pop(0)


def ask(text):
    if not API_KEY:
        return "Не задан ключ Gemini. Откройте настройки приложения и вставьте ключ."
    load_plugins()
    start = len(HISTORY)
    HISTORY.append({"role": "user", "parts": [{"text": text}]})
    tools = declarations()
    try:
        for _ in range(MAX_STEPS):
            resp = _generate(tools)
            cands = resp.get("candidates") or [{}]
            cand = cands[0]
            parts = (cand.get("content") or {}).get("parts") or []
            if not parts:
                reason = cand.get("finishReason") or resp.get("promptFeedback") or "пустой ответ"
                del HISTORY[start:]
                return "Модель не ответила (%s)." % (reason,)
            HISTORY.append({"role": "model", "parts": parts})
            calls = [p["functionCall"] for p in parts if "functionCall" in p]
            if not calls:
                answer = "".join(p.get("text", "") for p in parts if not p.get("thought")).strip()
                _trim()
                return answer or "Готово."
            out = []
            for c in calls:
                result = _run_tool(c.get("name", ""), c.get("args") or {})
                out.append({"functionResponse": {"name": c.get("name", ""), "response": {"result": result}}})
            HISTORY.append({"role": "user", "parts": out})
        _trim()
        return "Слишком много шагов подряд, остановился."
    except Exception as e:
        del HISTORY[start:]
        host.log("ask: %s" % traceback.format_exc(limit=4))
        return "Ошибка: %s" % (e,)
