"""Bridge between Python plugins and the TV: press keys, run shell, speak.

    import android_bridge as android
    android.key("volume_up")          # by name or Android keycode
    android.keys(["3", "2", "7"], delay=0.2)
    android.type_text("327")

Key events are injected over ADB to 127.0.0.1 (see KeyInjector.kt).
"""
import time

host = None


def set_host(h):
    global host
    host = h


KEYS = {
    # navigation
    "up": 19, "down": 20, "left": 21, "right": 22,
    "ok": 23, "center": 23, "select": 23,
    "enter": 66, "return": 66,
    "back": 4, "esc": 4, "escape": 4,
    "home": 3, "menu": 82, "tab": 61,
    "space": 62, " ": 62,
    "backspace": 67, "delete": 112,
    "pageup": 92, "pagedown": 93,
    # volume / media
    "volume_up": 24, "volumeup": 24,
    "volume_down": 25, "volumedown": 25,
    "mute": 164, "volumemute": 164,
    "play_pause": 85, "playpause": 85,
    "play": 126, "pause": 127, "stop": 86,
    "next": 87, "nexttrack": 87,
    "prev": 88, "prevtrack": 88, "previous": 88,
    "ff": 90, "rew": 89,
    # TV
    "channel_up": 166, "channel_down": 167,
    "info": 165, "guide": 172, "tv": 170, "input": 178, "settings": 176,
    "red": 183, "green": 184, "yellow": 185, "blue": 186,
    "power": 26, "search": 84,
    # punctuation
    ".": 56, ",": 55, "-": 69,
}
for _d in range(10):
    KEYS[str(_d)] = 7 + _d
for _i, _c in enumerate("abcdefghijklmnopqrstuvwxyz"):
    KEYS[_c] = 29 + _i


def code_of(k):
    if isinstance(k, int):
        return k
    s = str(k).strip().lower()
    if s in KEYS:
        return KEYS[s]
    if s.isdigit():
        return int(s)
    raise ValueError("неизвестная клавиша: %r" % (k,))


def key(k):
    """Press one key. Returns 'ok…' or an error text starting with 'ADB:' / 'Ошибка'."""
    try:
        code = code_of(k)
    except ValueError as e:
        return "Ошибка: %s" % e
    return host.key(code)


def keys(seq, delay=0.15):
    """Press several keys in order with a pause between them."""
    seq = list(seq)
    try:
        codes = [code_of(k) for k in seq]
    except ValueError as e:
        return "Ошибка: %s" % e
    if not codes:
        return "ok"
    if delay <= 0:
        return host.shell("input keyevent " + " ".join(str(c) for c in codes))
    last = "ok"
    for i, c in enumerate(codes):
        last = host.key(c)
        if not str(last).startswith("ok"):
            return last
        if i < len(codes) - 1:
            time.sleep(delay)
    return last


def type_text(text, delay=0.15):
    return keys(list(str(text)), delay)


def shell(cmd):
    return host.shell(cmd)


def speak(text):
    host.speak(str(text))


def log(text):
    host.log(str(text))


# ---------- search providers of other apps (in-app ContentResolver, no root) ----------

def in_app_search():
    """True, если приложение умеет само опрашивать поисковые провайдеры других приложений."""
    return hasattr(host, "searchQuery")


def has_global_search():
    try:
        return bool(host.hasGlobalSearch())
    except Exception:
        return False


def provider_list():
    """[(authority, package)] of apps with search providers, or None if the host can't tell."""
    try:
        out = str(host.searchProviders())
    except Exception:
        return None
    if out.startswith("ERR:"):
        return None
    res = []
    for line in out.splitlines():
        if "|" in line:
            a, p = line.split("|", 1)
            res.append((a.strip(), p.strip()))
    return res


def provider_query(authority, query, limit=20):
    """Query a search provider from inside the app. Returns (rows, error); rows is a list of dicts."""
    import json
    try:
        out = str(host.searchQuery(authority, query, int(limit)))
    except Exception as e:
        return None, "%s: %s" % (type(e).__name__, e)
    if out.startswith("ERR:"):
        return None, out[4:].strip()
    try:
        return json.loads(out), None
    except ValueError:
        return None, "bad json"


def query_uri(uri, selection=None, arg=None):
    """Any content:// query from inside the app. Returns (rows, error)."""
    import json
    try:
        out = str(host.queryUri(uri, selection, arg))
    except Exception as e:
        return None, "%s: %s" % (type(e).__name__, e)
    if out.startswith("ERR:"):
        return None, out[4:].strip()
    try:
        return json.loads(out), None
    except ValueError:
        return None, "bad json"


def show_results(title, items):
    """Poster grid on the Jarvis screen. items: [{title, sub, image, cmd, app}]. Returns True if shown."""
    import json
    try:
        host.showResults(str(title), json.dumps(items, ensure_ascii=False))
        return True
    except Exception:
        return False
