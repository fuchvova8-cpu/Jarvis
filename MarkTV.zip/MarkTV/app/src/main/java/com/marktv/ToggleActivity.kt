package com.marktv

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/** Invisible activity: flips "microphone always on" and closes immediately. */
class ToggleActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as App
        if (!app.voice.hasPermission()) {
            Toast.makeText(this, "Mark: нет разрешения на микрофон", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, MainActivity::class.java))
        } else {
            val on = !app.voice.continuous
            app.voice.setContinuous(on)
            Toast.makeText(this, if (on) "Mark: микрофон ВКЛ" else "Mark: микрофон ВЫКЛ", Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
