package com.marktv

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

class MainActivity : Activity() {

    private lateinit var app: App
    private lateinit var orb: OrbView
    private lateinit var status: TextView
    private lateinit var partial: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var keyEdit: EditText
    private lateinit var modelEdit: EditText
    private lateinit var contBtn: Button

    private val logListener: (String) -> Unit = { line ->
        logView.append(line + "\n")
        scroll.post { scroll.scrollTo(0, logView.height) }
    }
    private val stateListener: () -> Unit = { refresh() }
    private val levelListener: () -> Unit = { orb.level = app.voice.rms }
    private val partialListener: (String) -> Unit = { partial.text = it }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float = 16f): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(0xFFFFFFFF.toInt())
    }

    private fun btn(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 16f
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = application as App

        if (!app.voice.hasPermission()) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF101418.toInt())
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }

        val leftScroll = ScrollView(this).apply { isFocusable = false }
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, dp(12), 0)
        }
        leftScroll.addView(left)

        orb = OrbView(this)
        orb.setOnClickListener {
            if (app.voice.state == VState.IDLE && !app.voice.continuous) app.voice.listenOnce()
            else app.voice.abort()
        }
        left.addView(orb, LinearLayout.LayoutParams(dp(170), dp(170)).apply { gravity = Gravity.CENTER_HORIZONTAL })

        status = label("", 18f).apply { gravity = Gravity.CENTER }
        partial = label("", 15f).apply { gravity = Gravity.CENTER }
        left.addView(status, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        left.addView(partial, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        keyEdit = EditText(this).apply {
            hint = "Gemini API key"
            setText(app.apiKey)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF888888.toInt())
        }
        modelEdit = EditText(this).apply {
            hint = "Модель Gemini"
            setText(app.model)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF888888.toInt())
        }
        left.addView(keyEdit)
        left.addView(modelEdit)
        left.addView(btn("Сохранить ключ и модель") {
            app.apiKey = keyEdit.text.toString()
            app.model = modelEdit.text.toString()
            app.log("Настройки сохранены (модель ${app.model}, ключ ${if (app.apiKey.isEmpty()) "ПУСТОЙ" else "задан"})")
        })

        contBtn = btn("") {
            app.voice.setContinuous(!app.voice.continuous)
        }
        left.addView(contBtn)
        left.addView(btn("Диагностика системы") { diagnose() })
        left.addView(btn("Тест микрофона (AudioRecord, 4 с)") { micTest() })
        left.addView(btn("Тест Gemini") {
            app.worker.execute {
                val r = try {
                    app.brain.ask("Ответь одним словом: привет")
                } catch (e: Throwable) {
                    "Ошибка: ${e.message}"
                }
                app.log("Gemini: $r")
            }
        })
        left.addView(btn("Тест ADB (echo)") {
            app.worker.execute { app.log("ADB echo: " + app.keys.shell("echo ok")) }
        })
        left.addView(btn("ADB: громкость + (клавиша 24)") {
            app.worker.execute { app.log("ADB key 24: " + app.keys.key(24)) }
        })
        left.addView(btn("Список плагинов") {
            app.worker.execute {
                val r = try {
                    app.brain.describePlugins()
                } catch (e: Throwable) {
                    "Ошибка: ${e.message}"
                }
                app.log(r)
            }
        })

        logView = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFFCCE0CC.toInt())
            setTextIsSelectable(false)
        }
        scroll = ScrollView(this).apply {
            isFocusable = true
            setBackgroundColor(0xFF0A0D10.toInt())
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(logView)
        }

        root.addView(leftScroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        root.addView(scroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.3f))
        setContentView(root)

        logView.text = app.history().joinToString("\n") + "\n"
        app.log("Плагины: ${app.pluginsDir().absolutePath}")
        app.log("Лог-файл: ${app.logFile.absolutePath}")
        refresh()

        // Connect to the TV's own adbd right away so the "Allow debugging?" prompt shows up now.
        Thread {
            app.log("ADB (127.0.0.1:5555): подтвердите запрос на ТВ, если он появился…")
            app.log("ADB: " + app.keys.shell("echo ok"))
        }.start()
    }

    override fun onStart() {
        super.onStart()
        app.addLogListener(logListener)
        app.voice.stateListeners.add(stateListener)
        app.voice.levelListeners.add(levelListener)
        app.voice.partialListeners.add(partialListener)
        refresh()
    }

    override fun onStop() {
        app.removeLogListener(logListener)
        app.voice.stateListeners.remove(stateListener)
        app.voice.levelListeners.remove(levelListener)
        app.voice.partialListeners.remove(partialListener)
        super.onStop()
    }

    private fun refresh() {
        orb.vstate = app.voice.state
        status.text = when (app.voice.state) {
            VState.IDLE -> "Нажмите OK на значке или кнопку микрофона"
            VState.LISTENING -> "Слушаю…"
            VState.THINKING -> "Думаю…"
            VState.SPEAKING -> "Говорю…"
        }
        if (app.voice.state != VState.LISTENING) partial.text = ""
        contBtn.text = if (app.voice.continuous) "Микрофон постоянно: ВКЛ (нажмите — выкл)"
        else "Микрофон постоянно: ВЫКЛ (нажмите — вкл)"
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0 && currentFocus !is EditText) {
            val k = e.keyCode
            val nav = k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN ||
                k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT ||
                k == KeyEvent.KEYCODE_DPAD_CENTER
            if (!nav) app.log("KEY $k ${KeyEvent.keyCodeToString(k)}")
        }
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0 &&
            (e.keyCode == KeyEvent.KEYCODE_SEARCH || e.keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
                e.keyCode == KeyEvent.KEYCODE_ASSIST)
        ) {
            orb.performClick()
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        app.log("Разрешение на микрофон: ${if (ok) "получено" else "ОТКАЗАНО"}")
    }

    private fun typeName(t: Int): String = when (t) {
        15 -> "встроенный микрофон"
        11 -> "USB-устройство"
        22 -> "USB-гарнитура"
        7 -> "Bluetooth SCO"
        8 -> "Bluetooth A2DP"
        25 -> "remote submix"
        else -> "тип $t"
    }

    private fun diagnose() {
        app.log("— Диагностика —")
        app.log("Устройство: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        app.log("ABI: ${Build.SUPPORTED_ABIS.joinToString()}")
        app.log("RECORD_AUDIO: ${if (app.voice.hasPermission()) "есть" else "НЕТ"}")
        app.log("SpeechRecognizer доступен: ${SpeechRecognizer.isRecognitionAvailable(this)}")
        val svcs = packageManager.queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), 0)
        app.log("Службы распознавания: " + if (svcs.isEmpty()) "нет" else svcs.joinToString { it.serviceInfo.packageName })
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        val ins = am.getDevices(AudioManager.GET_DEVICES_INPUTS)
        app.log("Аудиовходы: " + if (ins.isEmpty()) "нет" else ins.joinToString { "${it.productName} [${typeName(it.type)}]" })
        app.log("TTS: ${app.tts.info()}")
        app.log("Ключ Gemini: ${if (app.apiKey.isEmpty()) "НЕ ЗАДАН" else "задан"}, модель ${app.model}")
    }

    private fun micTest() {
        if (!app.voice.hasPermission()) {
            app.log("Тест микрофона: нет разрешения")
            return
        }
        app.log("Тест микрофона: говорите 4 секунды…")
        Thread {
            try {
                val rate = 16000
                val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val ar = AudioRecord(
                    MediaRecorder.AudioSource.MIC, rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, 4096) * 2
                )
                if (ar.state != AudioRecord.STATE_INITIALIZED) {
                    app.log("AudioRecord не запустился (нет источника звука)")
                    ar.release()
                    return@Thread
                }
                ar.startRecording()
                val buf = ShortArray(1600)
                var peak = 0
                var sum = 0.0
                var n = 0L
                val end = System.currentTimeMillis() + 4000
                while (System.currentTimeMillis() < end) {
                    val r = ar.read(buf, 0, buf.size)
                    if (r <= 0) break
                    for (i in 0 until r) {
                        val v = abs(buf[i].toInt())
                        if (v > peak) peak = v
                        sum += v.toDouble() * v
                        n++
                    }
                }
                ar.stop()
                ar.release()
                val rms = if (n > 0) sqrt(sum / n) else 0.0
                val verdict = if (peak < 60) "ТИШИНА — микрофона нет или он не отдаёт звук приложениям"
                else "звук есть"
                app.log("AudioRecord: пик=$peak rms=${rms.toInt()} из 32767 → $verdict")
            } catch (e: Throwable) {
                app.log("AudioRecord: ${e.javaClass.simpleName}: ${e.message}")
            }
        }.start()
    }
}
