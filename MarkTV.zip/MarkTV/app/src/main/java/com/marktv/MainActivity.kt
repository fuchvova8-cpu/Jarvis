package com.marktv

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Main screen: the orb, what was heard, what Mark answered, and the "microphone always on" button.
 * Settings, tests and the raw log live in SettingsActivity (MENU key or the Settings button).
 */
class MainActivity : Activity() {

    private lateinit var app: App
    private lateinit var orb: OrbView
    private lateinit var status: TextView
    private lateinit var partial: TextView
    private lateinit var youText: TextView
    private lateinit var answerLabel: TextView
    private lateinit var answerText: TextView
    private lateinit var contBtn: Button

    private val white = 0xFFFFFFFF.toInt()
    private val accent = 0xFF42D7FF.toInt()
    private val muted = 0xFF8A98A6.toInt()
    private val bg = 0xFF0B0F14.toInt()
    private val card = 0xFF121A22.toInt()

    private val logListener: (String) -> Unit = { line -> applyLine(line) }
    private val stateListener: () -> Unit = { refresh() }
    private val levelListener: () -> Unit = { orb.level = app.voice.rms }
    private val partialListener: (String) -> Unit = { partial.text = it }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun shape(fill: Int, stroke: Int, strokeW: Int): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(14).toFloat()
        setColor(fill)
        setStroke(strokeW, stroke)
    }

    private fun tvButton(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 22f
        isAllCaps = false
        isFocusable = true
        stateListAnimator = null
        setPadding(dp(28), dp(14), dp(28), dp(14))
        setOnClickListener { onClick() }
        setOnFocusChangeListener { v, f ->
            v.animate().scaleX(if (f) 1.05f else 1f).scaleY(if (f) 1.05f else 1f).setDuration(120).start()
        }
        paintButton(this, false)
    }

    private fun paintButton(b: Button, on: Boolean) {
        val fill = if (on) accent else 0xFF1B242D.toInt()
        val edge = if (on) accent else 0xFF33414E.toInt()
        b.background = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), shape(fill, white, dp(3)))
            addState(intArrayOf(), shape(fill, edge, dp(2)))
        }
        b.setTextColor(if (on) 0xFF06202A.toInt() else white)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = application as App

        if (!app.voice.hasPermission()) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }

        // TV safe area: ~5% on the sides, ~5% top and bottom.
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(48), dp(27), dp(48), dp(27))
        }

        // ── top row: orb column + answer card ──
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        orb = OrbView(this)
        orb.setOnClickListener {
            if (app.voice.state == VState.IDLE && !app.voice.continuous) app.voice.listenOnce()
            else app.voice.abort()
        }
        left.addView(orb, LinearLayout.LayoutParams(dp(260), dp(260)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        status = text(30f, white, true).apply { gravity = Gravity.CENTER }
        partial = text(22f, accent).apply { gravity = Gravity.CENTER; maxLines = 3 }
        left.addView(status, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        left.addView(partial, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val cardBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(card, 0xFF1F2B36.toInt(), dp(1))
            setPadding(dp(28), dp(22), dp(28), dp(22))
        }
        cardBox.addView(text(16f, muted, true).apply { this.text = "ВЫ" })
        youText = text(26f, white)
        cardBox.addView(youText)
        answerLabel = text(16f, accent, true).apply {
            this.text = "MARK"
            setPadding(0, dp(18), 0, 0)
        }
        cardBox.addView(answerLabel)
        answerText = text(30f, white)
        val answerScroll = ScrollView(this).apply {
            isFocusable = false
            addView(answerText)
        }
        cardBox.addView(answerScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        top.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        top.addView(cardBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.4f).apply {
            leftMargin = dp(24)
        })
        root.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // ── buttons ──
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        contBtn = tvButton("") { app.voice.setContinuous(!app.voice.continuous) }
        buttons.addView(contBtn)
        val settingsBtn = tvButton("Настройки") { openSettings() }
        buttons.addView(settingsBtn, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { leftMargin = dp(16) })
        root.addView(buttons, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(18) })

        // ── hint ──
        val hint = text(18f, muted).apply {
            this.text = "Скажите: «канал 5» · «громче на пять» · «smart» · «lazy»      MENU — настройки"
        }
        root.addView(hint, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) })

        setContentView(root)

        // restore the last exchange from the log
        val hist = app.history()
        hist.asReversed().firstOrNull { it.contains("Вы: ") }?.let { applyLine(it) }
        hist.asReversed().firstOrNull { it.contains("Mark: ") }?.let { applyLine(it) }
        if (youText.text.isNullOrEmpty() && answerText.text.isNullOrEmpty()) {
            youText.text = "—"
            answerText.text = "Нажмите OK на шаре или кнопку микрофона на пульте."
        }
        refresh()
        contBtn.requestFocus()

        // Connect to the TV's own adbd right away so the "Allow debugging?" prompt shows up now.
        Thread {
            app.log("ADB (127.0.0.1:5555): подтвердите запрос на ТВ, если он появился…")
            app.log("ADB: " + app.keys.shell("echo ok"))
        }.start()
    }

    /** Fills the card from a log line (lines look like "HH:mm:ss  Вы: …"). */
    private fun applyLine(line: String) {
        val you = line.indexOf("Вы: ")
        val mark = line.indexOf("Mark: ")
        if (you >= 0) {
            youText.text = line.substring(you + 4)
        } else if (mark >= 0) {
            answerLabel.text = "MARK"
            answerLabel.setTextColor(accent)
            answerText.text = line.substring(mark + 6)
        } else if (line.contains("ошибка") || line.contains("Нет разрешения") || line.contains("недоступен")) {
            answerLabel.text = "ПРОБЛЕМА"
            answerLabel.setTextColor(0xFFF9A825.toInt())
            answerText.text = line.substring(minOf(line.length, 10)).trim()
        }
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    override fun onStart() {
        super.onStart()
        app.addLogListener(logListener)
        app.voice.stateListeners.add(stateListener)
        app.voice.levelListeners.add(levelListener)
        app.voice.partialListeners.add(partialListener)
        refresh()
    }

    override fun onStop() {
        app.removeLogListener(logListener)
        app.voice.stateListeners.remove(stateListener)
        app.voice.levelListeners.remove(levelListener)
        app.voice.partialListeners.remove(partialListener)
        super.onStop()
    }

    private fun refresh() {
        orb.vstate = app.voice.state
        status.text = when (app.voice.state) {
            VState.IDLE -> "Готов"
            VState.LISTENING -> "Слушаю…"
            VState.THINKING -> "Думаю…"
            VState.SPEAKING -> "Говорю…"
        }
        if (app.voice.state != VState.LISTENING) partial.text = ""
        val on = app.voice.continuous
        contBtn.text = if (on) "Микрофон постоянно: ВКЛ" else "Микрофон постоянно: ВЫКЛ"
        paintButton(contBtn, on)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
            val k = e.keyCode
            when (k) {
                KeyEvent.KEYCODE_MENU -> {
                    openSettings()
                    return true
                }
                KeyEvent.KEYCODE_SEARCH, KeyEvent.KEYCODE_VOICE_ASSIST, KeyEvent.KEYCODE_ASSIST -> {
                    orb.performClick()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT,
                KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_CENTER -> {}
                else -> app.log("KEY $k ${KeyEvent.keyCodeToString(k)}")
            }
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        app.log("Разрешение на микрофон: ${if (ok) "получено" else "ОТКАЗАНО"}")
    }
}
