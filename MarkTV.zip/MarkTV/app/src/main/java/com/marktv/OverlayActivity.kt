package com.marktv

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Translucent "listen once" window for use on top of the TV player.
 * Bind it to a remote button with TV Quick Actions.
 */
class OverlayActivity : Activity() {

    private lateinit var app: App
    private lateinit var orb: OrbView
    private lateinit var text: TextView
    private var contentShown = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private val stateListener: () -> Unit = {
        orb.vstate = app.voice.state
        when (app.voice.state) {
            VState.LISTENING -> text.text = "Слушаю…"
            VState.THINKING -> text.text = "Думаю…"
            VState.SPEAKING -> {}
            VState.IDLE -> {}
        }
    }
    private val levelListener: () -> Unit = { orb.level = app.voice.rms }
    private val contentListener: (String, String) -> Unit = { title, body ->
        contentShown = true
        text.text = "$title\n$body"
        text.textSize = 18f
        text.maxLines = 9
    }
    private val partialListener: (String) -> Unit = { text.text = it }
    private val logListener: (String) -> Unit = { line ->
        val i = line.indexOf("Mark: ")
        if (i >= 0) {
            text.text = line.substring(i + 6)
        } else if (line.contains("ошибка") || line.contains("Нет разрешения") || line.contains("недоступен")) {
            text.text = line.substring(minOf(line.length, 10))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = application as App

        if (!app.voice.hasPermission()) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        val root = FrameLayout(this)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xE6101418.toInt())
            setPadding(dp(16), dp(8), dp(24), dp(8))
        }
        orb = OrbView(this)
        panel.addView(orb, LinearLayout.LayoutParams(dp(90), dp(90)))
        text = TextView(this).apply {
            textSize = 22f
            setTextColor(Color.WHITE)
            this.text = "Слушаю…"
            maxLines = 4
        }
        panel.addView(text, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(
            panel,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        )
        setContentView(root)

        app.addLogListener(logListener)
        app.addContentListener(contentListener)
        app.voice.stateListeners.add(stateListener)
        app.voice.levelListeners.add(levelListener)
        app.voice.partialListeners.add(partialListener)

        app.voice.listenOnce {
            if (contentShown) {
                app.main.postDelayed({ if (!isFinishing) finish() }, 20_000)
            } else {
                finish()
            }
        }
        // safety net: never hang on screen
        app.main.postDelayed({ if (!isFinishing) finish() }, 60_000)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && e.keyCode == KeyEvent.KEYCODE_BACK) {
            app.voice.abort()
            finish()
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onDestroy() {
        if (::app.isInitialized) {
            app.removeLogListener(logListener)
            app.removeContentListener(contentListener)
            app.voice.stateListeners.remove(stateListener)
            app.voice.levelListeners.remove(levelListener)
            app.voice.partialListeners.remove(partialListener)
            app.voice.cancelOneShot()
        }
        super.onDestroy()
    }
}
