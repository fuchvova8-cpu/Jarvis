package com.marktv

import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

/** Thin wrapper around the Python core (app/src/main/python/brain.py). Call from worker threads only. */
class Brain(private val app: App) {

    private var mod: PyObject? = null

    @Synchronized
    private fun module(): PyObject {
        mod?.let { return it }
        if (!Python.isStarted()) Python.start(AndroidPlatform(app))
        val m = Python.getInstance().getModule("brain")
        m.callAttr("set_host", Host(app))
        mod = m
        app.log("Python запущен")
        return m
    }

    private fun configured(): PyObject {
        val m = module()
        m.callAttr("configure", app.apiKey, app.model, app.pluginsDir().absolutePath)
        return m
    }

    fun ask(text: String): String = configured().callAttr("ask", text).toString()

    fun describePlugins(): String = configured().callAttr("describe_plugins").toString()
}
