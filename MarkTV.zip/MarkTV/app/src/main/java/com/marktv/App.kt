package com.marktv

import android.app.Application
import android.content.Intent
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import java.io.File
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

class App : Application() {

    val main = Handler(Looper.getMainLooper())
    val worker = Executors.newSingleThreadExecutor()

    lateinit var prefs: SharedPreferences
    lateinit var tts: Tts
    lateinit var voice: Voice
    lateinit var brain: Brain
    lateinit var keys: KeyInjector

    private val lines = ArrayDeque<String>()
    private val logListeners = CopyOnWriteArrayList<(String) -> Unit>()
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    val logFile: File by lazy { File(getExternalFilesDir(null) ?: filesDir, "marktv.log") }

    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(v) { prefs.edit().putString("api_key", v.trim()).apply() }

    var accent: String
        get() = prefs.getString("accent", Hud.DEFAULT_ACCENT) ?: Hud.DEFAULT_ACCENT
        set(v) { prefs.edit().putString("accent", v).apply() }

    var model: String
        get() = prefs.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) { prefs.edit().putString("model", v.trim().ifEmpty { DEFAULT_MODEL }).apply() }

    override fun onCreate() {
        super.onCreate()
        inst = this
        prefs = getSharedPreferences("marktv", MODE_PRIVATE)
        Hud.applyAccent(accent)
        try {
            if (logFile.exists() && logFile.length() > 500_000) logFile.delete()
        } catch (ignored: Throwable) {
        }
        tts = Tts(this)
        voice = Voice(this)
        brain = Brain(this)
        keys = KeyInjector(this)
        log("Mark TV запущен")
    }

    fun pluginsDir(): File {
        val d = File(getExternalFilesDir(null) ?: filesDir, "plugins")
        d.mkdirs()
        return d
    }

    fun log(msg: String) {
        val line = timeFmt.format(Date()) + "  " + msg
        android.util.Log.i("MarkTV", msg)
        synchronized(lines) {
            lines.addLast(line)
            while (lines.size > 400) lines.removeFirst()
        }
        try {
            logFile.appendText(line + "\n")
        } catch (ignored: Throwable) {
        }
        main.post { for (l in logListeners) l(line) }
    }

    fun history(): List<String> = synchronized(lines) { lines.toList() }

    fun addLogListener(l: (String) -> Unit) {
        logListeners.add(l)
    }

    fun removeLogListener(l: (String) -> Unit) {
        logListeners.remove(l)
    }

    @Volatile var lastTitle = ""
    @Volatile var lastText = ""
    @Volatile var shownAt = 0L
    @Volatile var adbProbed = false

    /** Puts a title and text on the TV screen (ResultsActivity). Safe to call from any thread. */
    fun showContent(title: String, text: String) {
        lastTitle = title
        lastText = text
        shownAt = System.currentTimeMillis()
        log("На экран: $title")
        main.post {
            try {
                val i = Intent(this, ResultsActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                startActivity(i)
            } catch (e: Throwable) {
                log("Не удалось открыть экран результатов: ${e.message}")
            }
        }
    }

    companion object {
        const val DEFAULT_MODEL = "gemini-2.5-flash"
        lateinit var inst: App
    }
}
