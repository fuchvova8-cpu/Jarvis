package com.marktv

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Results panel on the right side of the screen: search results and long answers.
 * D-pad up/down scrolls it, Back closes it, it closes itself after 40 s of inactivity.
 */
class ResultsActivity : Activity() {

    private lateinit var app: App
    private lateinit var titleView: TextView
    private lateinit var body: TextView
    private lateinit var scroll: ScrollView
    private val closeRunnable = Runnable { finish() }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = application as App

        val dm = resources.displayMetrics
        val root = FrameLayout(this)
        val card = HudPanel(this)
        titleView = TextView(this).apply {
            textSize = 22f
            setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL), Typeface.NORMAL)
            setTextColor(Hud.CYAN)
            letterSpacing = 0.12f
        }
        body = TextView(this).apply {
            textSize = 20f
            setTextColor(Hud.TEXT)
            setLineSpacing(0f, 1.12f)
        }
        scroll = ScrollView(this).apply {
            isFocusable = true
            isFocusableInTouchMode = true
            addView(body)
        }
        card.addView(titleView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        card.addView(
            scroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (dm.heightPixels * 0.62f).toInt()).apply {
                topMargin = dp(12)
            }
        )
        root.addView(
            card,
            FrameLayout.LayoutParams(
                (dm.widthPixels * 0.58f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.END or Gravity.CENTER_VERTICAL
            ).apply { marginEnd = dp(24) }
        )
        setContentView(root)
        scroll.requestFocus()
        render()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        render()
    }

    private fun render() {
        titleView.text = app.lastTitle.uppercase()
        body.text = app.lastText
        scroll.scrollTo(0, 0)
        restartTimer()
    }

    private fun restartTimer() {
        app.main.removeCallbacks(closeRunnable)
        app.main.postDelayed(closeRunnable, 40_000)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                finish()
                return true
            }
            restartTimer()
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onDestroy() {
        app.main.removeCallbacks(closeRunnable)
        super.onDestroy()
    }
}
