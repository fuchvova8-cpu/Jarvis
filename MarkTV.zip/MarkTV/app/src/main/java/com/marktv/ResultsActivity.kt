package com.marktv

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

/**
 * Results panel: long answers as text, or search results as a grid of poster cards.
 * Poster cards come as JSON: [{"title","sub","image","cmd","app"}]. D-pad moves between cards,
 * OK opens the title in its app, Back closes the panel, it closes itself after a period of inactivity.
 */
class ResultsActivity : Activity() {

    private lateinit var app: App
    private lateinit var titleView: TextView
    private lateinit var body: TextView
    private lateinit var scroll: ScrollView
    private lateinit var postersScroll: ScrollView
    private lateinit var grid: LinearLayout
    private val closeRunnable = Runnable { finish() }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = application as App

        val dm = resources.displayMetrics
        val root = FrameLayout(this)
        val card = HudPanel(this)
        titleView = TextView(this).apply {
            textSize = 22f
            setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL), Typeface.NORMAL)
            setTextColor(Hud.CYAN)
            letterSpacing = 0.12f
        }
        body = TextView(this).apply {
            textSize = 20f
            setTextColor(Hud.TEXT)
            setLineSpacing(0f, 1.12f)
        }
        scroll = ScrollView(this).apply {
            isFocusable = true
            isFocusableInTouchMode = true
            addView(body)
        }
        grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        postersScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(grid)
        }
        val areaH = (dm.heightPixels * 0.74f).toInt()
        card.addView(titleView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        card.addView(
            scroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, areaH).apply { topMargin = dp(12) }
        )
        card.addView(
            postersScroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, areaH).apply { topMargin = dp(12) }
        )
        root.addView(
            card,
            FrameLayout.LayoutParams(
                (dm.widthPixels * 0.86f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.END or Gravity.CENTER_VERTICAL
            ).apply { marginEnd = dp(16) }
        )
        setContentView(root)
        render()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        render()
    }

    private fun render() {
        titleView.text = app.lastTitle.uppercase()
        val json = app.lastResults
        if (json.isNotEmpty()) {
            scroll.visibility = View.GONE
            postersScroll.visibility = View.VISIBLE
            try {
                buildGrid(JSONArray(json))
            } catch (e: Throwable) {
                app.log("Постеры: не разобрать данные: ${e.message}")
            }
        } else {
            postersScroll.visibility = View.GONE
            scroll.visibility = View.VISIBLE
            body.text = app.lastText
            scroll.scrollTo(0, 0)
            scroll.requestFocus()
        }
        restartTimer()
    }

    private fun buildGrid(arr: JSONArray) {
        grid.removeAllViews()
        val dm = resources.displayMetrics
        val cols = if (dm.widthPixels >= 1800) 6 else 5
        val avail = (dm.widthPixels * 0.86f).toInt() - dp(36) - dp(4)
        val cellW = avail / cols
        val posterW = cellW - dp(14)
        val posterH = (posterW * 1.5f).toInt()
        var row: LinearLayout? = null
        var first: View? = null
        for (i in 0 until arr.length()) {
            if (i % cols == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                grid.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            val cell = makeCell(i, arr.getJSONObject(i), cellW, posterW, posterH)
            row!!.addView(cell, LinearLayout.LayoutParams(cellW, ViewGroup.LayoutParams.WRAP_CONTENT))
            if (first == null) first = cell
        }
        postersScroll.scrollTo(0, 0)
        first?.requestFocus()
    }

    private fun makeCell(index: Int, item: JSONObject, cellW: Int, posterW: Int, posterH: Int): View {
        val title = item.optString("title")
        val sub = item.optString("sub")
        val image = item.optString("image")
        val cmd = item.optString("cmd")
        val appName = item.optString("app")

        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(7), dp(7), dp(7), dp(7))
            isFocusable = true
            isClickable = true
        }
        val focusBg = GradientDrawable().apply {
            cornerRadius = dp(6).toFloat()
            setColor(Hud.withAlpha(Hud.CYAN, 40))
            setStroke(dp(2), Hud.CYAN)
        }
        cell.setOnFocusChangeListener { v, has ->
            v.background = if (has) focusBg else null
            v.animate().scaleX(if (has) 1.05f else 1f).scaleY(if (has) 1.05f else 1f).setDuration(120).start()
            if (has) restartTimer()
        }
        cell.setOnClickListener {
            if (cmd.isNotEmpty()) {
                app.worker.execute { app.log("Открываю «$title»: " + app.keys.shell(cmd)) }
            }
            restartTimer()
        }

        val posterBox = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(4).toFloat()
                setColor(Hud.withAlpha(Hud.CYAN, 28))
            }
        }
        val letter = TextView(this).apply {
            text = title.trim().take(1).uppercase()
            textSize = 40f
            setTextColor(Hud.withAlpha(Hud.CYAN, 140))
            gravity = Gravity.CENTER
        }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        posterBox.addView(letter, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        posterBox.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val badge = TextView(this).apply {
            text = (index + 1).toString()
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(6), dp(1), dp(6), dp(1))
            background = GradientDrawable().apply {
                cornerRadius = dp(3).toFloat()
                setColor(0xCC000000.toInt())
            }
        }
        posterBox.addView(badge, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START).apply {
            topMargin = dp(4)
            marginStart = dp(4)
        })
        cell.addView(posterBox, LinearLayout.LayoutParams(posterW, posterH))

        cell.addView(TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(Hud.TEXT)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(posterW, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(5) })
        cell.addView(TextView(this).apply {
            text = sub
            textSize = 12f
            setTextColor(Hud.MUTED)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(posterW, ViewGroup.LayoutParams.WRAP_CONTENT))
        if (appName.isNotEmpty()) {
            cell.addView(TextView(this).apply {
                text = appName
                textSize = 11f
                setTextColor(Hud.CYAN)
                maxLines = 1
            }, LinearLayout.LayoutParams(posterW, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        if (image.isNotEmpty()) {
            Posters.load(app, image, posterW, posterH) { bmp ->
                if (bmp != null) {
                    img.setImageBitmap(bmp)
                    letter.visibility = View.GONE
                }
            }
        }
        return cell
    }

    private fun restartTimer() {
        app.main.removeCallbacks(closeRunnable)
        app.main.postDelayed(closeRunnable, if (app.lastResults.isNotEmpty()) 120_000 else 40_000)
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                finish()
                return true
            }
            restartTimer()
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onDestroy() {
        app.main.removeCallbacks(closeRunnable)
        super.onDestroy()
    }
}
