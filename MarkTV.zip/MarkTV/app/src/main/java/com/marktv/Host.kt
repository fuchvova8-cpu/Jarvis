package com.marktv

/** The object Python plugins talk to (android_bridge.py wraps it). Methods are called from a worker thread. */
class Host(private val app: App) {

    fun log(msg: String) {
        app.log("плагин: $msg")
    }

    fun speak(text: String) {
        app.main.post { app.tts.speak(text) }
    }

    fun setModel(name: String) {
        app.model = name
        app.log("Модель сохранена: $name")
    }

    fun key(code: Int): String = app.keys.key(code)

    fun shell(cmd: String): String = app.keys.shell(cmd)

    fun pluginsDir(): String = app.pluginsDir().absolutePath
}
