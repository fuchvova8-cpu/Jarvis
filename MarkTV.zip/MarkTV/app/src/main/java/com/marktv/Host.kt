package com.marktv

import android.app.SearchManager
import android.app.SearchableInfo
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** The object Python plugins talk to (android_bridge.py wraps it). Methods are called from a worker thread. */
class Host(private val app: App) {

    fun log(msg: String) {
        app.log("плагин: $msg")
    }

    fun speak(text: String) {
        app.main.post { app.tts.speak(text) }
    }

    fun showContent(title: String, text: String) {
        app.showContent(title, text)
    }

    fun setModel(name: String) {
        app.model = name
        app.log("Модель сохранена: $name")
    }

    fun key(code: Int): String = app.keys.key(code)

    fun shell(cmd: String): String = app.keys.shell(cmd)

    fun pluginsDir(): String = app.pluginsDir().absolutePath

    /** Description of a search provider as declared in the app's searchable.xml. */
    private class Spec(
        val pkg: String,
        val path: String,
        val selection: String?,
        val action: String?,
        val data: String?
    )

    private val specs = java.util.concurrent.ConcurrentHashMap<String, Spec>()

    private fun describe(e: Throwable): String {
        val sb = StringBuilder("${e.javaClass.simpleName}: ${e.message}")
        var c = e.cause
        var n = 0
        while (c != null && n < 2) {
            sb.append(" <- ${c.javaClass.simpleName}: ${c.message}")
            c = c.cause
            n++
        }
        return sb.toString()
    }

    /** Same as the system global search: SearchManager.getSearchablesInGlobalSearch() (hidden API, via reflection). */
    @Suppress("UNCHECKED_CAST")
    private fun scanSearchManager() {
        val sm = app.getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val m = SearchManager::class.java.getMethod("getSearchablesInGlobalSearch")
        val list = m.invoke(sm) as? List<SearchableInfo> ?: return
        for (si in list) {
            val auth = si.suggestAuthority ?: continue
            val pkg = si.searchActivity?.packageName ?: continue
            specs[auth] = Spec(pkg, si.suggestPath ?: "", si.suggestSelection, si.suggestIntentAction, si.suggestIntentData)
        }
    }

    /** Fallback when the hidden API is blocked: exported providers whose authority looks like search. */
    @Suppress("DEPRECATION")
    private fun scanPackages() {
        val pm = app.packageManager
        for (ai in pm.getInstalledApplications(0)) {
            val pi = try {
                pm.getPackageInfo(ai.packageName, PackageManager.GET_PROVIDERS)
            } catch (e: Throwable) {
                continue
            }
            for (pr in pi.providers ?: continue) {
                val auth = pr.authority ?: continue
                if (!pr.exported) continue
                if (!(auth.contains("search", true) || auth.contains("suggest", true))) continue
                for (a in auth.split(";")) if (!specs.containsKey(a)) specs[a] = Spec(ai.packageName, "", null, null, null)
            }
        }
    }

    /** Search providers of installed apps, one "authority|package" per line, or "ERR: ..." on failure. */
    fun searchProviders(): String {
        specs.clear()
        try {
            scanSearchManager()
        } catch (e: Throwable) {
            app.log("Провайдеры: SearchManager недоступен (${describe(e)}), сканирую пакеты")
        }
        try {
            scanPackages()
        } catch (e: Throwable) {
            if (specs.isEmpty()) return "ERR: ${describe(e)}"
        }
        val out = StringBuilder()
        for ((a, sp) in specs) out.append(a).append('|').append(sp.pkg).append('\n')
        app.log("Провайдеров поиска: ${specs.size}")
        return out.toString()
    }

    /**
     * Queries a provider exactly as the system search does (path / selection from its searchable.xml).
     * Returns a JSON array of rows (column -> text), or "ERR: ..." with the full exception.
     */
    fun searchQuery(authority: String, query: String, limit: Int): String {
        val sp = specs[authority] ?: Spec("", "", null, null, null)
        return try {
            val b = Uri.Builder().scheme("content").authority(authority)
            if (sp.path.isNotEmpty()) b.appendEncodedPath(sp.path)
            b.appendPath("search_suggest_query")
            var args: Array<String>? = null
            if (sp.selection != null) args = arrayOf(query) else b.appendPath(query)
            b.appendQueryParameter("limit", limit.toString())
            val rows = readRows(b.build(), sp.selection, args)
            for (i in 0 until rows.length()) {
                val o = rows.getJSONObject(i)
                sp.action?.let { o.put("_default_action", it) }
                sp.data?.let { o.put("_default_data", it) }
            }
            rows.toString()
        } catch (e: Throwable) {
            val err = describe(e)
            app.log("Поиск $authority: $err")
            "ERR: $err"
        }
    }

    /**
     * Generic provider query from inside the app: any content:// URI, optional selection with one argument.
     * Lets the Python plugin try different query styles without rebuilding the APK. JSON rows or "ERR: ...".
     */
    fun queryUri(uri: String, selection: String?, arg: String?): String {
        return try {
            readRows(Uri.parse(uri), selection, if (arg != null) arrayOf(arg) else null).toString()
        } catch (e: Throwable) {
            "ERR: ${describe(e)}"
        }
    }

    /** What the app declared in searchable.xml for this authority: JSON {pkg,path,selection,action,data}. */
    fun providerSpec(authority: String): String {
        val sp = specs[authority] ?: return "{}"
        val o = JSONObject()
        o.put("pkg", sp.pkg)
        o.put("path", sp.path)
        o.put("selection", sp.selection ?: JSONObject.NULL)
        o.put("action", sp.action ?: JSONObject.NULL)
        o.put("data", sp.data ?: JSONObject.NULL)
        return o.toString()
    }

    private fun readRows(uri: Uri, selection: String?, args: Array<String>?): JSONArray {
        val rows = JSONArray()
        val c = app.contentResolver.query(uri, null, selection, args, null) ?: return rows
        c.use {
            val names = it.columnNames
            while (it.moveToNext()) {
                val o = JSONObject()
                for (i in names.indices) {
                    try {
                        o.put(names[i], it.getString(i) ?: "")
                    } catch (ignored: Throwable) {
                    }
                }
                rows.put(o)
            }
        }
        return rows
    }
}
