package com.marktv

import android.content.pm.PackageManager
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** The object Python plugins talk to (android_bridge.py wraps it). Methods are called from a worker thread. */
class Host(private val app: App) {

    fun log(msg: String) {
        app.log("плагин: $msg")
    }

    fun speak(text: String) {
        app.main.post { app.tts.speak(text) }
    }

    fun showContent(title: String, text: String) {
        app.showContent(title, text)
    }

    fun setModel(name: String) {
        app.model = name
        app.log("Модель сохранена: $name")
    }

    fun key(code: Int): String = app.keys.key(code)

    fun shell(cmd: String): String = app.keys.shell(cmd)

    fun pluginsDir(): String = app.pluginsDir().absolutePath

    /** True when this app holds the privileged GLOBAL_SEARCH permission (installed as a system module). */
    fun hasGlobalSearch(): Boolean =
        app.checkSelfPermission("android.permission.GLOBAL_SEARCH") == PackageManager.PERMISSION_GRANTED

    /**
     * Search providers of installed apps, one "authority|package" per line.
     * Result starting with "ERR:" means the lookup failed.
     */
    @Suppress("DEPRECATION")
    fun searchProviders(): String {
        return try {
            val pm = app.packageManager
            val out = StringBuilder()
            for (ai in pm.getInstalledApplications(0)) {
                val pi = try {
                    pm.getPackageInfo(ai.packageName, PackageManager.GET_PROVIDERS)
                } catch (e: Throwable) {
                    continue
                }
                for (pr in pi.providers ?: continue) {
                    val auth = pr.authority ?: continue
                    if (!pr.exported) continue
                    val looks = pr.readPermission == "android.permission.GLOBAL_SEARCH" ||
                        auth.contains("search", true) || auth.contains("suggest", true)
                    if (!looks) continue
                    for (a in auth.split(";")) out.append(a).append('|').append(ai.packageName).append('\n')
                }
            }
            out.toString()
        } catch (e: Throwable) {
            "ERR: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    /**
     * Queries content://authority/search_suggest_query/<query> as this app (needs GLOBAL_SEARCH for most video apps).
     * Returns a JSON array of rows (column -> text), or "ERR: ..." on failure.
     */
    fun searchQuery(authority: String, query: String, limit: Int): String {
        return try {
            val uri = Uri.parse("content://$authority/search_suggest_query").buildUpon()
                .appendPath(query).appendQueryParameter("limit", limit.toString()).build()
            var rows = readRows(uri, null, null)
            if (rows.length() == 0) rows = readRows(Uri.parse("content://$authority/search_suggest_query")
                .buildUpon().appendQueryParameter("limit", limit.toString()).build(), "?", arrayOf(query))
            rows.toString()
        } catch (e: Throwable) {
            "ERR: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun readRows(uri: Uri, selection: String?, args: Array<String>?): JSONArray {
        val rows = JSONArray()
        val c = app.contentResolver.query(uri, null, selection, args, null) ?: return rows
        c.use {
            val names = it.columnNames
            while (it.moveToNext()) {
                val o = JSONObject()
                for (i in names.indices) {
                    try {
                        o.put(names[i], it.getString(i) ?: "")
                    } catch (ignored: Throwable) {
                    }
                }
                rows.put(o)
            }
        }
        return rows
    }
}
