package com.marktv

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/** The microphone "orb": focusable, clickable with OK on the remote. Colour and motion show the state. */
class OrbView(ctx: Context) : View(ctx) {

    var vstate: VState = VState.IDLE
        set(v) {
            field = v
            invalidate()
        }

    var level: Float = 0f
        set(v) {
            field = v
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var phase = 0f

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        isFocusable = true
        isClickable = true
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!anim.isStarted) anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val unit = min(width, height) / 2f
        val wave = sin(phase * 2.0 * PI).toFloat()
        val breath = when (vstate) {
            VState.IDLE -> 0.03f * wave
            VState.SPEAKING -> 0.06f * wave
            else -> 0f
        }
        val base = unit * 0.58f * (1f + breath)
        val col = when (vstate) {
            VState.IDLE -> 0xFF3A9FC4.toInt()
            VState.LISTENING -> 0xFF42D7FF.toInt()
            VState.THINKING -> 0xFFF9A825.toInt()
            VState.SPEAKING -> 0xFF2E7D32.toInt()
        }

        // soft glow
        paint.style = Paint.Style.FILL
        paint.color = col
        paint.alpha = 38
        c.drawCircle(cx, cy, base * (1.3f + 0.05f * wave), paint)

        if (vstate == VState.LISTENING) {
            val k = level.coerceIn(0f, 10f) / 10f
            paint.alpha = 80
            c.drawCircle(cx, cy, base * (1.05f + 0.4f * k), paint)
        }

        // main disc
        paint.alpha = 255
        paint.color = col
        c.drawCircle(cx, cy, base, paint)

        // thinking: a sweeping arc around the disc
        if (vstate == VState.THINKING) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = base * 0.09f
            paint.strokeCap = Paint.Cap.ROUND
            val r = base * 1.22f
            rect.set(cx - r, cy - r, cx + r, cy + r)
            c.drawArc(rect, phase * 360f, 100f, false, paint)
            paint.strokeCap = Paint.Cap.BUTT
        }

        // microphone glyph
        paint.style = Paint.Style.FILL
        paint.color = 0xFFFFFFFF.toInt()
        val w = base * 0.38f
        val h = base * 0.75f
        rect.set(cx - w / 2, cy - h / 2 - base * 0.1f, cx + w / 2, cy + h / 2 - base * 0.1f)
        c.drawRoundRect(rect, w / 2, w / 2, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = base * 0.07f
        val r = base * 0.42f
        rect.set(cx - r, cy - r * 0.9f, cx + r, cy + r * 0.9f)
        c.drawArc(rect, 20f, 140f, false, paint)
        c.drawLine(cx, cy + r * 0.9f, cx, cy + base * 0.62f, paint)

        if (isFocused) {
            paint.color = 0xFFFFFFFF.toInt()
            paint.strokeWidth = base * 0.06f
            c.drawCircle(cx, cy, base * 1.38f, paint)
        }
        paint.style = Paint.Style.FILL
    }
}
