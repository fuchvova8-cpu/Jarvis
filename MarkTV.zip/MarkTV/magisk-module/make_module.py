"""Собирает Magisk-модуль MarkTV-system-module.zip из готового APK.

    python make_module.py app-debug.apk
"""
import os
import sys
import zipfile

here = os.path.dirname(os.path.abspath(__file__))
tpl = os.path.join(here, "template")

if len(sys.argv) != 2 or not os.path.isfile(sys.argv[1]):
    sys.exit("Использование: python make_module.py путь\\к\\app-debug.apk")

out = os.path.join(os.getcwd(), "MarkTV-system-module.zip")
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for root, _dirs, files in os.walk(tpl):
        for f in files:
            full = os.path.join(root, f)
            arc = os.path.relpath(full, tpl).replace(os.sep, "/")
            info = zipfile.ZipInfo(arc)
            info.external_attr = (0o755 if f == "update-binary" else 0o644) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            with open(full, "rb") as fh:
                z.writestr(info, fh.read())
    info = zipfile.ZipInfo("system/priv-app/MarkTV/MarkTV.apk")
    info.external_attr = 0o644 << 16
    info.compress_type = zipfile.ZIP_DEFLATED
    with open(sys.argv[1], "rb") as fh:
        z.writestr(info, fh.read())
print("Готово:", out)
